
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { LanguageProvider } from "./contexts/LanguageContext";
import { AuthProvider } from "./contexts/AuthContext";
import { ApplicationProvider } from "./contexts/ApplicationContext";

import Index from "./pages/Index";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import SolicitorSignup from "./pages/SolicitorSignup";
import Dashboard from "./pages/Dashboard";
import NotFound from "./pages/NotFound";
import NewApplication from "./pages/NewApplication";
import ResidenceAuthorization from "./pages/ResidenceAuthorization";
import LongTermResidence from "./pages/LongTermResidence";
import SolicitorDashboard from "./components/solicitor/SolicitorDashboard";
import ApplicationDetails from "./components/solicitor/ApplicationDetails";
import ApplicationForm from "./components/application/ApplicationForm";
import SolicitorRoute from "./components/solicitor/SolicitorRoute";
import AdminLogin from "./pages/admin/AdminLogin";
import AdminRegister from "./pages/admin/AdminRegister";
import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminRoute from "./components/admin/AdminRoute";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <LanguageProvider>
      <BrowserRouter>
        <AuthProvider>
          <ApplicationProvider>
            <TooltipProvider>
              <Toaster />
              <Sonner />
              <Routes>
                <Route path="/" element={<Index />} />
                <Route path="/login" element={<Login />} />
                <Route path="/signup" element={<Signup />} />
                <Route path="/solicitor-login" element={<Login />} />
                <Route path="/solicitor-signup" element={<SolicitorSignup />} />
                <Route path="/dashboard" element={<Dashboard />} />
                <Route path="/application/new" element={<NewApplication />} />
                <Route path="/application/:applicationId" element={<ApplicationForm />} />
                <Route path="/residence-authorization" element={<ResidenceAuthorization />} />
                <Route path="/long-term-residence" element={<LongTermResidence />} />
                <Route path="/solicitor/dashboard" element={<SolicitorRoute><SolicitorDashboard /></SolicitorRoute>} />
                <Route path="/solicitor/application/:applicationId" element={<SolicitorRoute><ApplicationDetails /></SolicitorRoute>} />
                <Route path="/application/:applicationId/details" element={<SolicitorRoute><ApplicationDetails /></SolicitorRoute>} />
                
                {/* Admin routes */}
                <Route path="/admin/login" element={<AdminLogin />} />
                <Route path="/admin/register" element={<AdminRegister />} />
                <Route path="/admin/dashboard" element={<AdminRoute><AdminDashboard /></AdminRoute>} />
                
                {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
                <Route path="*" element={<NotFound />} />
              </Routes>
            </TooltipProvider>
          </ApplicationProvider>
        </AuthProvider>
      </BrowserRouter>
    </LanguageProvider>
  </QueryClientProvider>
);

export default App;
