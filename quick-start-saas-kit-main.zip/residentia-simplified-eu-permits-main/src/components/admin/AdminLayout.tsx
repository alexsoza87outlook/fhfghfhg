
import React from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { Navigate } from 'react-router-dom';
import AdminSidebar from './AdminSidebar';

interface AdminLayoutProps {
  children: React.ReactNode;
}

const AdminLayout: React.FC<AdminLayoutProps> = ({ children }) => {
  const { profile, isAuthenticated, isLoading } = useAuth();
  
  // Check if the user is authenticated and if they are an admin
  const isAdmin = profile?.user_type === 'admin';
  
  // If authentication is loading, show a loading state
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-resident-purple"></div>
      </div>
    );
  }
  
  // If the user is not authenticated or not an admin, redirect to login
  if (!isAuthenticated || !isAdmin) {
    return <Navigate to="/admin/login" replace />;
  }

  return (
    <div className="flex min-h-screen bg-gray-100">
      <AdminSidebar />
      <div className="flex-1 overflow-x-hidden">
        <main className="p-6">{children}</main>
      </div>
    </div>
  );
};

export default AdminLayout;
