
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';
import { cn } from '@/lib/utils';
import { useAuth } from '@/contexts/AuthContext';
import { 
  LayoutDashboard, 
  Users, 
  FileText, 
  Settings, 
  MessageCircle, 
  Key, 
  BarChart2,
  LogOut
} from 'lucide-react';
import { Button } from '@/components/ui/button';

const AdminSidebar: React.FC = () => {
  const { t } = useLanguage();
  const { logout, profile } = useAuth();
  const location = useLocation();
  
  const navItems = [
    {
      title: t('admin.dashboard.overview'),
      href: '/admin/dashboard',
      icon: <LayoutDashboard className="h-5 w-5" />,
    },
    {
      title: t('admin.dashboard.users'),
      href: '/admin/users',
      icon: <Users className="h-5 w-5" />,
    },
    {
      title: t('admin.dashboard.applications'),
      href: '/admin/applications',
      icon: <FileText className="h-5 w-5" />,
    },
    {
      title: t('admin.dashboard.chatbot'),
      href: '/admin/chatbot',
      icon: <MessageCircle className="h-5 w-5" />,
    },
    {
      title: t('admin.dashboard.apiKeys'),
      href: '/admin/api-keys',
      icon: <Key className="h-5 w-5" />,
    },
    {
      title: t('admin.dashboard.statistics'),
      href: '/admin/statistics',
      icon: <BarChart2 className="h-5 w-5" />,
    },
    {
      title: t('admin.dashboard.settings'),
      href: '/admin/settings',
      icon: <Settings className="h-5 w-5" />,
    },
  ];

  const handleLogout = () => {
    logout();
  };

  return (
    <div className="w-64 bg-white shadow-md min-h-screen">
      <div className="p-4">
        <div className="flex items-center justify-center py-4">
          <h1 className="text-xl font-bold text-resident-purple">
            {t('admin.title')}
          </h1>
        </div>
        
        {profile && (
          <div className="border-b pb-4 mb-4 flex flex-col items-center">
            <div className="w-16 h-16 rounded-full bg-resident-purple/20 flex items-center justify-center text-resident-purple font-bold text-xl mb-2">
              {profile.full_name?.charAt(0) || profile.email.charAt(0)}
            </div>
            <p className="text-sm font-medium">{profile.full_name || profile.email}</p>
            <p className="text-xs text-gray-500">{profile.email}</p>
            <Button
              variant="outline"
              size="sm" 
              className="mt-2 w-full flex items-center justify-center"
              onClick={handleLogout}
            >
              <LogOut className="h-4 w-4 mr-2" />
              {t('auth.logout')}
            </Button>
          </div>
        )}
        
        <nav className="space-y-1">
          {navItems.map((item) => (
            <Link
              key={item.href}
              to={item.href}
              className={cn(
                "flex items-center px-3 py-2 text-sm font-medium rounded-md",
                location.pathname === item.href
                  ? "bg-resident-purple text-white"
                  : "text-gray-700 hover:bg-resident-purple/10 hover:text-resident-purple"
              )}
            >
              {item.icon}
              <span className="ml-3">{item.title}</span>
            </Link>
          ))}
        </nav>
      </div>
    </div>
  );
};

export default AdminSidebar;
