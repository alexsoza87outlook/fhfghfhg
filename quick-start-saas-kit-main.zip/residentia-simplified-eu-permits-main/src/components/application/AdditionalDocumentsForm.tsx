import { useState } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useApplication } from '@/contexts/ApplicationContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Upload, Check, X, File, Plus } from 'lucide-react';

type DocumentUploadFormProps = {
  onNext: () => void;
};

const AdditionalDocumentsForm = ({ onNext }: DocumentUploadFormProps) => {
  const { t } = useLanguage();
  const { application, uploadDocument, isLoading, updateStep } = useApplication();
  
  const [additionalDocuments, setAdditionalDocuments] = useState<{ file: File | null, type: string, uploading: boolean }[]>([
    { file: null, type: 'other', uploading: false }
  ]);
  
  // Filter documents that are of type other than passport_copy and passport_photo
  const existingAdditionalDocuments = application?.documents?.filter(doc => 
    doc.document_type !== 'passport_copy' && doc.document_type !== 'passport_photo') || [];

  const handleFileChange = (index: number, e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const newDocs = [...additionalDocuments];
      newDocs[index].file = e.target.files[0];
      setAdditionalDocuments(newDocs);
    }
  };

  const handleTypeChange = (index: number, e: React.ChangeEvent<HTMLInputElement>) => {
    const newDocs = [...additionalDocuments];
    newDocs[index].type = e.target.value;
    setAdditionalDocuments(newDocs);
  };

  const handleUpload = async (index: number) => {
    const doc = additionalDocuments[index];
    if (!doc.file) return;
    
    const newDocs = [...additionalDocuments];
    newDocs[index].uploading = true;
    setAdditionalDocuments(newDocs);
    
    try {
      await uploadDocument(doc.file, doc.type);
      
      // Reset this entry
      newDocs[index] = { file: null, type: 'other', uploading: false };
      setAdditionalDocuments(newDocs);
    } catch (error) {
      // Handle upload error
      console.error("Error uploading document:", error);
    } finally {
      newDocs[index].uploading = false;
      setAdditionalDocuments(newDocs);
    }
  };

  const handleAddMoreDocuments = () => {
    setAdditionalDocuments([...additionalDocuments, { file: null, type: 'other', uploading: false }]);
  };

  const handleRemoveDocument = (index: number) => {
    const newDocs = [...additionalDocuments];
    newDocs.splice(index, 1);
    setAdditionalDocuments(newDocs);
  };

  const handleNext = () => {
    // Check if there are any documents pending upload
    const pendingUploads = additionalDocuments.some(doc => doc.file !== null);
    if (pendingUploads) {
      if (window.confirm(t('You have documents that have not been uploaded yet. Do you want to continue without uploading them?'))) {
        onNext();
      }
    } else {
      onNext();
    }
  };

  const handleSave = async () => {
    // Upload any pending documents
    const uploadPromises = additionalDocuments.map((doc, index) => {
      if (doc.file) {
        return handleUpload(index);
      }
      return Promise.resolve();
    });
    
    await Promise.all(uploadPromises);
    await updateStep('additional_documents');
  };

  return (
    <div className="max-w-3xl mx-auto">
      <Card>
        <CardHeader>
          <CardTitle>{t('application.documents.additionalTitle')}</CardTitle>
          <CardDescription>Upload any additional supporting documents (optional)</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {/* Existing Additional Documents */}
            {existingAdditionalDocuments.length > 0 && (
              <div className="space-y-3">
                <h3 className="text-sm font-medium">Uploaded Documents</h3>
                {existingAdditionalDocuments.map((doc, index) => (
                  <div key={doc.id} className="flex items-center p-3 border rounded-md bg-green-50">
                    <File className="h-5 w-5 mr-2 text-green-600" />
                    <div className="flex-grow">
                      <span className="text-sm font-medium">{doc.document_type}</span>
                      <p className="text-xs text-gray-500 truncate">{doc.original_filename}</p>
                    </div>
                    <Check className="h-5 w-5 text-green-600" />
                  </div>
                ))}
              </div>
            )}
            
            {/* Additional Document Upload Forms */}
            <div className="space-y-6">
              {additionalDocuments.map((doc, index) => (
                <div key={index} className="space-y-3 border p-4 rounded-md">
                  <div className="flex justify-between items-center">
                    <Label>Document Type</Label>
                    {index > 0 && (
                      <Button 
                        type="button" 
                        variant="ghost" 
                        size="icon" 
                        onClick={() => handleRemoveDocument(index)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                  
                  <Input 
                    type="text" 
                    placeholder="e.g. Proof of Address, Bank Statement" 
                    value={doc.type} 
                    onChange={e => handleTypeChange(index, e)} 
                  />
                  
                  {!doc.file ? (
                    <div className="border-2 border-dashed rounded-md p-6 flex flex-col items-center justify-center bg-gray-50">
                      <Upload className="h-8 w-8 text-gray-400 mb-2" />
                      <p className="text-sm text-gray-500 text-center">{t('application.documents.dragDrop')}</p>
                      <Input 
                        type="file" 
                        className="w-full mt-2" 
                        onChange={e => handleFileChange(index, e)}
                        accept="image/*,application/pdf"
                      />
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <div className="flex items-center p-2 border rounded-md flex-grow">
                        <File className="h-5 w-5 mr-2" />
                        <span className="text-sm truncate">{doc.file.name}</span>
                      </div>
                      <Button 
                        type="button" 
                        onClick={() => handleUpload(index)}
                        disabled={doc.uploading}
                      >
                        {doc.uploading ? (
                          <div className="animate-spin h-4 w-4 border-2 border-white rounded-full border-t-transparent" />
                        ) : t('application.documents.uploadBtn')}
                      </Button>
                      <Button 
                        type="button" 
                        variant="ghost" 
                        size="icon" 
                        onClick={() => {
                          const newDocs = [...additionalDocuments];
                          newDocs[index].file = null;
                          setAdditionalDocuments(newDocs);
                        }}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  )}
                </div>
              ))}
              
              <Button
                type="button"
                variant="outline"
                className="w-full flex items-center justify-center"
                onClick={handleAddMoreDocuments}
              >
                <Plus className="h-4 w-4 mr-2" />
                {t('application.documents.addMore')}
              </Button>
            </div>
            
            {/* Form Actions */}
            <div className="flex justify-between pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={handleSave}
                disabled={isLoading || additionalDocuments.some(doc => doc.uploading)}
              >
                {t('application.button.save')}
              </Button>
              <Button 
                type="button" 
                onClick={handleNext}
                disabled={isLoading || additionalDocuments.some(doc => doc.uploading)}
              >
                {t('application.button.next')}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdditionalDocumentsForm;
