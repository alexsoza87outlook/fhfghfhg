
import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useApplication } from '@/contexts/ApplicationContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import MainLayout from '@/components/layout/MainLayout';
import { ApplicationStep } from '@/types/application';
import PersonalDetailsForm from './PersonalDetailsForm';
import DocumentUploadForm from './DocumentUploadForm';
import AdditionalDocumentsForm from './AdditionalDocumentsForm';
import ReviewForm from './ReviewForm';
import PaymentForm from './PaymentForm';
import ApplicationSuccess from './ApplicationSuccess';

const ApplicationForm = () => {
  const { applicationId } = useParams<{ applicationId: string }>();
  const { application, getApplication, isLoading, error, updateStep } = useApplication();
  const { t } = useLanguage();
  const { isAuthenticated, isLoading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState<ApplicationStep>('personal_details');

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      navigate('/login');
      return;
    }

    if (applicationId) {
      getApplication(applicationId);
    } else {
      navigate('/dashboard');
    }
  }, [applicationId, getApplication, navigate, isAuthenticated, authLoading]);

  useEffect(() => {
    if (application) {
      setCurrentStep(application.current_step as ApplicationStep);
    }
  }, [application]);

  const handleNextStep = async (nextStep: ApplicationStep) => {
    if (application) {
      await updateStep(nextStep);
      setCurrentStep(nextStep);
    }
  };

  if (authLoading || isLoading) {
    return (
      <MainLayout>
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center justify-center min-h-[60vh]">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-resident-purple"></div>
          </div>
        </div>
      </MainLayout>
    );
  }

  if (error) {
    return (
      <MainLayout>
        <div className="container mx-auto px-4 py-8">
          <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
            <div className="flex">
              <div>
                <p className="font-bold text-red-700">Error</p>
                <p className="text-sm text-red-700">{error.message}</p>
              </div>
            </div>
          </div>
          <button
            className="text-resident-purple hover:underline"
            onClick={() => navigate('/dashboard')}
          >
            {t('application.success.backToDashboard')}
          </button>
        </div>
      </MainLayout>
    );
  }

  if (!application) {
    return null;
  }

  const renderStepContent = () => {
    switch (currentStep) {
      case 'personal_details':
        return <PersonalDetailsForm onNext={() => handleNextStep('documents')} />;
      case 'documents':
        return <DocumentUploadForm onNext={() => handleNextStep('additional_documents')} />;
      case 'additional_documents':
        return <AdditionalDocumentsForm onNext={() => handleNextStep('review')} />;
      case 'review':
        return <ReviewForm onNext={() => handleNextStep('payment')} />;
      case 'payment':
        return <PaymentForm onNext={() => handleNextStep('complete')} />;
      case 'complete':
        return <ApplicationSuccess />;
      default:
        return <PersonalDetailsForm onNext={() => handleNextStep('documents')} />;
    }
  };

  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-8">
        {/* Progress bar */}
        <div className="mb-8">
          <div className="flex justify-between mb-2">
            <span className={`text-sm font-medium ${currentStep === 'personal_details' ? 'text-resident-purple' : 'text-gray-500'}`}>
              Personal Details
            </span>
            <span className={`text-sm font-medium ${currentStep === 'documents' ? 'text-resident-purple' : 'text-gray-500'}`}>
              Documents
            </span>
            <span className={`text-sm font-medium ${currentStep === 'additional_documents' ? 'text-resident-purple' : 'text-gray-500'}`}>
              Additional Documents
            </span>
            <span className={`text-sm font-medium ${currentStep === 'review' ? 'text-resident-purple' : 'text-gray-500'}`}>
              Review
            </span>
            <span className={`text-sm font-medium ${currentStep === 'payment' ? 'text-resident-purple' : 'text-gray-500'}`}>
              Payment
            </span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div className="bg-resident-purple h-2.5 rounded-full" style={{ 
              width: currentStep === 'personal_details' ? '20%' : 
                    currentStep === 'documents' ? '40%' : 
                    currentStep === 'additional_documents' ? '60%' : 
                    currentStep === 'review' ? '80%' : 
                    currentStep === 'payment' || currentStep === 'complete' ? '100%' : '0%' 
            }}></div>
          </div>
        </div>
        
        {renderStepContent()}
      </div>
    </MainLayout>
  );
};

export default ApplicationForm;
