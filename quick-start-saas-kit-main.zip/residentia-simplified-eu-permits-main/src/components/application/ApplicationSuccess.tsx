
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle } from 'lucide-react';

const ApplicationSuccess = () => {
  const { t } = useLanguage();
  const navigate = useNavigate();
  
  return (
    <div className="max-w-md mx-auto">
      <Card>
        <CardHeader className="text-center">
          <div className="flex justify-center">
            <CheckCircle className="h-16 w-16 text-green-500 mb-2" />
          </div>
          <CardTitle className="text-2xl">{t('application.success.title')}</CardTitle>
          <CardDescription>{t('application.success.message')}</CardDescription>
        </CardHeader>
        <CardContent className="text-center">
          <Button 
            onClick={() => navigate('/dashboard')}
            className="mt-4"
          >
            {t('application.success.backToDashboard')}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default ApplicationSuccess;
