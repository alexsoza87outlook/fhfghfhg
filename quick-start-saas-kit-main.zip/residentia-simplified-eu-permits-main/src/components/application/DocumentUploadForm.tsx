
import { useState } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useApplication } from '@/contexts/ApplicationContext';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Upload, Check, X, File } from 'lucide-react';

type DocumentUploadFormProps = {
  onNext: () => void;
};

const DocumentUploadForm = ({ onNext }: DocumentUploadFormProps) => {
  const { t } = useLanguage();
  const { application, uploadDocument, isLoading, updateStep } = useApplication();
  const { user } = useAuth();
  
  const [passportCopyFile, setPassportCopyFile] = useState<File | null>(null);
  const [passportPhotoFile, setPassportPhotoFile] = useState<File | null>(null);
  const [uploadingPassportCopy, setUploadingPassportCopy] = useState(false);
  const [uploadingPassportPhoto, setUploadingPassportPhoto] = useState(false);
  
  const existingPassportCopy = application?.documents?.find(doc => doc.document_type === 'passport_copy');
  const existingPassportPhoto = application?.documents?.find(doc => doc.document_type === 'passport_photo');

  const handlePassportCopyChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setPassportCopyFile(e.target.files[0]);
    }
  };

  const handlePassportPhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setPassportPhotoFile(e.target.files[0]);
    }
  };

  const handleUploadPassportCopy = async () => {
    if (!passportCopyFile) return;
    
    setUploadingPassportCopy(true);
    try {
      await uploadDocument(passportCopyFile, 'passport_copy');
      setPassportCopyFile(null);
    } finally {
      setUploadingPassportCopy(false);
    }
  };

  const handleUploadPassportPhoto = async () => {
    if (!passportPhotoFile) return;
    
    setUploadingPassportPhoto(true);
    try {
      await uploadDocument(passportPhotoFile, 'passport_photo');
      setPassportPhotoFile(null);
    } finally {
      setUploadingPassportPhoto(false);
    }
  };

  const handleNext = async () => {
    // Ensure all required documents are uploaded before proceeding
    if (existingPassportCopy && existingPassportPhoto) {
      onNext();
    } else {
      alert(t('Please upload all required documents'));
    }
  };

  const handleSave = async () => {
    // Save any pending documents
    if (passportCopyFile) {
      await handleUploadPassportCopy();
    }
    
    if (passportPhotoFile) {
      await handleUploadPassportPhoto();
    }
    
    await updateStep('documents');
  };

  return (
    <div className="max-w-3xl mx-auto">
      <Card>
        <CardHeader>
          <CardTitle>{t('application.documents.title')}</CardTitle>
          <CardDescription>Please upload the required documents</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {/* Passport Copy Upload */}
            <div className="space-y-3">
              <Label>{t('application.documents.passportCopy')}</Label>
              
              {existingPassportCopy ? (
                <div className="flex items-center p-3 border rounded-md bg-green-50">
                  <File className="h-5 w-5 mr-2 text-green-600" />
                  <span className="flex-grow text-sm truncate">{existingPassportCopy.original_filename}</span>
                  <Check className="h-5 w-5 text-green-600" />
                </div>
              ) : (
                <div className="space-y-2">
                  <div className="border-2 border-dashed rounded-md p-6 flex flex-col items-center justify-center bg-gray-50">
                    <Upload className="h-8 w-8 text-gray-400 mb-2" />
                    <p className="text-sm text-gray-500 text-center">{t('application.documents.dragDrop')}</p>
                    <Input 
                      type="file" 
                      className="w-full mt-2" 
                      onChange={handlePassportCopyChange}
                      accept="image/*,application/pdf"
                    />
                  </div>
                  
                  {passportCopyFile && (
                    <div className="flex items-center gap-2">
                      <div className="flex items-center p-2 border rounded-md flex-grow">
                        <File className="h-5 w-5 mr-2" />
                        <span className="text-sm truncate">{passportCopyFile.name}</span>
                      </div>
                      <Button 
                        type="button" 
                        onClick={handleUploadPassportCopy}
                        disabled={uploadingPassportCopy}
                      >
                        {uploadingPassportCopy ? (
                          <div className="animate-spin h-4 w-4 border-2 border-white rounded-full border-t-transparent" />
                        ) : t('application.documents.uploadBtn')}
                      </Button>
                      <Button 
                        type="button" 
                        variant="ghost" 
                        size="icon" 
                        onClick={() => setPassportCopyFile(null)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  )}
                </div>
              )}
            </div>
            
            {/* Passport Photo Upload */}
            <div className="space-y-3">
              <Label>{t('application.documents.passportPhoto')}</Label>
              
              {existingPassportPhoto ? (
                <div className="flex items-center p-3 border rounded-md bg-green-50">
                  <File className="h-5 w-5 mr-2 text-green-600" />
                  <span className="flex-grow text-sm truncate">{existingPassportPhoto.original_filename}</span>
                  <Check className="h-5 w-5 text-green-600" />
                </div>
              ) : (
                <div className="space-y-2">
                  <div className="border-2 border-dashed rounded-md p-6 flex flex-col items-center justify-center bg-gray-50">
                    <Upload className="h-8 w-8 text-gray-400 mb-2" />
                    <p className="text-sm text-gray-500 text-center">{t('application.documents.dragDrop')}</p>
                    <Input 
                      type="file" 
                      className="w-full mt-2" 
                      onChange={handlePassportPhotoChange}
                      accept="image/*"
                    />
                  </div>
                  
                  {passportPhotoFile && (
                    <div className="flex items-center gap-2">
                      <div className="flex items-center p-2 border rounded-md flex-grow">
                        <File className="h-5 w-5 mr-2" />
                        <span className="text-sm truncate">{passportPhotoFile.name}</span>
                      </div>
                      <Button 
                        type="button" 
                        onClick={handleUploadPassportPhoto}
                        disabled={uploadingPassportPhoto}
                      >
                        {uploadingPassportPhoto ? (
                          <div className="animate-spin h-4 w-4 border-2 border-white rounded-full border-t-transparent" />
                        ) : t('application.documents.uploadBtn')}
                      </Button>
                      <Button 
                        type="button" 
                        variant="ghost" 
                        size="icon" 
                        onClick={() => setPassportPhotoFile(null)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  )}
                </div>
              )}
            </div>
            
            {/* Form Actions */}
            <div className="flex justify-between pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={handleSave}
                disabled={isLoading || uploadingPassportCopy || uploadingPassportPhoto}
              >
                {t('application.button.save')}
              </Button>
              <Button 
                type="button" 
                onClick={handleNext}
                disabled={isLoading || 
                          uploadingPassportCopy || 
                          uploadingPassportPhoto || 
                          !(existingPassportCopy && existingPassportPhoto)}
              >
                {t('application.button.next')}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DocumentUploadForm;
