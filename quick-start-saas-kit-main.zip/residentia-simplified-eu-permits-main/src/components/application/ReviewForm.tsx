
import { useLanguage } from '@/contexts/LanguageContext';
import { useApplication } from '@/contexts/ApplicationContext';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Edit, File } from 'lucide-react';

type ReviewFormProps = {
  onNext: () => void;
};

const ReviewForm = ({ onNext }: ReviewFormProps) => {
  const { t } = useLanguage();
  const { application, isLoading } = useApplication();
  const navigate = useNavigate();
  
  if (!application || !application.personal_details) {
    return null;
  }
  
  const personalDetails = application.personal_details;
  
  const handleEdit = (step: string) => {
    navigate(`/application/${application.id}/${step}`);
  };

  return (
    <div className="max-w-3xl mx-auto">
      <Card>
        <CardHeader>
          <CardTitle>{t('application.review.title')}</CardTitle>
          <CardDescription>Please review your application information before proceeding</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {/* Personal Information Review */}
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-medium">{t('application.review.personalSection')}</h3>
                <Button 
                  type="button" 
                  variant="ghost" 
                  size="sm" 
                  className="flex items-center"
                  onClick={() => handleEdit('personal_details')}
                >
                  <Edit className="h-4 w-4 mr-1" />
                  {t('application.review.editBtn')}
                </Button>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-gray-500">{t('application.personal.firstName')}</p>
                  <p>{personalDetails.first_name}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">{t('application.personal.firstLastName')}</p>
                  <p>{personalDetails.first_last_name}</p>
                </div>
                {personalDetails.second_last_name && (
                  <div>
                    <p className="text-sm font-medium text-gray-500">{t('application.personal.secondLastName')}</p>
                    <p>{personalDetails.second_last_name}</p>
                  </div>
                )}
              </div>
            </div>
            
            {/* Contact Information Review */}
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-medium">{t('application.review.contactSection')}</h3>
                <Button 
                  type="button" 
                  variant="ghost" 
                  size="sm" 
                  className="flex items-center"
                  onClick={() => handleEdit('personal_details')}
                >
                  <Edit className="h-4 w-4 mr-1" />
                  {t('application.review.editBtn')}
                </Button>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-gray-500">{t('application.contact.email')}</p>
                  <p>{personalDetails.email}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">{t('application.contact.phone')}</p>
                  <p>{personalDetails.phone}</p>
                </div>
              </div>
            </div>
            
            {/* Address Information Review */}
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-medium">{t('application.review.addressSection')}</h3>
                <Button 
                  type="button" 
                  variant="ghost" 
                  size="sm" 
                  className="flex items-center"
                  onClick={() => handleEdit('personal_details')}
                >
                  <Edit className="h-4 w-4 mr-1" />
                  {t('application.review.editBtn')}
                </Button>
              </div>
              
              <div className="space-y-2">
                <p>{personalDetails.address_line1}</p>
                {personalDetails.address_line2 && <p>{personalDetails.address_line2}</p>}
                <p>
                  {personalDetails.city}, {personalDetails.state} {personalDetails.postal_code}
                </p>
                <p>{personalDetails.country}</p>
              </div>
            </div>
            
            {/* Identity Information Review */}
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-medium">{t('application.review.identitySection')}</h3>
                <Button 
                  type="button" 
                  variant="ghost" 
                  size="sm" 
                  className="flex items-center"
                  onClick={() => handleEdit('personal_details')}
                >
                  <Edit className="h-4 w-4 mr-1" />
                  {t('application.review.editBtn')}
                </Button>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-gray-500">{t('application.identity.sex')}</p>
                  <p>{personalDetails.sex}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">{t('application.identity.dateOfBirth')}</p>
                  <p>{personalDetails.date_of_birth}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">{t('application.identity.passportNumber')}</p>
                  <p>{personalDetails.passport_number}</p>
                </div>
                {personalDetails.nie && (
                  <div>
                    <p className="text-sm font-medium text-gray-500">{t('application.identity.nie')}</p>
                    <p>{personalDetails.nie}</p>
                  </div>
                )}
                <div>
                  <p className="text-sm font-medium text-gray-500">{t('application.identity.placeOfBirth')}</p>
                  <p>{personalDetails.place_of_birth}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">{t('application.identity.countryOfBirth')}</p>
                  <p>{personalDetails.country_of_birth}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">{t('application.identity.nationality')}</p>
                  <p>{personalDetails.nationality}</p>
                </div>
              </div>
            </div>
            
            {/* Documents Review */}
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-medium">{t('application.review.documentsSection')}</h3>
                <div className="space-x-2">
                  <Button 
                    type="button" 
                    variant="ghost" 
                    size="sm" 
                    className="flex items-center"
                    onClick={() => handleEdit('documents')}
                  >
                    <Edit className="h-4 w-4 mr-1" />
                    {t('application.review.editBtn')} Required
                  </Button>
                  <Button 
                    type="button" 
                    variant="ghost" 
                    size="sm" 
                    className="flex items-center"
                    onClick={() => handleEdit('additional_documents')}
                  >
                    <Edit className="h-4 w-4 mr-1" />
                    {t('application.review.editBtn')} Additional
                  </Button>
                </div>
              </div>
              
              <div className="space-y-3">
                {application.documents && application.documents.map((doc, index) => (
                  <div key={index} className="flex items-center p-3 border rounded-md">
                    <File className="h-5 w-5 mr-2 text-resident-purple" />
                    <div className="flex-grow">
                      <p className="font-medium text-sm">{doc.document_type}</p>
                      <p className="text-xs text-gray-500 truncate">{doc.original_filename}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Form Actions */}
            <div className="flex justify-end pt-6">
              <Button 
                type="button" 
                onClick={onNext}
                disabled={isLoading}
              >
                {t('application.button.next')}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ReviewForm;
