
import React from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { StatusUpdate } from '@/types/application';
import { format } from 'date-fns';
import { CheckCircle, Clock, FileText, AlertCircle, FileCheck } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';

interface ApplicationTimelineProps {
  statusUpdates: StatusUpdate[];
  latestApplication: any; // Using any here as the structure is used conditionally
}

const ApplicationTimeline: React.FC<ApplicationTimelineProps> = ({ statusUpdates, latestApplication }) => {
  const { t } = useLanguage();
  
  // Build timeline steps based on application status and history
  const buildTimelineSteps = () => {
    // Default timeline steps with icons
    const defaultSteps = [
      { 
        id: 'draft',
        title: t('dashboard.applicationStatus.draft'),
        date: t('dashboard.timeline.step1.date'),
        status: 'completed',
        icon: FileText
      },
      { 
        id: 'submitted',
        title: t('dashboard.applicationStatus.submitted'),
        date: t('dashboard.timeline.step2.date'),
        status: 'completed',
        icon: FileCheck
      },
      { 
        id: 'under_review',
        title: t('dashboard.applicationStatus.underReview'),
        date: t('dashboard.timeline.step3.status'),
        status: 'current',
        icon: Clock
      },
      { 
        id: 'additional_docs_required',
        title: t('dashboard.applicationStatus.docsRequired'),
        date: t('dashboard.timeline.step4.date'),
        status: 'upcoming',
        icon: AlertCircle
      },
      { 
        id: 'approved',
        title: t('dashboard.applicationStatus.approved'),
        date: t('dashboard.timeline.step5.date'),
        status: 'upcoming',
        icon: CheckCircle
      }
    ];

    // If we have an application and status updates, customize the timeline
    if (latestApplication && statusUpdates.length > 0) {
      // Sort from oldest to newest for chronological display
      const sortedUpdates = [...statusUpdates].sort((a, b) => 
        new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
      );
      
      // Map status updates to timeline steps
      return sortedUpdates.map((update, index) => {
        const date = new Date(update.created_at);
        const formattedDate = format(date, 'MMM d, yyyy');
        
        let status = 'completed';
        if (index === sortedUpdates.length - 1) {
          status = 'current';
        }
        
        // Determine title and icon based on status
        let title, icon;
        switch (update.status) {
          case 'draft':
            title = t('dashboard.applicationStatus.draft');
            icon = FileText;
            break;
          case 'submitted':
            title = t('dashboard.applicationStatus.submitted');
            icon = FileCheck;
            break;
          case 'under_review':
            title = t('dashboard.applicationStatus.underReview');
            icon = Clock;
            break;
          case 'additional_docs_required':
            title = t('dashboard.applicationStatus.docsRequired');
            icon = AlertCircle;
            break;
          case 'approved':
            title = t('dashboard.applicationStatus.approved');
            icon = CheckCircle;
            break;
          case 'rejected':
            title = t('dashboard.applicationStatus.rejected');
            icon = AlertCircle;
            break;
          case 'completed':
            title = t('dashboard.applicationStatus.completed');
            icon = CheckCircle;
            break;
          default:
            title = `Status: ${update.status}`;
            icon = Clock;
        }
        
        return {
          id: `status-${index}`,
          title: update.comment ? `${title}: ${update.comment}` : title,
          date: formattedDate,
          status,
          icon
        };
      });
    }
    
    return defaultSteps;
  };

  const timelineSteps = buildTimelineSteps();

  return (
    <div className="bg-resident-purple-light p-6 rounded-lg w-full mb-6">
      <h2 className="text-xl font-semibold mb-4">{t('dashboard.timeline.title')}</h2>
      <ScrollArea className="w-full">
        <div className="flex space-x-4 pb-4 min-w-max">
          {timelineSteps.map((step, index) => (
            <HorizontalTimelineItem
              key={step.id}
              title={step.title}
              date={step.date}
              isCompleted={step.status === 'completed'}
              isCurrent={step.status === 'current'}
              isLast={index === timelineSteps.length - 1}
              Icon={step.icon}
            />
          ))}
        </div>
      </ScrollArea>
    </div>
  );
};

interface HorizontalTimelineItemProps {
  title: string;
  date: string;
  isCompleted: boolean;
  isCurrent: boolean;
  isLast: boolean;
  Icon?: React.ElementType;
}

const HorizontalTimelineItem: React.FC<HorizontalTimelineItemProps> = ({
  title,
  date,
  isCompleted,
  isCurrent,
  isLast,
  Icon
}) => {
  let dotColor = 'bg-gray-300';
  let iconColor = 'text-gray-400';
  
  if (isCompleted) {
    dotColor = 'bg-green-500';
    iconColor = 'text-green-500';
  } else if (isCurrent) {
    dotColor = 'bg-amber-500';
    iconColor = 'text-amber-500';
  }
  
  return (
    <div className="flex flex-col items-center text-center min-w-[120px] max-w-[180px]">
      <div className="flex flex-col items-center">
        <div className={`h-10 w-10 rounded-full ${dotColor} flex items-center justify-center`}>
          {Icon && <Icon className={`h-6 w-6 ${iconColor}`} />}
        </div>
        {!isLast && (
          <div className="h-0.5 w-24 bg-gray-300 mt-5 absolute translate-x-[60px]"></div>
        )}
      </div>
      <div className="mt-3">
        <p className="font-medium text-sm">{title}</p>
        <p className="text-xs text-gray-600">{date}</p>
      </div>
    </div>
  );
};

export default ApplicationTimeline;
