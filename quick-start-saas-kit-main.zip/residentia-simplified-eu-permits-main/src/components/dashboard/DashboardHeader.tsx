
import React from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { Button } from '@/components/ui/button';
import { PlusCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface DashboardHeaderProps {
  userName: string;
}

const DashboardHeader: React.FC<DashboardHeaderProps> = ({ userName }) => {
  const { t } = useLanguage();
  const navigate = useNavigate();

  const handleStartApplication = () => {
    navigate('/application/new');
  };

  return (
    <div className="flex justify-between items-center mb-6">
      <h1 className="text-3xl font-bold">
        {t('dashboard.welcome', { name: userName })}
      </h1>
      <Button 
        onClick={handleStartApplication}
        className="bg-resident-purple hover:bg-resident-purple-dark"
      >
        <PlusCircle className="mr-2 h-5 w-5" />
        {t('dashboard.startApplication')}
      </Button>
    </div>
  );
};

export default DashboardHeader;
