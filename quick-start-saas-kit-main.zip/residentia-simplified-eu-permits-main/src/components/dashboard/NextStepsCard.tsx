
import React from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Clock } from 'lucide-react';

const NextStepsCard: React.FC = () => {
  const { t } = useLanguage();

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center">
          <Clock className="mr-2 h-5 w-5" />
          {t('dashboard.cards.nextsteps.title')}
        </CardTitle>
        <CardDescription>{t('dashboard.cards.nextsteps.description')}</CardDescription>
      </CardHeader>
      <CardContent>
        <p className="font-medium">{t('dashboard.cards.nextsteps.biometric')}</p>
        <p className="text-sm text-gray-600 mt-2">
          {t('dashboard.cards.nextsteps.message')}
        </p>
      </CardContent>
    </Card>
  );
};

export default NextStepsCard;
