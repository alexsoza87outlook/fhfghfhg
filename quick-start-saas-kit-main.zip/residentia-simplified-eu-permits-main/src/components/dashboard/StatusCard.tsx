
import React from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { FileText } from 'lucide-react';
import { Application } from '@/types/application';

interface StatusCardProps {
  latestApplication: Application | null;
}

const StatusCard: React.FC<StatusCardProps> = ({ latestApplication }) => {
  const { t } = useLanguage();

  const getStatusDisplay = () => {
    if (!latestApplication) return { 
      text: t('dashboard.cards.status.none'), 
      color: 'text-gray-500' 
    };

    switch (latestApplication.status) {
      case 'draft':
        return { text: t('dashboard.cards.status.draft'), color: 'text-blue-500' };
      case 'submitted':
        return { text: t('dashboard.cards.status.submitted'), color: 'text-purple-500' };
      case 'under_review':
        return { text: t('dashboard.cards.status.review'), color: 'text-amber-500' };
      case 'approved':
        return { text: t('dashboard.cards.status.approved'), color: 'text-green-500' };
      case 'rejected':
        return { text: t('dashboard.cards.status.rejected'), color: 'text-red-500' };
      case 'additional_docs_required':
        return { text: t('dashboard.cards.status.docs'), color: 'text-orange-500' };
      default:
        return { text: latestApplication.status, color: 'text-gray-500' };
    }
  };

  const statusDisplay = getStatusDisplay();

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center">
          <FileText className="mr-2 h-5 w-5" />
          {t('dashboard.cards.status.title')}
        </CardTitle>
        <CardDescription>{t('dashboard.cards.status.description')}</CardDescription>
      </CardHeader>
      <CardContent>
        <p className={`font-medium ${statusDisplay.color}`}>{statusDisplay.text}</p>
        <p className="text-sm text-gray-600 mt-2">
          {latestApplication 
            ? t('dashboard.cards.status.message') 
            : t('dashboard.cards.status.noApplications')}
        </p>
      </CardContent>
    </Card>
  );
};

export default StatusCard;
