
import React from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { AlertCircle } from 'lucide-react';

const SupportCard: React.FC = () => {
  const { t } = useLanguage();

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center">
          <AlertCircle className="mr-2 h-5 w-5" />
          {t('dashboard.cards.support.title')}
        </CardTitle>
        <CardDescription>{t('dashboard.cards.support.description')}</CardDescription>
      </CardHeader>
      <CardContent>
        <p className="font-medium">{t('dashboard.cards.support.questions')}</p>
        <p className="text-sm text-gray-600 mt-2">
          {t('dashboard.cards.support.message')}
        </p>
      </CardContent>
    </Card>
  );
};

export default SupportCard;
