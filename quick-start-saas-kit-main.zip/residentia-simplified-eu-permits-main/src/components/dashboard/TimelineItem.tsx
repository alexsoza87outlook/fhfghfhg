
import React from 'react';
import { LucideIcon } from 'lucide-react';

interface TimelineItemProps {
  title: string;
  date: string;
  isCompleted: boolean;
  isCurrent: boolean;
  isLast: boolean;
  Icon?: LucideIcon;
}

const TimelineItem: React.FC<TimelineItemProps> = ({ 
  title, 
  date, 
  isCompleted, 
  isCurrent, 
  isLast,
  Icon
}) => {
  let dotColor = 'bg-gray-300';
  let iconColor = 'text-gray-400';
  
  if (isCompleted) {
    dotColor = 'bg-green-500';
    iconColor = 'text-green-500';
  } else if (isCurrent) {
    dotColor = 'bg-amber-500';
    iconColor = 'text-amber-500';
  }
  
  return (
    <div className="flex">
      <div className="flex-shrink-0">
        <div className={`h-4 w-4 rounded-full ${dotColor} mt-2 flex items-center justify-center`}>
          {Icon && <Icon className={`h-4 w-4 ${iconColor}`} />}
        </div>
        {!isLast && <div className="h-16 w-0.5 bg-gray-300 mx-auto"></div>}
      </div>
      <div className="ml-4">
        <p className="font-medium">{title}</p>
        <p className="text-sm text-gray-600">{date}</p>
      </div>
    </div>
  );
};

export default TimelineItem;
