
import React from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Card, CardContent } from '@/components/ui/card';
import { FileTextIcon, RefreshCcwIcon } from 'lucide-react';

interface AuthorizationTypeSelectorProps {
  isOpen: boolean;
  onClose: () => void;
  onTypeSelect: (type: 'initial' | 'renewal') => void;
  selectedCountry: string;
}

const AuthorizationTypeSelector: React.FC<AuthorizationTypeSelectorProps> = ({ 
  isOpen, 
  onClose, 
  onTypeSelect,
  selectedCountry
}) => {
  const { t } = useLanguage();
  
  const countryName = t(`countries.${selectedCountry}`);

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-center">
            {t('eligibility.selectAuthorizationType')}
          </DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 py-6">
          <Card 
            className="cursor-pointer hover:shadow-md transition-all hover:border-resident-purple"
            onClick={() => onTypeSelect('initial')}
          >
            <CardContent className="pt-6 flex flex-col items-center text-center">
              <FileTextIcon className="h-12 w-12 text-resident-purple mb-4" />
              <h3 className="text-lg font-bold mb-2">{t('eligibility.initialResidence')}</h3>
              <p className="text-gray-600">
                {t('eligibility.initialResidenceDescription', { country: countryName })}
              </p>
            </CardContent>
          </Card>

          <Card 
            className="cursor-pointer hover:shadow-md transition-all hover:border-resident-purple"
            onClick={() => onTypeSelect('renewal')}
          >
            <CardContent className="pt-6 flex flex-col items-center text-center">
              <RefreshCcwIcon className="h-12 w-12 text-resident-purple mb-4" />
              <h3 className="text-lg font-bold mb-2">{t('eligibility.residenceRenewal')}</h3>
              <p className="text-gray-600">
                {t('eligibility.residenceRenewalDescription')}
              </p>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default AuthorizationTypeSelector;
