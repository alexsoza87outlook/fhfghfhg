
import React from 'react';
import { CountryOption } from '@/data/countriesData';
import { Button } from '@/components/ui/button';
import { Check } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';

interface CountryListProps {
  countries: CountryOption[];
  onSelectCountry: (countryCode: string) => void;
}

const CountryList: React.FC<CountryListProps> = ({ countries, onSelectCountry }) => {
  return (
    <ScrollArea className="h-[300px] rounded-md border p-2">
      <div className="space-y-1">
        {countries.map((country) => (
          <Button
            key={country.code}
            variant="ghost"
            className="w-full justify-start font-normal"
            onClick={() => onSelectCountry(country.code)}
          >
            {country.name}
            <Check className="ml-auto h-4 w-4 opacity-0" />
          </Button>
        ))}
      </div>
    </ScrollArea>
  );
};

export default CountryList;
