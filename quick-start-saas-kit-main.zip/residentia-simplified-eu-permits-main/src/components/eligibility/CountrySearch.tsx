
import React from 'react';
import { Input } from '@/components/ui/input';
import { Search } from 'lucide-react';

interface CountrySearchProps {
  searchTerm: string;
  onSearchChange: (value: string) => void;
  placeholder: string;
}

const CountrySearch: React.FC<CountrySearchProps> = ({ 
  searchTerm, 
  onSearchChange,
  placeholder 
}) => {
  return (
    <div className="relative mb-4">
      <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
      <Input 
        className="pl-10" 
        placeholder={placeholder}
        value={searchTerm}
        onChange={(e) => onSearchChange(e.target.value)}
      />
    </div>
  );
};

export default CountrySearch;
