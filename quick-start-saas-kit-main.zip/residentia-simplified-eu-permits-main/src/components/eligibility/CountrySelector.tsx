
import React from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { GlobeIcon } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';

interface CountrySelectorProps {
  isOpen: boolean;
  onClose: () => void;
  onCountrySelect: (country: string) => void;
}

const CountrySelector: React.FC<CountrySelectorProps> = ({ isOpen, onClose, onCountrySelect }) => {
  const { t } = useLanguage();
  
  // All EU countries - only Spain is active for now
  const euCountries = [
    { code: 'es', name: t('countries.spain'), active: true },
    { code: 'it', name: t('countries.italy'), active: false },
    { code: 'fr', name: t('countries.france'), active: false },
    { code: 'pt', name: t('countries.portugal'), active: false },
    { code: 'cz', name: t('countries.czech'), active: false },
    { code: 'si', name: t('countries.slovenia'), active: false },
    { code: 'at', name: t('countries.austria'), active: false },
    { code: 'gr', name: t('countries.greece'), active: false },
    { code: 'pl', name: t('countries.poland'), active: false },
    { code: 'hu', name: t('countries.hungary'), active: false },
    { code: 'hr', name: t('countries.croatia'), active: false },
    { code: 'sk', name: t('countries.slovakia'), active: false },
    { code: 'ro', name: t('countries.romania'), active: false },
    { code: 'bg', name: t('countries.bulgaria'), active: false },
    { code: 'de', name: t('countries.germany'), active: false },
    { code: 'nl', name: t('countries.netherlands'), active: false },
    { code: 'be', name: t('countries.belgium'), active: false },
    { code: 'lu', name: t('countries.luxembourg'), active: false },
    { code: 'dk', name: t('countries.denmark'), active: false },
    { code: 'se', name: t('countries.sweden'), active: false },
    { code: 'fi', name: t('countries.finland'), active: false },
    { code: 'ie', name: t('countries.ireland'), active: false },
    { code: 'ee', name: t('countries.estonia'), active: false },
    { code: 'lv', name: t('countries.latvia'), active: false },
    { code: 'lt', name: t('countries.lithuania'), active: false },
    { code: 'mt', name: t('countries.malta'), active: false },
    { code: 'cy', name: t('countries.cyprus'), active: false },
  ];

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-md sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-center">
            {t('eligibility.selectCountry')}
          </DialogTitle>
        </DialogHeader>

        <ScrollArea className="max-h-80">
          <div className="grid grid-cols-3 md:grid-cols-4 gap-2 py-3">
            {euCountries.map(country => (
              <Card 
                key={country.code}
                className={`p-2 flex flex-col items-center justify-center text-center transition-all ${
                  country.active 
                    ? 'cursor-pointer hover:bg-resident-purple-light hover:shadow-md border-resident-purple' 
                    : 'opacity-60 cursor-not-allowed'
                }`}
                onClick={() => country.active && onCountrySelect(country.code)}
              >
                <GlobeIcon className={`h-4 w-4 mb-1 ${country.active ? 'text-resident-purple' : 'text-gray-400'}`} />
                <p className="font-medium text-xs">{country.name}</p>
                {country.active ? (
                  <Badge className="bg-resident-purple text-white text-xs mt-1 px-1 py-0">{t('eligibility.available')}</Badge>
                ) : (
                  <Badge variant="outline" className="text-xs text-gray-500 mt-1 px-1 py-0">{t('eligibility.comingSoon')}</Badge>
                )}
              </Card>
            ))}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
};

export default CountrySelector;
