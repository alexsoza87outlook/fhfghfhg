
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import CountrySelector from './CountrySelector';
import AuthorizationTypeSelector from './AuthorizationTypeSelector';
import NationalitySelector from './NationalitySelector';
import RenewalTypeSelector from './RenewalTypeSelector';
import { useToast } from '@/components/ui/use-toast';
import { useLanguage } from '@/contexts/LanguageContext';

interface EligibilityCheckProps {
  isOpen: boolean;
  onClose: () => void;
}

const EligibilityCheck: React.FC<EligibilityCheckProps> = ({ isOpen, onClose }) => {
  const { toast } = useToast();
  const { t } = useLanguage();
  const navigate = useNavigate();
  
  const [step, setStep] = useState<'country' | 'authType' | 'nationality' | 'renewalType'>('country');
  const [selectedCountry, setSelectedCountry] = useState<string>('');
  const [selectedAuthType, setSelectedAuthType] = useState<'initial' | 'renewal' | ''>('');

  const handleCountrySelect = (country: string) => {
    setSelectedCountry(country);
    setStep('authType');
  };

  const handleAuthTypeSelect = (type: 'initial' | 'renewal') => {
    setSelectedAuthType(type);
    if (type === 'initial') {
      setStep('nationality');
    } else {
      setStep('renewalType');
    }
  };

  const handleNationalitySelect = (countryCode: string) => {
    // Here you would typically navigate to a form or process the eligibility check
    toast({
      title: t('eligibility.nationalitySelected'),
      description: t('eligibility.redirectingToForm'),
    });
    // Reset state and close eligibility check
    resetAndClose();
  };

  const handleRenewalTypeSelect = (type: 'standard' | 'longterm' | 'other') => {
    // Handle the selection of renewal type
    if (type === 'longterm') {
      navigate('/long-term-residence');
    } else {
      toast({
        title: t('eligibility.renewalTypeSelected'),
        description: t('eligibility.redirectingToForm'),
      });
    }
    // Reset state and close eligibility check
    resetAndClose();
  };

  const resetAndClose = () => {
    // Reset the state
    setStep('country');
    setSelectedCountry('');
    setSelectedAuthType('');
    // Close the eligibility check
    onClose();
  };

  // Handle back button functionality
  const handleBackButton = () => {
    if (step === 'authType') {
      setStep('country');
    } else if (step === 'nationality' || step === 'renewalType') {
      setStep('authType');
    }
  };

  return (
    <>
      <CountrySelector 
        isOpen={isOpen && step === 'country'} 
        onClose={onClose} 
        onCountrySelect={handleCountrySelect} 
      />
      
      <AuthorizationTypeSelector 
        isOpen={isOpen && step === 'authType'} 
        onClose={() => handleBackButton()} 
        onTypeSelect={handleAuthTypeSelect} 
        selectedCountry={selectedCountry}
      />
      
      <NationalitySelector 
        isOpen={isOpen && step === 'nationality'} 
        onClose={() => handleBackButton()} 
        onNationalitySelect={handleNationalitySelect} 
      />
      
      <RenewalTypeSelector 
        isOpen={isOpen && step === 'renewalType'} 
        onClose={() => handleBackButton()} 
        onRenewalTypeSelect={handleRenewalTypeSelect} 
        selectedCountry={selectedCountry}
      />
    </>
  );
};

export default EligibilityCheck;
