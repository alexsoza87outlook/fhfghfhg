
import React, { useState, useEffect } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { countryList, CountryOption } from '@/data/countriesData'; 
import { filterCountriesBySearchTerm, getSortedCountries } from '@/utils/countryUtils';
import CountrySearch from './CountrySearch';
import CountryList from './CountryList';

interface NationalitySelectorProps {
  isOpen: boolean;
  onClose: () => void;
  onNationalitySelect: (countryCode: string) => void;
}

const NationalitySelector: React.FC<NationalitySelectorProps> = ({ 
  isOpen, 
  onClose, 
  onNationalitySelect 
}) => {
  const { t } = useLanguage();
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredCountries, setFilteredCountries] = useState<CountryOption[]>([]);
  const [allCountries, setAllCountries] = useState<CountryOption[]>([]);

  // Initialize and sort countries
  useEffect(() => {
    setAllCountries(getSortedCountries(countryList));
  }, []);

  // Filter countries when search term changes
  useEffect(() => {
    setFilteredCountries(filterCountriesBySearchTerm(allCountries, searchTerm));
  }, [searchTerm, allCountries]);

  const handleSearchChange = (value: string) => {
    setSearchTerm(value);
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-center">
            {t('eligibility.selectNationality')}
          </DialogTitle>
        </DialogHeader>

        <div className="py-4">
          <p className="text-center mb-4">
            {t('eligibility.findRightAuthorization')}
          </p>
          
          <CountrySearch 
            searchTerm={searchTerm} 
            onSearchChange={handleSearchChange}
            placeholder={t('eligibility.searchCountry')}
          />

          <CountryList 
            countries={filteredCountries} 
            onSelectCountry={onNationalitySelect} 
          />
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default NationalitySelector;
