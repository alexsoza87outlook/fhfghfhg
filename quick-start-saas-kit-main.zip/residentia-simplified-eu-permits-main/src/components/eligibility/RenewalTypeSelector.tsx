
import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/contexts/LanguageContext';
import { useNavigate } from 'react-router-dom';

interface RenewalTypeSelectorProps {
  isOpen: boolean;
  onClose: () => void;
  onRenewalTypeSelect: (type: 'standard' | 'longterm' | 'other') => void;
  selectedCountry: string;
}

const RenewalTypeSelector: React.FC<RenewalTypeSelectorProps> = ({
  isOpen,
  onClose,
  onRenewalTypeSelect,
  selectedCountry,
}) => {
  const { t } = useLanguage();
  const navigate = useNavigate();

  const handleLongTermSelection = () => {
    // Navigate to long-term residence page instead of using the onRenewalTypeSelect callback
    navigate('/long-term-residence');
    onClose();
  };
  
  const handleStandardRenewalSelection = () => {
    // Navigate to residence authorization page for standard renewals
    navigate('/residence-authorization');
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold">
            {t('eligibility.selectAuthorizationPhase')}
          </DialogTitle>
        </DialogHeader>

        <div className="flex flex-col space-y-4 mt-4">
          <Button
            variant="outline"
            className="flex flex-col items-start p-4 h-auto"
            onClick={handleStandardRenewalSelection}
          >
            <span className="font-medium mb-1">{t('eligibility.renewalOrExtension')}</span>
            <span className="text-sm text-gray-500">
              {t('eligibility.standardRenewalDescription')}
            </span>
          </Button>

          <Button
            variant="outline"
            className="flex flex-col items-start p-4 h-auto"
            onClick={handleLongTermSelection}
          >
            <span className="font-medium mb-1">{t('eligibility.longTermResidence')}</span>
            <span className="text-sm text-gray-500">
              {t('eligibility.longTermResidenceDescription').replace('{country}', selectedCountry)}
            </span>
          </Button>

          <Button
            variant="outline"
            className="flex flex-col items-start p-4 h-auto"
            onClick={() => onRenewalTypeSelect('other')}
          >
            <span className="font-medium mb-1">{t('eligibility.others')}</span>
            <span className="text-sm text-gray-500">{t('eligibility.othersDescription')}</span>
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default RenewalTypeSelector;
