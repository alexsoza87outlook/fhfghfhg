
import { useLanguage } from '@/contexts/LanguageContext';
import { Globe, UserCheck, DollarSign, Languages, BarChart3, Video, ShieldCheck, CreditCard } from 'lucide-react';

const BenefitsSection = () => {
  const { t } = useLanguage();

  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="gradient-text">{t('benefits.title')}</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Why thousands of applicants choose ResidentIA for their EU residence permit needs.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-y-8 gap-x-6">
          <div className="bg-white rounded-lg p-6 shadow-md">
            <div className="mb-4 h-12 w-12 bg-resident-purple-light rounded-full flex items-center justify-center">
              <Globe className="h-6 w-6 text-resident-purple" />
            </div>
            <p className="text-gray-800 font-medium">
              {t('benefits.online')}
            </p>
          </div>

          <div className="bg-white rounded-lg p-6 shadow-md">
            <div className="mb-4 h-12 w-12 bg-resident-blue-light rounded-full flex items-center justify-center">
              <UserCheck className="h-6 w-6 text-resident-blue" />
            </div>
            <p className="text-gray-800 font-medium">
              {t('benefits.qualified')}
            </p>
          </div>

          <div className="bg-white rounded-lg p-6 shadow-md">
            <div className="mb-4 h-12 w-12 bg-resident-purple-light rounded-full flex items-center justify-center">
              <DollarSign className="h-6 w-6 text-resident-purple" />
            </div>
            <p className="text-gray-800 font-medium">
              {t('benefits.pricing')}
            </p>
          </div>

          <div className="bg-white rounded-lg p-6 shadow-md">
            <div className="mb-4 h-12 w-12 bg-resident-blue-light rounded-full flex items-center justify-center">
              <Languages className="h-6 w-6 text-resident-blue" />
            </div>
            <p className="text-gray-800 font-medium">
              {t('benefits.multilingual')}
            </p>
          </div>
          
          <div className="bg-white rounded-lg p-6 shadow-md">
            <div className="mb-4 h-12 w-12 bg-resident-purple-light rounded-full flex items-center justify-center">
              <BarChart3 className="h-6 w-6 text-resident-purple" />
            </div>
            <p className="text-gray-800 font-medium">
              {t('benefits.tracker')}
            </p>
          </div>

          <div className="bg-white rounded-lg p-6 shadow-md">
            <div className="mb-4 h-12 w-12 bg-resident-blue-light rounded-full flex items-center justify-center">
              <Video className="h-6 w-6 text-resident-blue" stroke="currentColor" />
            </div>
            <p className="text-gray-800 font-medium">
              {t('benefits.nocalls')}
            </p>
          </div>

          <div className="bg-white rounded-lg p-6 shadow-md">
            <div className="mb-4 h-12 w-12 bg-resident-purple-light rounded-full flex items-center justify-center">
              <ShieldCheck className="h-6 w-6 text-resident-purple" />
            </div>
            <p className="text-gray-800 font-medium">
              {t('benefits.guarantee')}
            </p>
          </div>

          <div className="bg-white rounded-lg p-6 shadow-md">
            <div className="mb-4 h-12 w-12 bg-resident-blue-light rounded-full flex items-center justify-center">
              <CreditCard className="h-6 w-6 text-resident-blue" />
            </div>
            <p className="text-gray-800 font-medium">
              {t('benefits.klarna')}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default BenefitsSection;
