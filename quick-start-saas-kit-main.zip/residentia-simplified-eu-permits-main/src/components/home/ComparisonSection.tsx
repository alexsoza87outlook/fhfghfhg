
import { useLanguage } from '@/contexts/LanguageContext';
import { CheckCircle, X } from 'lucide-react';

const ComparisonSection = () => {
  const { t } = useLanguage();
  
  const features = [
    {
      name: t('comparison.feature1'),
      residentIA: true,
      traditional: false,
      traditionalText: t('comparison.no')
    },
    {
      name: t('comparison.feature2'),
      residentIA: true,
      traditional: false,
      traditionalText: t('comparison.no.extra')
    },
    {
      name: t('comparison.feature3'),
      residentIA: true,
      traditional: false,
      traditionalText: t('comparison.no')
    },
    {
      name: t('comparison.feature4'),
      residentIA: true,
      traditional: false,
      traditionalText: t('comparison.no.required')
    },
    {
      name: t('comparison.feature5'),
      residentIA: true,
      traditional: false,
      traditionalText: t('comparison.no.manual')
    },
    {
      name: t('comparison.feature6'),
      residentIA: true,
      traditional: true,
      traditionalText: t('comparison.yes')
    },
    {
      name: t('comparison.feature7'),
      residentIA: true,
      traditional: false,
      traditionalText: t('comparison.no.common')
    },
    {
      name: t('comparison.feature8'),
      residentIA: true,
      traditional: false,
      traditionalText: t('comparison.no.hourly')
    },
    {
      name: t('comparison.feature9'),
      residentIA: true,
      traditional: false,
      traditionalText: t('comparison.no.refunds')
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="gradient-text">{t('comparison.title')}</span>
          </h2>
        </div>
        
        <div className="max-w-4xl mx-auto overflow-x-auto">
          <table className="w-full shadow-lg rounded-lg overflow-hidden">
            <thead className="bg-resident-purple text-white">
              <tr>
                <th className="py-4 px-6 text-left">{t('comparison.feature1').split(' ')[0]}</th>
                <th className="py-4 px-6 text-center">ResidentIA</th>
                <th className="py-4 px-6 text-center">{t('comparison.title').split(' vs ')[1]}</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {features.map((feature, index) => (
                <tr key={index} className={index % 2 === 0 ? 'bg-gray-50' : 'bg-white'}>
                  <td className="py-4 px-6">{feature.name}</td>
                  <td className="py-4 px-6 text-center">
                    {feature.residentIA ? (
                      <div className="flex justify-center">
                        <CheckCircle className="h-6 w-6 text-green-500" />
                        <span className="sr-only">{t('comparison.yes')}</span>
                      </div>
                    ) : (
                      <div className="flex justify-center">
                        <X className="h-6 w-6 text-red-500" />
                        <span className="sr-only">{t('comparison.no')}</span>
                      </div>
                    )}
                  </td>
                  <td className="py-4 px-6 text-center">
                    {feature.traditional ? (
                      <div className="flex justify-center">
                        <CheckCircle className="h-6 w-6 text-green-500" />
                        <span className="sr-only">{t('comparison.yes')}</span>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center">
                        <X className="h-6 w-6 text-red-500" />
                        <span className="text-sm text-gray-500">{feature.traditionalText}</span>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
};

export default ComparisonSection;
