
import { useLanguage } from '@/contexts/LanguageContext';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

const CtaSection = () => {
  const { t } = useLanguage();

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="bg-gradient-to-r from-resident-purple to-resident-blue rounded-2xl overflow-hidden shadow-xl">
          <div className="py-12 px-8 md:px-12 flex flex-col items-center text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-white">
              {t('cta.title')}
            </h2>
            <p className="text-xl text-white/90 mb-8 max-w-3xl">
              {t('cta.description')}
            </p>
            <Link to="/signup">
              <Button size="lg" className="bg-white text-resident-purple hover:bg-gray-100 group">
                {t('cta.button')}
                <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CtaSection;
