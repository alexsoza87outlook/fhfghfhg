import { useState } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { ChevronRight, CheckCircle, CreditCard, ArrowRight, ShieldCheck, CheckSquare } from 'lucide-react';
import EligibilityCheck from '../eligibility/EligibilityCheck';
import CountrySelector from '../eligibility/CountrySelector';
import { useIsMobile } from '@/hooks/use-mobile';
import { Badge } from '@/components/ui/badge';

const HeroSection = () => {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const isMobile = useIsMobile();
  const [isEligibilityCheckOpen, setIsEligibilityCheckOpen] = useState(false);
  const [isCountrySelectorOpen, setIsCountrySelectorOpen] = useState(false);

  const handleEligibilityCheckOpen = () => {
    setIsEligibilityCheckOpen(true);
  };

  const handleEligibilityCheckClose = () => {
    setIsEligibilityCheckOpen(false);
  };

  const handleStartApplication = () => {
    setIsCountrySelectorOpen(true);
  };

  const handleCountrySelect = (country: string) => {
    setIsCountrySelectorOpen(false);
    navigate('/residence-authorization');
  };

  return (
    <div className="relative bg-gradient-to-b from-resident-gray-dark via-resident-purple-dark to-resident-purple-light overflow-hidden">
      <div 
        className="absolute inset-0 z-0 opacity-20"
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1530789253388-582c481c54b0?auto=format&fit=crop&q=80&w=1920&h=800&crop=entropy')",
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundBlendMode: "luminosity"
        }}
        role="img"
        aria-label="Abstract background"
      />
      
      <div className="absolute inset-0 z-0 opacity-10">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_30%_20%,rgba(138,99,255,0.4)_0%,transparent_50%)]"></div>
        <div className="absolute bottom-0 right-0 w-full h-full bg-[radial-gradient(circle_at_70%_80%,rgba(58,160,255,0.4)_0%,transparent_50%)]"></div>
      </div>
      
      <div className="container relative z-10 mx-auto px-4 py-16 md:py-24 lg:py-32">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 md:gap-8 items-center">
          <div className="md:col-span-7 text-center md:text-left">
            <Badge variant="outline" className="px-4 py-1.5 mb-6 text-sm font-medium rounded-full bg-white/10 text-white backdrop-blur-sm border border-white/20 hover:bg-white/20">
              {t('hero.badge')}
            </Badge>
            
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-4 md:mb-6">
              <span className="gradient-text" itemProp="headline">{t('hero.title')}</span>
            </h1>
            
            <p className="text-lg md:text-xl mb-6 md:mb-8 gradient-text" itemProp="description">
              {t('hero.subtitle')}
            </p>
            
            <div className="flex flex-col sm:flex-row items-center gap-4 justify-center md:justify-start mb-8 md:mb-10">
              <Button 
                size={isMobile ? "default" : "lg"}
                className="bg-resident-purple hover:bg-resident-purple-dark group w-full sm:w-auto shadow-md hover:shadow-lg transition-all"
                onClick={handleEligibilityCheckOpen}
              >
                {t('hero.cta.check')}
                <ChevronRight className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Button>

              <span className="text-white/80 font-medium">{t('hero.cta.or')}</span>

              <Button 
                size={isMobile ? "default" : "lg"}
                variant="outline"
                className="w-full sm:w-auto bg-white/10 hover:bg-white/20 text-white border-white/20 group shadow-md hover:shadow-lg transition-all"
                onClick={handleStartApplication}
              >
                {t('hero.cta.start')}
                <ArrowRight className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Button>
            </div>
            
            <div className="glass-effect p-3 md:p-4 text-xs sm:text-sm">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 md:gap-3">
                <div className="flex items-center gap-1 md:gap-2">
                  <CheckCircle className="h-4 w-4 md:h-5 md:w-5 text-green-500 flex-shrink-0" />
                  <span className="font-medium line-clamp-1 text-gray-800">{t('hero.trust.novideo')}</span>
                </div>
                <div className="flex items-center gap-1 md:gap-2">
                  <CreditCard className="h-4 w-4 md:h-5 md:w-5 text-resident-blue flex-shrink-0" />
                  <span className="font-medium line-clamp-1 text-gray-800">{t('hero.trust.klarna')}</span>
                </div>
                <div className="flex items-center gap-1 md:gap-2">
                  <ArrowRight className="h-4 w-4 md:h-5 md:w-5 text-green-500 flex-shrink-0" />
                  <span className="font-medium line-clamp-1 text-gray-800">{t('hero.trust.guarantee')}</span>
                </div>
                <div className="flex items-center gap-1 md:gap-2">
                  <CheckSquare className="h-4 w-4 md:h-5 md:w-5 text-resident-blue flex-shrink-0" />
                  <span className="font-medium line-clamp-1 text-gray-800">{t('hero.trust.fees')}</span>
                </div>
                <div className="flex items-center gap-1 md:gap-2 sm:col-span-2 lg:col-span-2">
                  <ShieldCheck className="h-4 w-4 md:h-5 md:w-5 text-green-500 flex-shrink-0" />
                  <span className="font-medium line-clamp-1 text-gray-800">{t('hero.trust.verified')}</span>
                </div>
              </div>
            </div>
          </div>
          <div className="md:col-span-5 mt-8 md:mt-0">
            <div className="glass-effect p-5 md:p-6 lg:p-8 animate-float shadow-lg border-2 border-white/10">
              <h3 className="font-bold text-lg md:text-xl mb-4 text-gray-800">{t('steps.title')}</h3>
              <div className="space-y-4 md:space-y-5">
                <div className="flex items-center">
                  <div className="h-8 w-8 md:h-10 md:w-10 rounded-full bg-resident-purple/20 flex items-center justify-center text-resident-purple font-bold text-sm md:text-base">
                    1
                  </div>
                  <div className="ml-3">
                    <h4 className="font-medium text-sm md:text-base text-gray-800">{t('steps.check.title')}</h4>
                    <p className="text-xs md:text-sm text-gray-500">{t('steps.check.description')}</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <div className="h-8 w-8 md:h-10 md:w-10 rounded-full bg-resident-blue/20 flex items-center justify-center text-resident-blue font-bold text-sm md:text-base">
                    2
                  </div>
                  <div className="ml-3">
                    <h4 className="font-medium text-sm md:text-base text-gray-800">{t('steps.upload.title')}</h4>
                    <p className="text-xs md:text-sm text-gray-500">{t('steps.upload.description')}</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <div className="h-8 w-8 md:h-10 md:w-10 rounded-full bg-resident-purple/20 flex items-center justify-center text-resident-purple font-bold text-sm md:text-base">
                    3
                  </div>
                  <div className="ml-3">
                    <h4 className="font-medium text-sm md:text-base text-gray-800">{t('steps.biometric.title')}</h4>
                    <p className="text-xs md:text-sm text-gray-500">{t('steps.biometric.description')}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <EligibilityCheck 
        isOpen={isEligibilityCheckOpen} 
        onClose={handleEligibilityCheckClose} 
      />

      <CountrySelector
        isOpen={isCountrySelectorOpen}
        onClose={() => setIsCountrySelectorOpen(false)}
        onCountrySelect={handleCountrySelect}
      />
      
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({
        "@context": "https://schema.org",
        "@type": "Service",
        "name": "ResidentIA EU Residence Permit Application",
        "description": "100% online EU residence permit application service with solicitor verification and no video calls.",
        "provider": {
          "@type": "Organization",
          "name": "ResidentIA",
          "url": "https://residentia.app"
        },
        "serviceType": "Immigration Service",
        "areaServed": {
          "@type": "Continent",
          "name": "Europe"
        },
        "hasOfferCatalog": {
          "@type": "OfferCatalog",
          "name": "EU Residence Permits",
          "itemListElement": [
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Temporary Residence Authorization"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Long-term Residence Permit"
              }
            }
          ]
        }
      }) }} />
    </div>
  );
};

export default HeroSection;
