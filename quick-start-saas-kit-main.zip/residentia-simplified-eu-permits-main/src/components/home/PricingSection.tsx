
import { useLanguage } from '@/contexts/LanguageContext';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { CheckCircle } from 'lucide-react';

const PricingSection = () => {
  const { t } = useLanguage();

  const pricingFeatures = [
    t('pricing.fees'),
    t('pricing.ai'),
    t('pricing.legal'),
    t('pricing.upload'),
    t('pricing.scheduling'),
    t('pricing.updates'),
    t('pricing.guarantee'),
    t('pricing.klarna'),
  ];

  return (
    <section className="py-20 bg-resident-purple-light">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="gradient-text">{t('pricing.title')}</span>
          </h2>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto mb-4">
            {t('pricing.subtitle')}
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-xl shadow-lg overflow-hidden">
            <div className="p-8">
              <div className="mb-6">
                <h3 className="text-2xl font-bold mb-4">{t('pricing.included')}</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {pricingFeatures.map((feature, index) => (
                    <div key={index} className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-3 flex-shrink-0 mt-0.5" />
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="text-center">
                <Link to="/signup">
                  <Button 
                    size="lg"
                    className="bg-resident-purple hover:bg-resident-purple-dark"
                  >
                    {t('cta.button')}
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>

        <div className="text-center mt-8">
          <p className="text-gray-700">
            All plans include a 30-day money-back guarantee. Government fees are included in the prices.
          </p>
        </div>
      </div>
    </section>
  );
};

export default PricingSection;
