
import { useLanguage } from '@/contexts/LanguageContext';
import { X } from 'lucide-react';

const ProblemSection = () => {
  const { t } = useLanguage();
  
  const issues = [
    t('problem.issue1'),
    t('problem.issue2'),
    t('problem.issue3'),
    t('problem.issue4'),
    t('problem.issue5'),
    t('problem.issue6'),
    t('problem.issue7')
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              <span className="gradient-text">{t('problem.title')}</span>
            </h2>
            <p className="text-xl text-gray-700">
              {t('problem.intro')}
            </p>
          </div>
          
          <div className="space-y-4">
            {issues.map((issue, index) => (
              <div key={index} className="flex items-start bg-white p-4 rounded-lg shadow-sm">
                <X className="text-red-500 h-5 w-5 mt-0.5 mr-3 flex-shrink-0" />
                <p className="text-gray-800">{issue}</p>
              </div>
            ))}
          </div>
          
          <div className="mt-10 text-center">
            <p className="text-2xl font-bold text-resident-purple">
              {t('problem.solution')}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProblemSection;
