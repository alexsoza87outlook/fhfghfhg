
import { useLanguage } from '@/contexts/LanguageContext';
import { CheckCircle, Upload, ScanFace } from 'lucide-react';

const StepsSection = () => {
  const { t } = useLanguage();

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="gradient-text">{t('steps.title')}</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Complete your application in minutes, not months, with our simplified three-step process.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white rounded-lg p-8 text-center shadow-lg border border-gray-100 hover:border-resident-purple transition-all duration-300">
            <div className="mb-6 flex justify-center">
              <div className="h-16 w-16 bg-resident-purple-light rounded-full flex items-center justify-center">
                <CheckCircle className="h-8 w-8 text-resident-purple" />
              </div>
            </div>
            <h3 className="text-2xl font-bold mb-4">{t('steps.check.title')}</h3>
            <p className="text-gray-600">
              {t('steps.check.description')}
            </p>
          </div>

          <div className="bg-white rounded-lg p-8 text-center shadow-lg border border-gray-100 hover:border-resident-purple transition-all duration-300">
            <div className="mb-6 flex justify-center">
              <div className="h-16 w-16 bg-resident-blue-light rounded-full flex items-center justify-center">
                <Upload className="h-8 w-8 text-resident-blue" />
              </div>
            </div>
            <h3 className="text-2xl font-bold mb-4">{t('steps.upload.title')}</h3>
            <p className="text-gray-600">
              {t('steps.upload.description')}
            </p>
          </div>

          <div className="bg-white rounded-lg p-8 text-center shadow-lg border border-gray-100 hover:border-resident-purple transition-all duration-300">
            <div className="mb-6 flex justify-center">
              <div className="h-16 w-16 bg-resident-purple-light rounded-full flex items-center justify-center">
                <ScanFace className="h-8 w-8 text-resident-purple" />
              </div>
            </div>
            <h3 className="text-2xl font-bold mb-4">{t('steps.biometric.title')}</h3>
            <p className="text-gray-600">
              {t('steps.biometric.description')}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default StepsSection;
