
import { useLanguage } from '@/contexts/LanguageContext';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { Card, CardContent } from "@/components/ui/card";
import { MessageSquare } from "lucide-react";

const TestimonialsCarousel = () => {
  const { t } = useLanguage();
  
  const testimonials = [
    {
      quote: t('testimonials.1.quote'),
      person: t('testimonials.1.person')
    },
    {
      quote: t('testimonials.2.quote'),
      person: t('testimonials.2.person')
    },
    {
      quote: t('testimonials.3.quote'),
      person: t('testimonials.3.person')
    },
    {
      quote: t('testimonials.4.quote'),
      person: t('testimonials.4.person')
    },
    {
      quote: t('testimonials.5.quote'),
      person: t('testimonials.5.person')
    },
    {
      quote: t('testimonials.6.quote'),
      person: t('testimonials.6.person')
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="gradient-text">{t('testimonials.title')}</span>
          </h2>
        </div>
        
        <div className="relative px-12">
          <Carousel
            opts={{
              align: "start",
              loop: true
            }}
            className="w-full"
          >
            <CarouselContent className="-ml-4">
              {testimonials.map((testimonial, index) => (
                <CarouselItem key={index} className="pl-4 md:basis-1/2 lg:basis-1/3">
                  <Card className="border-resident-purple-light">
                    <CardContent className="p-6">
                      <div className="mb-4">
                        <MessageSquare className="h-8 w-8 text-resident-purple" />
                      </div>
                      <blockquote className="mb-4 italic text-gray-700">
                        "{testimonial.quote}"
                      </blockquote>
                      <p className="text-sm font-medium text-gray-900">
                        {testimonial.person}
                      </p>
                    </CardContent>
                  </Card>
                </CarouselItem>
              ))}
            </CarouselContent>
            <CarouselPrevious className="left-0" />
            <CarouselNext className="right-0" />
          </Carousel>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsCarousel;
