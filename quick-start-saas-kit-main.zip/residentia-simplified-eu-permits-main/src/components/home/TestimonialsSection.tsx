
import { useState } from 'react';
import { ChevronLeft, ChevronRight, Star } from 'lucide-react';

interface Testimonial {
  id: number;
  name: string;
  position: string;
  content: string;
  rating: number;
  image: string;
  country: string;
}

const testimonials: Testimonial[] = [
  {
    id: 1,
    name: "Sarah Johnson",
    position: "Software Engineer",
    content: "ResidentIA made my move to Germany incredibly smooth. The AI eligibility checker accurately assessed my situation, and I was able to complete all paperwork in one evening. The legal review gave me peace of mind.",
    rating: 5,
    image: "https://randomuser.me/api/portraits/women/32.jpg",
    country: "United States"
  },
  {
    id: 2,
    name: "Miguel Fernandez",
    position: "Marketing Director",
    content: "After trying to navigate the Spanish residence permit process on my own for months, I found ResidentIA. Within days I had my application submitted correctly. Worth every penny for the time saved and stress avoided.",
    rating: 5,
    image: "https://randomuser.me/api/portraits/men/54.jpg",
    country: "Argentina"
  },
  {
    id: 3,
    name: "Jana Novak",
    position: "Researcher",
    content: "As an academic moving to the Netherlands, I was worried about the paperwork affecting my start date. ResidentIA's process was incredibly fast, and their support team answered all my questions promptly.",
    rating: 4,
    image: "https://randomuser.me/api/portraits/women/68.jpg",
    country: "Czech Republic"
  }
];

const TestimonialsSection = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  
  const nextTestimonial = () => {
    setCurrentIndex((currentIndex + 1) % testimonials.length);
  };
  
  const prevTestimonial = () => {
    setCurrentIndex((currentIndex - 1 + testimonials.length) % testimonials.length);
  };
  
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="gradient-text">What Our Clients Say</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Thousands of people have successfully relocated to the EU with our assistance.
          </p>
        </div>
        
        <div className="relative max-w-4xl mx-auto">
          <div className="bg-white rounded-xl shadow-lg p-8 md:p-12 relative">
            <div className="absolute top-0 right-0 -mt-4 -mr-4 bg-resident-purple text-white rounded-full p-2 shadow-md">
              <div className="flex items-center">
                {Array(5).fill(0).map((_, idx) => (
                  <Star 
                    key={idx}
                    className={`h-4 w-4 ${idx < testimonials[currentIndex].rating ? 'fill-white' : ''}`}
                  />
                ))}
              </div>
            </div>
          
            <div className="flex flex-col md:flex-row gap-6 items-center">
              <div className="flex-shrink-0">
                <div className="h-24 w-24 rounded-full overflow-hidden border-4 border-resident-purple-light">
                  <img
                    src={testimonials[currentIndex].image}
                    alt={testimonials[currentIndex].name}
                    className="h-full w-full object-cover"
                  />
                </div>
              </div>
              
              <div className="flex-grow">
                <blockquote>
                  <p className="text-lg text-gray-700 italic mb-4">
                    "{testimonials[currentIndex].content}"
                  </p>
                  <footer>
                    <div className="font-semibold text-lg">{testimonials[currentIndex].name}</div>
                    <div className="text-gray-600 text-sm">
                      {testimonials[currentIndex].position} | {testimonials[currentIndex].country}
                    </div>
                  </footer>
                </blockquote>
              </div>
            </div>
          </div>
          
          <div className="flex justify-center mt-8 gap-4">
            <button 
              onClick={prevTestimonial}
              aria-label="Previous testimonial"
              className="bg-white rounded-full p-3 shadow hover:shadow-md transition-shadow focus:outline-none focus:ring-2 focus:ring-resident-purple"
            >
              <ChevronLeft className="h-5 w-5 text-resident-purple" />
            </button>
            
            <div className="flex gap-1 items-center">
              {testimonials.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setCurrentIndex(idx)}
                  aria-label={`Go to testimonial ${idx + 1}`}
                  className={`h-2.5 rounded-full transition-all focus:outline-none focus:ring-2 focus:ring-resident-purple ${
                    idx === currentIndex ? 'w-6 bg-resident-purple' : 'w-2.5 bg-gray-300'
                  }`}
                />
              ))}
            </div>
            
            <button 
              onClick={nextTestimonial}
              aria-label="Next testimonial"
              className="bg-white rounded-full p-3 shadow hover:shadow-md transition-shadow focus:outline-none focus:ring-2 focus:ring-resident-purple"
            >
              <ChevronRight className="h-5 w-5 text-resident-purple" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
