
import { useLanguage } from '@/contexts/LanguageContext';
import { Badge, ShieldCheck, Lock } from 'lucide-react';

const TrustGuaranteeSection = () => {
  const { t } = useLanguage();

  return (
    <section className="py-16 bg-resident-purple-light">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="p-8">
            <div className="text-center mb-6">
              <h2 className="text-2xl md:text-3xl font-bold mb-4">
                {t('trust.title')}
              </h2>
              <p className="text-gray-600">
                {t('trust.description')}
              </p>
            </div>
            
            <div className="flex flex-wrap justify-center gap-6 mt-8">
              <div className="flex items-center">
                <Badge className="h-5 w-5 text-resident-purple mr-2" />
                <span className="font-medium">{t('trust.lawyer')}</span>
              </div>
              <div className="flex items-center">
                <Lock className="h-5 w-5 text-resident-blue mr-2" />
                <span className="font-medium">{t('trust.secure')}</span>
              </div>
              <div className="flex items-center">
                <ShieldCheck className="h-5 w-5 text-resident-purple mr-2" />
                <span className="font-medium">{t('trust.transparent')}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TrustGuaranteeSection;
