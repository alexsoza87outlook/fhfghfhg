
import { useLanguage } from '@/contexts/LanguageContext';
import { GlobeIcon } from 'lucide-react';

const WhereWeOperateSection = () => {
  const { t } = useLanguage();
  
  const countries = [
    t('operate.country.spain'),
    t('operate.country.italy'),
    t('operate.country.france'),
    t('operate.country.portugal'),
    t('operate.country.czech'),
    t('operate.country.slovenia'),
    t('operate.country.austria'),
    t('operate.country.greece'),
    t('operate.country.poland'),
    t('operate.country.hungary'),
    t('operate.country.croatia'),
    t('operate.country.slovakia'),
    t('operate.country.romania'),
    t('operate.country.bulgaria')
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="gradient-text">{t('operate.title')}</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            {t('operate.subtitle')}
          </p>
        </div>
        
        <div className="max-w-5xl mx-auto">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {countries.map((country, index) => (
              <div key={index} className="bg-white rounded-lg p-4 shadow-sm flex items-center">
                <GlobeIcon className="h-5 w-5 text-resident-blue mr-2" />
                <span>{country}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default WhereWeOperateSection;
