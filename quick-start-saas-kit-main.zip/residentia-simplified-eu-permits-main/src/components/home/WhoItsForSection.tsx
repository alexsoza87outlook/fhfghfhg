
import { useLanguage } from '@/contexts/LanguageContext';
import { Users, GraduationCap, Flag, HeartHandshake, Briefcase, Palmtree } from 'lucide-react';

const WhoItsForSection = () => {
  const { t } = useLanguage();
  
  const personas = [
    {
      title: t('who.digital'),
      icon: <Users className="h-6 w-6 text-resident-purple" />
    },
    {
      title: t('who.students'),
      icon: <GraduationCap className="h-6 w-6 text-resident-blue" />
    },
    {
      title: t('who.citizens'),
      icon: <Flag className="h-6 w-6 text-resident-purple" />
    },
    {
      title: t('who.family'),
      icon: <HeartHandshake className="h-6 w-6 text-resident-blue" />
    },
    {
      title: t('who.entrepreneurs'),
      icon: <Briefcase className="h-6 w-6 text-resident-purple" />
    },
    {
      title: t('who.retirees'),
      icon: <Palmtree className="h-6 w-6 text-resident-blue" />
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="gradient-text">{t('who.title')}</span>
          </h2>
        </div>
        
        <div className="max-w-5xl mx-auto">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {personas.map((persona, index) => (
              <div key={index} className="bg-white rounded-lg p-6 shadow-md flex items-center border border-gray-100 hover:border-resident-blue transition-colors">
                <div className="mr-4">
                  {persona.icon}
                </div>
                <h3 className="font-medium">{persona.title}</h3>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default WhoItsForSection;
