
import { useLanguage } from '@/contexts/LanguageContext';
import FooterAbout from './footer/FooterAbout';
import FooterNavLinks from './footer/FooterNavLinks';
import FooterServiceLinks from './footer/FooterServiceLinks';
import FooterContact from './footer/FooterContact';
import FooterBottom from './footer/FooterBottom';

const Footer = () => {
  const { t } = useLanguage();

  return (
    <footer className="bg-resident-gray-dark text-white pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <FooterAbout />
          <FooterNavLinks />
          <FooterServiceLinks />
          <FooterContact />
        </div>
        <FooterBottom />
      </div>
    </footer>
  );
};

export default Footer;
