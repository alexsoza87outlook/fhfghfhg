import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"
import { getInitials } from '@/lib/utils';

const Header = () => {
  const { user, profile, logout } = useAuth();
  const { t, language, setLanguage } = useLanguage();
  const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  const renderAuthButtons = () => {
    if (user) {
      return null;
    }

    return (
      <>
        <li>
          <Link to="/login" className="hover:text-resident-purple transition-colors">{t('nav.login')}</Link>
        </li>
        <li>
          <Link to="/signup" className="bg-resident-purple text-white py-2 px-4 rounded hover:bg-resident-purple-dark transition-colors">{t('nav.signup')}</Link>
        </li>
      </>
    );
  };

  const renderLanguageSwitcher = () => {
    const handleLanguageChange = (newLanguage: 'en' | 'es') => {
      setLanguage(newLanguage);
      setIsMenuOpen(false);
    };

    return (
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" className="relative h-10 w-10 rounded-full">
            {language.toUpperCase()}
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="w-40">
          <DropdownMenuLabel>Select Language</DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={() => handleLanguageChange('en')}>
            English
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => handleLanguageChange('es')}>
            Español
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    );
  };

  const renderUserMenu = () => {
    return (
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" className="relative h-10 w-10 rounded-full">
            <Avatar>
              <AvatarImage src="/placeholder.svg" alt={profile?.full_name || user?.email} />
              <AvatarFallback>{getInitials(profile?.full_name || user?.email || '')}</AvatarFallback>
            </Avatar>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="w-40">
          <DropdownMenuLabel>{profile?.full_name || user?.email}</DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={handleLogout}>
            Logout
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    );
  };

  return (
    <header className="bg-primary-dark text-white py-4 shadow-md">
      <div className="container mx-auto px-4 flex items-center justify-between">
        <Link to="/" className="text-2xl font-bold text-white">ResidentIA</Link>

        <nav className="hidden md:flex items-center space-x-6">
          <Link to="/" className="hover:text-primary-lighter transition-colors">{t('nav.home')}</Link>
          <Link to="/services" className="hover:text-primary-lighter transition-colors">{t('nav.services')}</Link>
          <Link to="/pricing" className="hover:text-primary-lighter transition-colors">{t('nav.pricing')}</Link>
          <Link to="/about" className="hover:text-primary-lighter transition-colors">{t('nav.about')}</Link>
          <Link to="/contact" className="hover:text-primary-lighter transition-colors">{t('nav.contact')}</Link>
        </nav>

        <div className="hidden md:flex items-center space-x-4">
          {renderAuthButtons()}
          {renderLanguageSwitcher()}
          {user && renderUserMenu()}
        </div>

        {/* Mobile Menu Button */}
        <div className="md:hidden">
          <button onClick={toggleMenu} className="text-white hover:text-primary-lighter focus:outline-none">
            <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16"></path>
            </svg>
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-primary-dark py-2 px-4">
          <nav className="flex flex-col space-y-4">
            <Link to="/" className="text-white hover:text-primary-lighter transition-colors">{t('nav.home')}</Link>
            <Link to="/services" className="text-white hover:text-primary-lighter transition-colors">{t('nav.services')}</Link>
            <Link to="/pricing" className="text-white hover:text-primary-lighter transition-colors">{t('nav.pricing')}</Link>
            <Link to="/about" className="text-white hover:text-primary-lighter transition-colors">{t('nav.about')}</Link>
            <Link to="/contact" className="text-white hover:text-primary-lighter transition-colors">{t('nav.contact')}</Link>
            {renderAuthButtons()}
            {renderLanguageSwitcher()}
            {user && renderUserMenu()}
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;
