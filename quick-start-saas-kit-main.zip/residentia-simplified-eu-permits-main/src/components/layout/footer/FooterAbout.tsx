
import SocialLinks from './SocialLinks';

const FooterAbout = () => {
  return (
    <div>
      <h3 className="text-2xl font-bold mb-4 gradient-text">ResidentIA</h3>
      <p className="text-gray-300 mb-4">
        Simplifying EU residence permits and authorization applications with AI-assisted technology and expert legal support.
      </p>
      <SocialLinks />
    </div>
  );
};

export default FooterAbout;
