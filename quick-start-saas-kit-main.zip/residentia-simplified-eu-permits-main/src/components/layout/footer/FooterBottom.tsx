
import { Link } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';

const FooterBottom = () => {
  const { t } = useLanguage();
  const year = new Date().getFullYear();
  
  return (
    <div className="border-t border-gray-700 pt-8">
      <div className="flex flex-col md:flex-row justify-between">
        <p className="text-gray-400 text-sm mb-4 md:mb-0">
          &copy; {year} ResidentIA. {t('footer.rightsReserved')}
        </p>
        <div className="flex space-x-4">
          <Link to="/privacy-policy" className="text-gray-400 text-sm hover:text-resident-purple transition-colors">
            {t('footer.privacyPolicy')}
          </Link>
          <Link to="/terms-of-service" className="text-gray-400 text-sm hover:text-resident-purple transition-colors">
            {t('footer.termsOfService')}
          </Link>
          <Link to="/cookies" className="text-gray-400 text-sm hover:text-resident-purple transition-colors">
            {t('footer.cookies')}
          </Link>
        </div>
      </div>
    </div>
  );
};

export default FooterBottom;
