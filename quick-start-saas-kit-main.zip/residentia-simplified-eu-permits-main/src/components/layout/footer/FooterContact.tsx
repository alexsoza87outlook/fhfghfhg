
import { Link } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';

const FooterContact = () => {
  const { t } = useLanguage();
  
  return (
    <div>
      <h4 className="text-lg font-semibold mb-4">{t('footer.contact')}</h4>
      <address className="not-italic text-gray-300 space-y-2">
        <p>123 Main Street</p>
        <p>Barcelona, Spain 08001</p>
        <p>Email: info@residentia.com</p>
        <p>Phone: +34 91 234 5678</p>
      </address>
      
      <div className="mt-4 pt-4 border-t border-gray-700">
        <h5 className="text-sm font-semibold mb-2">{t('footer.solicitorSection')}</h5>
        <ul className="space-y-1">
          <li>
            <Link to="/solicitor-login" className="text-gray-300 hover:text-resident-purple transition-colors text-sm">
              {t('auth.solicitorLogin')}
            </Link>
          </li>
          <li>
            <Link to="/solicitor-signup" className="text-gray-300 hover:text-resident-purple transition-colors text-sm">
              {t('auth.solicitorSignup')}
            </Link>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default FooterContact;
