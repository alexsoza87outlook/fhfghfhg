
import { Link } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';

const FooterNavLinks = () => {
  const { t } = useLanguage();
  
  return (
    <div>
      <h4 className="text-lg font-semibold mb-4">{t('footer.pages')}</h4>
      <ul className="space-y-2">
        <li>
          <Link to="/" className="text-gray-300 hover:text-resident-purple transition-colors">
            {t('nav.home')}
          </Link>
        </li>
        <li>
          <Link to="/services" className="text-gray-300 hover:text-resident-purple transition-colors">
            {t('nav.services')}
          </Link>
        </li>
        <li>
          <Link to="/pricing" className="text-gray-300 hover:text-resident-purple transition-colors">
            {t('nav.pricing')}
          </Link>
        </li>
        <li>
          <Link to="/about" className="text-gray-300 hover:text-resident-purple transition-colors">
            {t('nav.about')}
          </Link>
        </li>
        <li>
          <Link to="/contact" className="text-gray-300 hover:text-resident-purple transition-colors">
            {t('nav.contact')}
          </Link>
        </li>
      </ul>
    </div>
  );
};

export default FooterNavLinks;
