
import { Link } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';

const FooterServiceLinks = () => {
  const { t } = useLanguage();
  
  return (
    <div>
      <h4 className="text-lg font-semibold mb-4">{t('footer.services')}</h4>
      <ul className="space-y-2">
        <li>
          <Link to="/services/work-permits" className="text-gray-300 hover:text-resident-purple transition-colors">
            {t('services.workPermits')}
          </Link>
        </li>
        <li>
          <Link to="/services/family-reunification" className="text-gray-300 hover:text-resident-purple transition-colors">
            {t('services.familyReunification')}
          </Link>
        </li>
        <li>
          <Link to="/services/student-visas" className="text-gray-300 hover:text-resident-purple transition-colors">
            {t('services.studentVisas')}
          </Link>
        </li>
        <li>
          <Link to="/services/blue-card" className="text-gray-300 hover:text-resident-purple transition-colors">
            {t('services.blueCard')}
          </Link>
        </li>
        <li>
          <Link to="/services/citizenship" className="text-gray-300 hover:text-resident-purple transition-colors">
            {t('services.citizenship')}
          </Link>
        </li>
      </ul>
      
      {/* Admin section */}
      <h4 className="text-lg font-semibold mt-6 mb-4">{t('admin.footer.adminSection')}</h4>
      <ul className="space-y-2">
        <li>
          <Link to="/admin/login" className="text-gray-300 hover:text-resident-purple transition-colors">
            {t('admin.footer.adminLogin')}
          </Link>
        </li>
        <li>
          <Link to="/admin/register" className="text-gray-300 hover:text-resident-purple transition-colors">
            {t('admin.footer.adminRegister')}
          </Link>
        </li>
      </ul>
    </div>
  );
};

export default FooterServiceLinks;
