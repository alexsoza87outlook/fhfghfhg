
import { Facebook, Twitter, Instagram, Linkedin } from 'lucide-react';

const SocialLinks = () => {
  return (
    <div className="flex space-x-4">
      <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="text-gray-300 hover:text-resident-purple transition-colors">
        <Facebook className="h-5 w-5" />
      </a>
      <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="text-gray-300 hover:text-resident-purple transition-colors">
        <Twitter className="h-5 w-5" />
      </a>
      <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="text-gray-300 hover:text-resident-purple transition-colors">
        <Instagram className="h-5 w-5" />
      </a>
      <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="text-gray-300 hover:text-resident-purple transition-colors">
        <Linkedin className="h-5 w-5" />
      </a>
    </div>
  );
};

export default SocialLinks;
