
import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useLanguage } from '@/contexts/LanguageContext';
import { Button } from '@/components/ui/button';
import { MessageSquareIcon } from 'lucide-react';

interface EligibilityQuestionnaireProps {
  isOpen: boolean;
  onClose: () => void;
  cardType: string;
}

const EligibilityQuestionnaire: React.FC<EligibilityQuestionnaireProps> = ({ isOpen, onClose, cardType }) => {
  const { t } = useLanguage();

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold">
            {t('residence.chatbotTitle')}
          </DialogTitle>
        </DialogHeader>

        <div className="flex flex-col space-y-4">
          <div className="bg-gray-100 p-4 rounded-lg">
            <div className="flex gap-3">
              <MessageSquareIcon className="w-6 h-6 text-resident-purple" />
              <div>
                <p className="text-sm">{t('residence.chatbotDescription')}</p>
              </div>
            </div>
          </div>

          <div className="bg-resident-purple/10 p-4 rounded-lg border border-resident-purple/20">
            <p className="text-sm italic">
              {t(`residence.${cardType}.title`)} - {t('residence.chatbotDescription')}
            </p>
          </div>

          <div className="flex justify-end">
            <Button onClick={onClose}>{t('residence.close')}</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default EligibilityQuestionnaire;
