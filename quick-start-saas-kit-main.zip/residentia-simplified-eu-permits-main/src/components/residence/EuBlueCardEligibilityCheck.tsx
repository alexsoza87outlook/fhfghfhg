
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useLanguage } from '@/contexts/LanguageContext';
import { Button } from '@/components/ui/button';
import { CheckIcon, MessageSquareIcon } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface EuBlueCardEligibilityCheckProps {
  isOpen: boolean;
  onClose: () => void;
}

const EuBlueCardEligibilityCheck: React.FC<EuBlueCardEligibilityCheckProps> = ({ isOpen, onClose }) => {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<boolean[]>([]);
  const [completed, setCompleted] = useState(false);

  const questions = [
    t('residence.euBlueCard.question1'),
    t('residence.euBlueCard.question2'),
    t('residence.euBlueCard.question3'),
    t('residence.euBlueCard.question4'),
    t('residence.euBlueCard.question5'),
    t('residence.euBlueCard.question6'),
    t('residence.euBlueCard.question7'),
    t('residence.euBlueCard.question8'),
  ];

  const handleAnswer = (answer: boolean) => {
    const newAnswers = [...answers, answer];
    setAnswers(newAnswers);

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setCompleted(true);
    }
  };

  const handleSignUp = () => {
    navigate('/signup');
    onClose();
  };

  const allAnswersAreYes = answers.every(answer => answer === true);

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold">
            {t('residence.chatbotTitle')}
          </DialogTitle>
        </DialogHeader>

        <div className="flex flex-col space-y-4">
          <div className="bg-gray-100 p-4 rounded-lg">
            <div className="flex gap-3">
              <MessageSquareIcon className="w-6 h-6 text-resident-purple" />
              <div>
                <p className="text-sm">{t('residence.chatbotDescription')}</p>
              </div>
            </div>
          </div>

          {!completed ? (
            <div className="bg-resident-purple/10 p-4 rounded-lg border border-resident-purple/20">
              <p className="text-sm mb-4">{questions[currentQuestion]}</p>
              <div className="flex justify-between mt-4">
                <Button 
                  variant="outline" 
                  onClick={() => handleAnswer(false)}
                >
                  {t('residence.euBlueCard.answerNo')}
                </Button>
                <Button 
                  onClick={() => handleAnswer(true)}
                >
                  {t('residence.euBlueCard.answerYes')}
                </Button>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center p-4">
              {allAnswersAreYes ? (
                <>
                  <div className="bg-green-100 text-green-800 px-4 py-2 rounded-full flex items-center mb-4">
                    <CheckIcon className="w-5 h-5 mr-1" />
                    <span className="font-semibold">{t('residence.euBlueCard.verified')}</span>
                  </div>
                  <Button 
                    onClick={handleSignUp}
                    className="w-full"
                  >
                    {t('residence.euBlueCard.signUp')}
                  </Button>
                </>
              ) : (
                <p className="text-sm text-center">
                  Based on your answers, you may not be eligible for the EU Blue Card. 
                  Please review the requirements or contact us for more information.
                </p>
              )}
            </div>
          )}

          <div className="flex justify-end">
            {!completed && (
              <Button onClick={onClose} variant="outline">{t('residence.close')}</Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default EuBlueCardEligibilityCheck;
