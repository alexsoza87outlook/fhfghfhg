
import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { useLanguage } from '@/contexts/LanguageContext';
import { Button } from '@/components/ui/button';
import ContactForm from './ContactForm';

interface InfoDialogProps {
  isOpen: boolean;
  onClose: () => void;
  cardType: string;
}

const InfoDialog: React.FC<InfoDialogProps> = ({ isOpen, onClose, cardType }) => {
  const { t } = useLanguage();

  const showContactForm = [
    'euBlueCard',
    'studentStay',
    'temporaryWorkInitial',
    'remoteWork',
    'familyReunificationInitial'
  ].includes(cardType);

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold mb-2">
            {t(`residence.${cardType}.title`)}
          </DialogTitle>
          <DialogDescription className="whitespace-pre-line">
            {t(`residence.${cardType}.moreInfo`)}
          </DialogDescription>
        </DialogHeader>

        {showContactForm && (
          <div className="mt-4">
            <p className="text-sm text-gray-700 mb-4">
              {t(`residence.${cardType}.contactUsText`)}
            </p>
            <ContactForm cardType={cardType} />
          </div>
        )}

        <div className="flex justify-end mt-4">
          <Button onClick={onClose}>{t('residence.close')}</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default InfoDialog;
