
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/contexts/LanguageContext';
import { useNavigate } from 'react-router-dom';
import { CheckIcon, XIcon, MessageSquareIcon } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

interface EligibilityQuestion {
  key: string;
  answer: boolean | null;
}

interface NonLucrativeEligibilityCheckProps {
  isOpen: boolean;
  onClose: () => void;
}

const NonLucrativeEligibilityCheck: React.FC<NonLucrativeEligibilityCheckProps> = ({ isOpen, onClose }) => {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const { toast } = useToast();

  // Define all the required questions
  const [questions] = useState<EligibilityQuestion[]>([
    { key: 'nonEuCitizen', answer: null },
    { key: 'over18', answer: null },
    { key: 'outsideSpain', answer: null },
    { key: 'cleanRecord', answer: null },
    { key: 'sufficientFunds', answer: null },
    { key: 'additionalFunds', answer: null },
    { key: 'proveIncome', answer: null },
    { key: 'healthInsurance', answer: null },
    { key: 'validPassport', answer: null },
    { key: 'medicalCertificate', answer: null },
    { key: 'spanishAddress', answer: null },
    { key: 'noWork', answer: null },
    { key: 'understandRules', answer: null },
    { key: 'stayInSpain', answer: null },
  ]);

  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [completed, setCompleted] = useState(false);
  const [qualified, setQualified] = useState(false);

  // Handle user's answer to current question
  const handleAnswer = (answer: boolean) => {
    // Update the answer for the current question
    const updatedQuestions = [...questions];
    updatedQuestions[currentQuestionIndex].answer = answer;
    
    // Move to the next question or finish if all answered
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      // Check if all questions are answered with 'yes'
      const isQualified = updatedQuestions.every(q => q.answer === true);
      setQualified(isQualified);
      setCompleted(true);
    }
  };

  // Reset the questionnaire
  const resetQuestionnaire = () => {
    const resetQuestions = questions.map(q => ({ ...q, answer: null }));
    setCurrentQuestionIndex(0);
    setCompleted(false);
    setQualified(false);
  };

  // Navigate to signup page
  const handleSignUp = () => {
    navigate('/signup');
    onClose();
    toast({
      title: t('residence.nonLucrative.eligibilityCheck.qualified'),
      description: t('residence.nonLucrative.eligibilityCheck.redirectingToSignup'),
    });
  };

  // Handle closing the dialog
  const handleCloseDialog = () => {
    if (completed) {
      resetQuestionnaire();
    }
    onClose();
  };

  // Get the current question text
  const getCurrentQuestionText = () => {
    if (currentQuestionIndex < questions.length) {
      return t(`residence.nonLucrative.eligibilityCheck.questions.${questions[currentQuestionIndex].key}`);
    }
    return '';
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && handleCloseDialog()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold">
            {t('residence.chatbotTitle')}
          </DialogTitle>
        </DialogHeader>

        <div className="flex flex-col space-y-4 p-1">
          {!completed ? (
            <div className="bg-gray-50 rounded-lg p-4 shadow-sm border">
              <div className="flex items-start gap-3 mb-4">
                <MessageSquareIcon className="w-5 h-5 text-resident-purple mt-1" />
                <div className="flex-1">
                  <p className="font-medium text-sm">{t('residence.nonLucrative.title')}</p>
                  <p className="text-sm text-gray-600">{t('residence.nonLucrative.eligibilityCheck.instruction')}</p>
                </div>
              </div>
              
              <div className="mb-4 mt-6 bg-white p-4 rounded-md border">
                <p className="text-sm">{getCurrentQuestionText()}</p>
              </div>

              <div className="flex gap-3 justify-end mt-4">
                <Button 
                  onClick={() => handleAnswer(false)}
                  variant="outline"
                  className="px-6"
                >
                  <XIcon className="w-4 h-4 mr-2" />
                  {t('residence.nonLucrative.eligibilityCheck.no')}
                </Button>
                <Button 
                  onClick={() => handleAnswer(true)}
                  className="px-6 bg-resident-purple hover:bg-resident-purple/90"
                >
                  <CheckIcon className="w-4 h-4 mr-2" />
                  {t('residence.nonLucrative.eligibilityCheck.yes')}
                </Button>
              </div>

              <div className="flex justify-between mt-6">
                <p className="text-xs text-gray-500">
                  {t('residence.nonLucrative.eligibilityCheck.progress', { 
                    current: (currentQuestionIndex + 1).toString(), 
                    total: questions.length.toString() 
                  })}
                </p>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center text-center p-6 bg-gray-50 rounded-lg">
              {qualified ? (
                <>
                  <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mb-4">
                    <CheckIcon className="w-8 h-8 text-green-600" />
                  </div>
                  <h3 className="text-xl font-bold text-green-700 mb-2">
                    {t('residence.nonLucrative.eligibilityCheck.qualifiedTitle')}
                  </h3>
                  <p className="text-gray-600 mb-6">
                    {t('residence.nonLucrative.eligibilityCheck.qualifiedMessage')}
                  </p>
                  <div className="flex gap-3">
                    <Button 
                      onClick={handleSignUp}
                      className="bg-resident-purple hover:bg-resident-purple/90"
                    >
                      {t('residence.nonLucrative.eligibilityCheck.signUp')}
                    </Button>
                    <Button 
                      onClick={handleCloseDialog}
                      variant="outline"
                    >
                      {t('residence.close')}
                    </Button>
                  </div>
                </>
              ) : (
                <>
                  <div className="w-16 h-16 rounded-full bg-amber-100 flex items-center justify-center mb-4">
                    <XIcon className="w-8 h-8 text-amber-600" />
                  </div>
                  <h3 className="text-xl font-bold text-amber-700 mb-2">
                    {t('residence.nonLucrative.eligibilityCheck.notQualifiedTitle')}
                  </h3>
                  <p className="text-gray-600 mb-6">
                    {t('residence.nonLucrative.eligibilityCheck.notQualifiedMessage')}
                  </p>
                  <div className="flex gap-3">
                    <Button 
                      onClick={resetQuestionnaire}
                      className="bg-resident-purple hover:bg-resident-purple/90"
                    >
                      {t('residence.nonLucrative.eligibilityCheck.tryAgain')}
                    </Button>
                    <Button 
                      onClick={handleCloseDialog}
                      variant="outline"
                    >
                      {t('residence.close')}
                    </Button>
                  </div>
                </>
              )}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default NonLucrativeEligibilityCheck;
