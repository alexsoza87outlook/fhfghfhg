
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/contexts/LanguageContext';
import { InfoIcon, CheckIcon } from 'lucide-react';

interface ResidenceCardProps {
  cardType: string;
  onCheckEligibility: () => void;
  onMoreInfo: () => void;
}

const ResidenceCard: React.FC<ResidenceCardProps> = ({ cardType, onCheckEligibility, onMoreInfo }) => {
  const { t } = useLanguage();

  const getRequirements = () => {
    const requirements = [
      t(`residence.${cardType}.requirement1`),
      t(`residence.${cardType}.requirement2`),
      t(`residence.${cardType}.requirement3`),
    ];
    
    return requirements;
  };

  return (
    <Card className="w-full shadow-md hover:shadow-lg transition-shadow duration-300">
      <CardContent className="p-6">
        <h3 className="text-lg font-bold mb-2">{t(`residence.${cardType}.title`)}</h3>
        <p className="text-gray-600 mb-4">{t(`residence.${cardType}.description`)}</p>
        
        <div className="mb-6">
          <h4 className="font-semibold text-sm mb-2">{t('residence.mainRequirements')}</h4>
          <ul className="list-disc list-inside text-sm text-gray-700 space-y-1">
            {getRequirements().map((req, index) => (
              <li key={index}>{req}</li>
            ))}
          </ul>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-2 mt-4">
          <Button 
            onClick={onCheckEligibility} 
            variant="default"
            className="bg-resident-purple hover:bg-resident-purple/90"
          >
            <CheckIcon className="w-4 h-4 mr-2" />
            {t('residence.checkEligibility')}
          </Button>
          <Button 
            onClick={onMoreInfo} 
            variant="outline"
          >
            <InfoIcon className="w-4 h-4 mr-2" />
            {t('residence.moreInformation')}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default ResidenceCard;
