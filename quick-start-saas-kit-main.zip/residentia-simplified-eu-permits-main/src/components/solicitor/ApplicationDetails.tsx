
import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { Application, ApplicationDocument, StatusUpdate } from '@/types/application';
import { getApplicationById, getStatusUpdates, getDocumentUrl } from '@/services/application';
import MainLayout from '@/components/layout/MainLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogTrigger, DialogContent } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Loader2, ArrowLeft, Download, Clock, FileText, History } from 'lucide-react';
import ApplicationStatusUpdate from './ApplicationStatusUpdate';
import { useToast } from '@/components/ui/use-toast';
import { format } from 'date-fns';

const ApplicationDetails = () => {
  const { applicationId } = useParams<{ applicationId: string }>();
  const { user, profile, isAuthenticated, isLoading: authLoading } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [application, setApplication] = useState<Application | null>(null);
  const [statusUpdates, setStatusUpdates] = useState<StatusUpdate[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState('details');

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      navigate('/login');
      return;
    }

    if (!authLoading && profile?.user_type !== 'solicitor') {
      navigate('/dashboard');
      return;
    }
  }, [isAuthenticated, authLoading, navigate, profile]);

  useEffect(() => {
    if (applicationId) {
      loadApplicationData();
    }
  }, [applicationId]);

  const loadApplicationData = async () => {
    if (!applicationId) return;

    setIsLoading(true);
    try {
      // Load application data
      const applicationData = await getApplicationById(applicationId);
      setApplication(applicationData);

      // Load status updates
      const statusUpdatesData = await getStatusUpdates(applicationId);
      setStatusUpdates(statusUpdatesData);

    } catch (error) {
      console.error('Error loading application data:', error);
      toast({
        title: 'Error',
        description: 'Failed to load application data',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleDocumentDownload = async (document: ApplicationDocument) => {
    try {
      const url = await getDocumentUrl(document.file_path);
      window.open(url, '_blank');
    } catch (error) {
      console.error('Error downloading document:', error);
      toast({
        title: 'Error',
        description: 'Failed to download document',
        variant: 'destructive',
      });
    }
  };

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'draft': return 'bg-gray-200 text-gray-800 hover:bg-gray-300';
      case 'submitted': return 'bg-blue-100 text-blue-800 hover:bg-blue-200';
      case 'under_review': return 'bg-yellow-100 text-yellow-800 hover:bg-yellow-200';
      case 'approved': return 'bg-green-100 text-green-800 hover:bg-green-200';
      case 'rejected': return 'bg-red-100 text-red-800 hover:bg-red-200';
      case 'completed': return 'bg-purple-100 text-purple-800 hover:bg-purple-200';
      case 'received': return 'bg-indigo-100 text-indigo-800 hover:bg-indigo-200';
      case 'additional_docs_required': return 'bg-amber-100 text-amber-800 hover:bg-amber-200';
      default: return 'bg-gray-100 text-gray-800 hover:bg-gray-200';
    }
  };

  const formatDate = (dateString?: string) => {
    if (!dateString) return 'N/A';
    try {
      return format(new Date(dateString), 'PPP');
    } catch (error) {
      return dateString;
    }
  };

  if (authLoading || isLoading) {
    return (
      <MainLayout>
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center justify-center min-h-[60vh]">
            <Loader2 className="h-12 w-12 animate-spin" />
          </div>
        </div>
      </MainLayout>
    );
  }

  if (!application) {
    return (
      <MainLayout>
        <div className="container mx-auto px-4 py-8">
          <div className="flex flex-col items-center justify-center min-h-[60vh] text-center">
            <h2 className="text-2xl font-bold mb-4">Application Not Found</h2>
            <p className="mb-6">The application you are looking for does not exist or you do not have permission to view it.</p>
            <Button onClick={() => navigate('/solicitor/dashboard')}>
              <ArrowLeft className="mr-2 h-4 w-4" /> Back to Dashboard
            </Button>
          </div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-8">
        {/* Header with back button and status update button */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
          <div className="flex items-center">
            <Button 
              variant="outline"
              className="mr-4"
              onClick={() => navigate('/solicitor/dashboard')}
            >
              <ArrowLeft className="mr-2 h-4 w-4" /> Back
            </Button>
            <div>
              <h1 className="text-2xl font-bold">{t('solicitor.applicationDetails.title')}</h1>
              <p className="text-muted-foreground">
                {application.user_profile?.full_name} - {application.id}
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Badge className={getStatusBadgeClass(application.status)}>
              {application.status}
            </Badge>
            <Dialog>
              <DialogTrigger asChild>
                <Button>
                  {t('solicitor.dashboard.updateStatus')}
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <ApplicationStatusUpdate 
                  application={application} 
                  onSuccess={loadApplicationData} 
                />
              </DialogContent>
            </Dialog>
          </div>
        </div>
        
        {/* Main content tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="details">
              <FileText className="mr-2 h-4 w-4" />
              {t('solicitor.applicationDetails.details')}
            </TabsTrigger>
            <TabsTrigger value="history">
              <History className="mr-2 h-4 w-4" />
              {t('solicitor.applicationDetails.history')}
            </TabsTrigger>
          </TabsList>
          
          {/* Details Tab */}
          <TabsContent value="details" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Personal Details */}
              <Card>
                <CardHeader>
                  <CardTitle>{t('solicitor.applicationDetails.personalDetails')}</CardTitle>
                  <CardDescription>
                    {t('solicitor.applicationDetails.applicantInformation')}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {application.personal_details ? (
                    <div className="space-y-4">
                      <div>
                        <h3 className="text-sm font-medium text-muted-foreground mb-1">
                          {t('application.personalDetails.name')}
                        </h3>
                        <p>
                          {application.personal_details.first_name} {application.personal_details.first_last_name} {application.personal_details.second_last_name}
                        </p>
                      </div>
                      
                      <div>
                        <h3 className="text-sm font-medium text-muted-foreground mb-1">
                          {t('application.personalDetails.contact')}
                        </h3>
                        <p>{application.personal_details.email}</p>
                        <p>{application.personal_details.phone}</p>
                      </div>
                      
                      <div>
                        <h3 className="text-sm font-medium text-muted-foreground mb-1">
                          {t('application.personalDetails.address')}
                        </h3>
                        <p>{application.personal_details.address_line1}</p>
                        {application.personal_details.address_line2 && (
                          <p>{application.personal_details.address_line2}</p>
                        )}
                        <p>
                          {application.personal_details.city}, {application.personal_details.state} {application.personal_details.postal_code}
                        </p>
                        <p>{application.personal_details.country}</p>
                      </div>
                      
                      <div>
                        <h3 className="text-sm font-medium text-muted-foreground mb-1">
                          {t('application.personalDetails.identification')}
                        </h3>
                        <p>
                          <span className="font-medium">
                            {t('application.personalDetails.passportNumber')}:
                          </span>{' '}
                          {application.personal_details.passport_number || 'N/A'}
                        </p>
                        <p>
                          <span className="font-medium">NIE:</span>{' '}
                          {application.personal_details.nie || 'N/A'}
                        </p>
                      </div>
                      
                      <div>
                        <h3 className="text-sm font-medium text-muted-foreground mb-1">
                          {t('application.personalDetails.birthDetails')}
                        </h3>
                        <p>
                          <span className="font-medium">
                            {t('application.personalDetails.dateOfBirth')}:
                          </span>{' '}
                          {formatDate(application.personal_details.date_of_birth)}
                        </p>
                        <p>
                          <span className="font-medium">
                            {t('application.personalDetails.placeOfBirth')}:
                          </span>{' '}
                          {application.personal_details.place_of_birth || 'N/A'}, {application.personal_details.country_of_birth || 'N/A'}
                        </p>
                        <p>
                          <span className="font-medium">
                            {t('application.personalDetails.nationality')}:
                          </span>{' '}
                          {application.personal_details.nationality || 'N/A'}
                        </p>
                      </div>
                    </div>
                  ) : (
                    <p className="text-muted-foreground">
                      {t('solicitor.applicationDetails.noPersonalDetails')}
                    </p>
                  )}
                </CardContent>
              </Card>

              {/* Application Details */}
              <Card>
                <CardHeader>
                  <CardTitle>{t('solicitor.applicationDetails.applicationInfo')}</CardTitle>
                  <CardDescription>
                    {t('solicitor.applicationDetails.status')}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground mb-1">
                        {t('solicitor.applicationDetails.dates')}
                      </h3>
                      <p>
                        <span className="font-medium">
                          {t('solicitor.applicationDetails.created')}:
                        </span>{' '}
                        {formatDate(application.created_at)}
                      </p>
                      {application.submitted_at && (
                        <p>
                          <span className="font-medium">
                            {t('solicitor.applicationDetails.submitted')}:
                          </span>{' '}
                          {formatDate(application.submitted_at)}
                        </p>
                      )}
                      <p>
                        <span className="font-medium">
                          {t('solicitor.applicationDetails.updated')}:
                        </span>{' '}
                        {formatDate(application.updated_at)}
                      </p>
                    </div>
                    
                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground mb-1">
                        {t('solicitor.applicationDetails.currentStatus')}
                      </h3>
                      <p>
                        <span className="font-medium">
                          {t('solicitor.applicationDetails.status')}:
                        </span>{' '}
                        <Badge className={getStatusBadgeClass(application.status)}>
                          {application.status}
                        </Badge>
                      </p>
                      <p>
                        <span className="font-medium">
                          {t('solicitor.applicationDetails.step')}:
                        </span>{' '}
                        {application.current_step}
                      </p>
                      <p>
                        <span className="font-medium">
                          {t('solicitor.applicationDetails.payment')}:
                        </span>{' '}
                        <Badge 
                          variant={application.payment_status === 'completed' ? 'default' : 'outline'}
                          className="ml-1"
                        >
                          {application.payment_status}
                        </Badge>
                      </p>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground mb-1">
                        {t('solicitor.applicationDetails.documents')}
                      </h3>
                      {application.documents && application.documents.length > 0 ? (
                        <div className="space-y-2">
                          {application.documents.map((doc) => (
                            <div 
                              key={doc.id} 
                              className="flex items-center justify-between p-2 bg-muted rounded-md"
                            >
                              <div>
                                <p className="font-medium">{doc.document_type}</p>
                                <p className="text-xs text-muted-foreground">
                                  {doc.original_filename}
                                </p>
                              </div>
                              <Button 
                                variant="ghost" 
                                size="sm"
                                onClick={() => handleDocumentDownload(doc)}
                              >
                                <Download className="h-4 w-4" />
                              </Button>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-muted-foreground">
                          {t('solicitor.applicationDetails.noDocuments')}
                        </p>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          {/* History Tab */}
          <TabsContent value="history" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>{t('solicitor.applicationDetails.statusHistory')}</CardTitle>
                <CardDescription>
                  {t('solicitor.applicationDetails.historyDescription')}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[400px] pr-4">
                  <div className="space-y-4">
                    {statusUpdates.length > 0 ? (
                      statusUpdates.map((update, index) => (
                        <div key={update.id} className="relative pb-8">
                          {/* Timeline connector */}
                          {index < statusUpdates.length - 1 && (
                            <div className="absolute left-4 top-10 bottom-0 w-0.5 bg-muted" />
                          )}
                          
                          <div className="flex gap-4">
                            {/* Timeline circle */}
                            <div className="flex-shrink-0 mt-1">
                              <div className="p-1 rounded-full bg-primary">
                                <Clock className="h-6 w-6 text-primary-foreground" />
                              </div>
                            </div>
                            
                            {/* Content */}
                            <div className="flex-grow">
                              <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center">
                                <Badge className={getStatusBadgeClass(update.status)}>
                                  {update.status}
                                </Badge>
                                <span className="text-sm text-muted-foreground mt-1 sm:mt-0">
                                  {formatDate(update.created_at)}
                                </span>
                              </div>
                              
                              {update.comment && (
                                <p className="mt-2 text-sm">{update.comment}</p>
                              )}
                            </div>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-8 text-muted-foreground">
                        <p>{t('solicitor.applicationDetails.noStatusUpdates')}</p>
                      </div>
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
};

export default ApplicationDetails;
