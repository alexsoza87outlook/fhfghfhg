
import { useState } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { Application, ApplicationStatus } from '@/types/application';
import { DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { updateApplicationStatus, addStatusUpdate } from '@/services/application';
import { useToast } from '@/components/ui/use-toast';

type ApplicationStatusUpdateProps = {
  application: Application;
  onSuccess?: () => void;
};

const ApplicationStatusUpdate = ({ application, onSuccess }: ApplicationStatusUpdateProps) => {
  const { t } = useLanguage();
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [status, setStatus] = useState<ApplicationStatus>(application.status);
  const [comment, setComment] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      toast({
        title: 'Error',
        description: 'You must be logged in to update status',
        variant: 'destructive',
      });
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // Update application status
      await updateApplicationStatus(application.id, status);
      
      // Add status update record
      await addStatusUpdate(application.id, user.id, status, comment);
      
      toast({
        title: 'Success',
        description: 'Application status updated successfully',
      });
      
      if (onSuccess) {
        onSuccess();
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to update application status',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <DialogHeader>
        <DialogTitle>{t('solicitor.dashboard.updateStatus')}</DialogTitle>
        <DialogDescription>
          Update the status of application {application.id}
        </DialogDescription>
      </DialogHeader>
      
      <div className="space-y-4 py-4">
        <div className="space-y-2">
          <Label>Status</Label>
          <RadioGroup value={status} onValueChange={(value: ApplicationStatus) => setStatus(value)} className="space-y-2">
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="under_review" id="under_review" />
              <Label htmlFor="under_review">{t('solicitor.status.underReview')}</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="additional_docs_required" id="additional_docs_required" />
              <Label htmlFor="additional_docs_required">{t('solicitor.status.additionalDocsRequired')}</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="approved" id="approved" />
              <Label htmlFor="approved">{t('solicitor.status.approved')}</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="rejected" id="rejected" />
              <Label htmlFor="rejected">{t('solicitor.status.rejected')}</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="completed" id="completed" />
              <Label htmlFor="completed">{t('solicitor.status.completed')}</Label>
            </div>
          </RadioGroup>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="comment">Comment</Label>
          <Textarea 
            id="comment"
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            placeholder="Add a comment about this status update"
            className="min-h-[100px]"
          />
        </div>
      </div>
      
      <div className="flex justify-end">
        <Button type="submit" disabled={isSubmitting}>
          {isSubmitting ? 'Updating...' : 'Update Status'}
        </Button>
      </div>
    </form>
  );
};

export default ApplicationStatusUpdate;
