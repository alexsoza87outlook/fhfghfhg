
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import MainLayout from '@/components/layout/MainLayout';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Eye, RefreshCw, MessageCircle } from 'lucide-react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Application } from '@/types/application';
import { getAllApplications } from '@/services/application';
import ApplicationStatusUpdate from './ApplicationStatusUpdate';
import { Dialog, DialogTrigger, DialogContent } from '@/components/ui/dialog';
import { useToast } from '@/components/ui/use-toast';

const SolicitorDashboard = () => {
  const { user, profile, isAuthenticated, isLoading: authLoading } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [applications, setApplications] = useState<Application[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedApplication, setSelectedApplication] = useState<Application | null>(null);
  
  useEffect(() => {
    if (!authLoading) {
      if (!isAuthenticated) {
        navigate('/login');
        return;
      }
      
      // Check if user is a solicitor
      if (profile?.user_type !== 'solicitor') {
        navigate('/dashboard');
        return;
      }
    }
  }, [isAuthenticated, authLoading, navigate, profile]);
  
  useEffect(() => {
    loadApplications();
  }, []);
  
  const loadApplications = async () => {
    setIsLoading(true);
    try {
      const data = await getAllApplications();
      setApplications(data as Application[]);
    } catch (error) {
      console.error("Error loading applications:", error);
      toast({
        title: 'Error',
        description: t('solicitor.dashboard.failedToLoad'),
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const formatDate = (dateString?: string) => {
    if (!dateString) return '-';
    return new Date(dateString).toLocaleDateString();
  };
  
  const getStatusClass = (status: string) => {
    switch(status) {
      case 'draft': return 'bg-gray-100 text-gray-800';
      case 'submitted': return 'bg-blue-100 text-blue-800';
      case 'under_review': return 'bg-yellow-100 text-yellow-800';
      case 'approved': return 'bg-green-100 text-green-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      case 'completed': return 'bg-purple-100 text-purple-800';
      case 'received': return 'bg-indigo-100 text-indigo-800';
      case 'additional_docs_required': return 'bg-amber-100 text-amber-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (authLoading) {
    return (
      <MainLayout>
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center justify-center min-h-[60vh]">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-resident-purple"></div>
          </div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">{t('solicitor.dashboard.title')}</h1>
          <Button 
            onClick={loadApplications}
            variant="outline"
            className="flex items-center"
          >
            <RefreshCw className="mr-2 h-4 w-4" />
            {t('solicitor.dashboard.refresh')}
          </Button>
        </div>
        
        <Card>
          <CardContent className="p-0">
            {isLoading ? (
              <div className="flex items-center justify-center p-12">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-resident-purple"></div>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>{t('solicitor.dashboard.applicant')}</TableHead>
                      <TableHead>{t('solicitor.dashboard.status')}</TableHead>
                      <TableHead>{t('solicitor.dashboard.date')}</TableHead>
                      <TableHead className="text-right">{t('solicitor.dashboard.action')}</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {applications.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={4} className="text-center py-8">
                          {t('solicitor.dashboard.noApplications')}
                        </TableCell>
                      </TableRow>
                    ) : (
                      applications.map((app) => (
                        <TableRow key={app.id}>
                          <TableCell>
                            {app.user_profile?.full_name || 'Unknown User'}
                            <div className="text-sm text-gray-500">{app.user_profile?.email || 'No email'}</div>
                          </TableCell>
                          <TableCell>
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusClass(app.status)}`}>
                              {app.status}
                            </span>
                            <div className="text-xs text-gray-500 mt-1">
                              Payment: {app.payment_status}
                            </div>
                          </TableCell>
                          <TableCell>{formatDate(app.submitted_at)}</TableCell>
                          <TableCell className="text-right space-x-2">
                            <Button 
                              variant="outline" 
                              size="sm" 
                              className="inline-flex items-center"
                              onClick={() => navigate(`/solicitor/application/${app.id}`)}
                            >
                              <Eye className="mr-1 h-4 w-4" />
                              {t('solicitor.dashboard.viewDetails')}
                            </Button>
                            <Button 
                              variant="outline" 
                              size="sm" 
                              className="inline-flex items-center"
                              onClick={() => navigate(`/solicitor/application/${app.id}`, { state: { tab: 'messaging' } })}
                            >
                              <MessageCircle className="mr-1 h-4 w-4" />
                              {t('solicitor.dashboard.messages')}
                            </Button>
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button 
                                  size="sm"
                                  className="inline-flex items-center"
                                  onClick={() => setSelectedApplication(app)}
                                >
                                  {t('solicitor.dashboard.updateStatus')}
                                </Button>
                              </DialogTrigger>
                              <DialogContent className="sm:max-w-md">
                                {selectedApplication && (
                                  <ApplicationStatusUpdate 
                                    application={selectedApplication} 
                                    onSuccess={loadApplications}
                                  />
                                )}
                              </DialogContent>
                            </Dialog>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
};

export default SolicitorDashboard;
