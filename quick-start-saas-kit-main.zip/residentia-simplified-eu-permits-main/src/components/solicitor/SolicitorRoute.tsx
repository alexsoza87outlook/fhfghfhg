
import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';

type SolicitorRouteProps = {
  children: React.ReactNode;
};

const SolicitorRoute = ({ children }: SolicitorRouteProps) => {
  const { isAuthenticated, isLoading, profile } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isLoading) {
      if (!isAuthenticated) {
        navigate('/login');
        return;
      }
      
      if (profile?.user_type !== 'solicitor') {
        navigate('/dashboard');
        return;
      }
    }
  }, [isAuthenticated, isLoading, navigate, profile]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-resident-purple"></div>
      </div>
    );
  }

  return <>{children}</>;
};

export default SolicitorRoute;
