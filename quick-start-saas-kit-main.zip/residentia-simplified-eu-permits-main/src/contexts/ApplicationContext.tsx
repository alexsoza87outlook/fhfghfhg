
import { createContext, useContext, ReactNode } from 'react';
import { Application, PersonalDetails, ApplicationDocument, ApplicationStatus, ApplicationStep } from '@/types/application';
import { useAuth } from './AuthContext';
import { useApplicationState } from '@/hooks/useApplicationState';
import { useApplicationActions } from '@/hooks/useApplicationActions';

interface ApplicationContextType {
  application: Application | null;
  isLoading: boolean;
  error: Error | null;
  createApplication: () => Promise<Application>;
  getApplication: (id: string) => Promise<void>;
  updateStep: (step: string) => Promise<void>;
  savePersonalDetails: (details: PersonalDetails) => Promise<void>;
  uploadDocument: (file: File, documentType: string) => Promise<ApplicationDocument | null>;
  submitApplication: () => Promise<void>;
  completePayment: () => Promise<void>;
}

const ApplicationContext = createContext<ApplicationContextType | undefined>(undefined);

export const ApplicationProvider = ({ children }: { children: ReactNode }) => {
  const { user } = useAuth();
  const { 
    application, 
    setApplication,
    isLoading,
    setIsLoading,
    error,
    setError 
  } = useApplicationState();
  
  const { 
    createApplication,
    getApplication,
    updateStep,
    savePersonalDetails,
    uploadDocument,
    submitApplication,
    completePayment
  } = useApplicationActions(
    application, 
    setApplication, 
    setIsLoading, 
    setError,
    user?.id
  );

  return (
    <ApplicationContext.Provider
      value={{
        application,
        isLoading,
        error,
        createApplication,
        getApplication,
        updateStep,
        savePersonalDetails,
        uploadDocument,
        submitApplication,
        completePayment
      }}
    >
      {children}
    </ApplicationContext.Provider>
  );
};

export const useApplication = (): ApplicationContextType => {
  const context = useContext(ApplicationContext);
  if (context === undefined) {
    throw new Error('useApplication must be used within an ApplicationProvider');
  }
  return context;
};
