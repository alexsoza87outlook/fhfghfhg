
import { useCallback } from 'react';
import { Application, ApplicationStatus } from '@/types/application';
import * as applicationService from '@/services/application';
import { useToast } from '@/components/ui/use-toast';

export function useApplicationSubmit(
  application: Application | null,
  setApplication: React.Dispatch<React.SetStateAction<Application | null>>,
  setIsLoading: React.Dispatch<React.SetStateAction<boolean>>,
  setError: React.Dispatch<React.SetStateAction<Error | null>>
) {
  const { toast } = useToast();

  const submitApplication = useCallback(async () => {
    if (!application) {
      throw new Error('No active application');
    }

    setIsLoading(true);
    setError(null);

    try {
      const updatedApplication = await applicationService.submitApplication(application.id);
      setApplication(prev => {
        if (!prev) return null;
        return { 
          ...prev, 
          status: updatedApplication.status as ApplicationStatus,
          submitted_at: updatedApplication.submitted_at
        };
      });
      
      toast({
        title: 'Success',
        description: 'Application submitted successfully',
      });
    } catch (err) {
      setError(err as Error);
      toast({
        title: 'Error',
        description: 'Failed to submit application',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  }, [application, toast, setApplication, setIsLoading, setError]);

  return submitApplication;
}
