
import { useCallback } from 'react';
import { Application } from '@/types/application';
import * as applicationService from '@/services/application';
import { useToast } from '@/components/ui/use-toast';

export function useCreateApplication(
  setApplication: React.Dispatch<React.SetStateAction<Application | null>>,
  setIsLoading: React.Dispatch<React.SetStateAction<boolean>>,
  setError: React.Dispatch<React.SetStateAction<Error | null>>,
  userId?: string
) {
  const { toast } = useToast();

  const createApplication = useCallback(async () => {
    if (!userId) {
      throw new Error('User not authenticated');
    }

    setIsLoading(true);
    setError(null);

    try {
      const newApplication = await applicationService.createApplication(userId);
      setApplication(newApplication as Application);
      return newApplication as Application;
    } catch (err) {
      setError(err as Error);
      toast({
        title: 'Error',
        description: 'Failed to create application',
        variant: 'destructive',
      });
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, [userId, toast, setApplication, setIsLoading, setError]);

  return createApplication;
}
