
import { useCallback } from 'react';
import { Application, ApplicationDocument } from '@/types/application';
import * as applicationService from '@/services/application';
import { useToast } from '@/components/ui/use-toast';

export function useDocumentUpload(
  application: Application | null,
  setApplication: React.Dispatch<React.SetStateAction<Application | null>>,
  setIsLoading: React.Dispatch<React.SetStateAction<boolean>>,
  setError: React.Dispatch<React.SetStateAction<Error | null>>,
  userId?: string
) {
  const { toast } = useToast();

  const uploadDocument = useCallback(async (file: File, documentType: string) => {
    if (!application || !userId) {
      throw new Error('No active application or user not authenticated');
    }

    setIsLoading(true);
    setError(null);

    try {
      const document = await applicationService.uploadDocument(application.id, userId, file, documentType);
      
      // Update the application state with the new document
      setApplication(prev => {
        if (!prev) return null;
        
        const updatedDocuments = [...(prev.documents || []), document];
        return { ...prev, documents: updatedDocuments };
      });
      
      toast({
        title: 'Success',
        description: 'Document uploaded successfully',
      });
      
      return document;
    } catch (err) {
      setError(err as Error);
      toast({
        title: 'Error',
        description: 'Failed to upload document',
        variant: 'destructive',
      });
      return null;
    } finally {
      setIsLoading(false);
    }
  }, [application, userId, toast, setApplication, setIsLoading, setError]);

  return uploadDocument;
}
