
import { useCallback } from 'react';
import { Application } from '@/types/application';
import * as applicationService from '@/services/application';
import { useToast } from '@/components/ui/use-toast';

export function useGetApplication(
  setApplication: React.Dispatch<React.SetStateAction<Application | null>>,
  setIsLoading: React.Dispatch<React.SetStateAction<boolean>>,
  setError: React.Dispatch<React.SetStateAction<Error | null>>
) {
  const { toast } = useToast();

  const getApplication = useCallback(async (id: string) => {
    setIsLoading(true);
    setError(null);

    try {
      const applicationData = await applicationService.getApplicationById(id);
      setApplication(applicationData);
    } catch (err) {
      setError(err as Error);
      toast({
        title: 'Error',
        description: 'Failed to load application data',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  }, [toast, setApplication, setIsLoading, setError]);

  return getApplication;
}
