
import { useCallback } from 'react';
import { Application, PaymentStatus } from '@/types/application';
import * as applicationService from '@/services/application';
import { useToast } from '@/components/ui/use-toast';

export function usePayment(
  application: Application | null,
  setApplication: React.Dispatch<React.SetStateAction<Application | null>>,
  setIsLoading: React.Dispatch<React.SetStateAction<boolean>>,
  setError: React.Dispatch<React.SetStateAction<Error | null>>
) {
  const { toast } = useToast();

  const completePayment = useCallback(async () => {
    if (!application) {
      throw new Error('No active application');
    }

    setIsLoading(true);
    setError(null);

    try {
      const updatedApplication = await applicationService.completePayment(application.id);
      setApplication(prev => {
        if (!prev) return null;
        return { ...prev, payment_status: updatedApplication.payment_status as PaymentStatus };
      });
      
      toast({
        title: 'Success',
        description: 'Payment completed successfully',
      });
    } catch (err) {
      setError(err as Error);
      toast({
        title: 'Error',
        description: 'Failed to process payment',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  }, [application, toast, setApplication, setIsLoading, setError]);

  return completePayment;
}
