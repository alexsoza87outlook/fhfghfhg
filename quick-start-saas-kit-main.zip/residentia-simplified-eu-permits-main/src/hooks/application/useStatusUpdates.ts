
import { useState, useEffect } from 'react';
import { StatusUpdate, ApplicationStatus } from '@/types/application';
import { getStatusUpdates, addStatusUpdate } from '@/services/application';
import { useToast } from '@/components/ui/use-toast';

export function useStatusUpdates(applicationId: string) {
  const [statusUpdates, setStatusUpdates] = useState<StatusUpdate[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const { toast } = useToast();
  
  const loadStatusUpdates = async () => {
    if (!applicationId) return;
    
    setIsLoading(true);
    try {
      const updates = await getStatusUpdates(applicationId);
      setStatusUpdates(updates);
    } catch (error) {
      console.error('Error loading status updates:', error);
      toast({
        title: 'Error',
        description: 'Failed to load status history',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const createStatusUpdate = async (userId: string, status: ApplicationStatus, comment?: string) => {
    if (!applicationId || !userId || !status) return null;
    
    try {
      const newUpdate = await addStatusUpdate(applicationId, userId, status, comment);
      setStatusUpdates(prev => [newUpdate, ...prev]);
      return newUpdate;
    } catch (error) {
      console.error('Error creating status update:', error);
      toast({
        title: 'Error',
        description: 'Failed to create status update',
        variant: 'destructive',
      });
      return null;
    }
  };
  
  useEffect(() => {
    if (applicationId) {
      loadStatusUpdates();
    }
  }, [applicationId]);
  
  return {
    statusUpdates,
    isLoading,
    refreshStatusUpdates: loadStatusUpdates,
    createStatusUpdate
  };
}
