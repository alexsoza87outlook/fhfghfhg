
import { useCallback } from 'react';
import { Application, ApplicationStep } from '@/types/application';
import * as applicationService from '@/services/application';
import { useToast } from '@/components/ui/use-toast';

export function useUpdateApplicationStep(
  application: Application | null,
  setApplication: React.Dispatch<React.SetStateAction<Application | null>>,
  setIsLoading: React.Dispatch<React.SetStateAction<boolean>>,
  setError: React.Dispatch<React.SetStateAction<Error | null>>
) {
  const { toast } = useToast();

  const updateStep = useCallback(async (step: string) => {
    if (!application) {
      throw new Error('No active application');
    }

    setIsLoading(true);
    setError(null);

    try {
      const updatedApplication = await applicationService.updateApplicationStep(application.id, step);
      setApplication(prev => {
        if (!prev) return null;
        return { ...prev, current_step: updatedApplication.current_step as ApplicationStep };
      });
    } catch (err) {
      setError(err as Error);
      toast({
        title: 'Error',
        description: 'Failed to update application step',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  }, [application, toast, setApplication, setIsLoading, setError]);

  return updateStep;
}
