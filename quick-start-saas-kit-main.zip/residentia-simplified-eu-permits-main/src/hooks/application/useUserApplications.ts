
import { useState, useEffect } from 'react';
import { Application, StatusUpdate } from '@/types/application';
import { useAuth } from '@/contexts/AuthContext';
import * as applicationService from '@/services/application';
import { useToast } from '@/components/ui/use-toast';

export function useUserApplications() {
  const [applications, setApplications] = useState<Application[]>([]);
  const [statusUpdates, setStatusUpdates] = useState<StatusUpdate[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { user } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    async function loadUserData() {
      if (!user?.id) return;
      
      try {
        setIsLoading(true);
        // Get user's applications
        const userApplications = await applicationService.getApplicationsByUserId(user.id);
        setApplications(userApplications);
        
        // If there's at least one application, get its status updates
        if (userApplications.length > 0) {
          const latestApplication = userApplications[0]; // Assuming sorted by latest first
          try {
            const updates = await applicationService.getStatusUpdates(latestApplication.id);
            setStatusUpdates(updates);
          } catch (updateError) {
            console.error('Error loading status updates:', updateError);
            // Don't fail the whole operation if just status updates fail
          }
        }
      } catch (error) {
        console.error('Error loading user applications:', error);
        toast({
          title: 'Error',
          description: 'Failed to load your application data',
          variant: 'destructive',
        });
      } finally {
        setIsLoading(false);
      }
    }

    loadUserData();
  }, [user, toast]);

  return { applications, statusUpdates, isLoading };
}
