
import { Application, PersonalDetails, ApplicationDocument, ApplicationStatus, PaymentStatus } from '@/types/application';
import { useCreateApplication } from './application/useCreateApplication';
import { useGetApplication } from './application/useGetApplication';
import { useUpdateApplicationStep } from './application/useUpdateApplicationStep';
import { usePersonalDetails } from './application/usePersonalDetails';
import { useDocumentUpload } from './application/useDocumentUpload';
import { useApplicationSubmit } from './application/useApplicationSubmit';
import { usePayment } from './application/usePayment';

export function useApplicationActions(
  application: Application | null,
  setApplication: React.Dispatch<React.SetStateAction<Application | null>>,
  setIsLoading: React.Dispatch<React.SetStateAction<boolean>>,
  setError: React.Dispatch<React.SetStateAction<Error | null>>,
  userId?: string
) {
  const createApplication = useCreateApplication(
    setApplication,
    setIsLoading,
    setError,
    userId
  );

  const getApplication = useGetApplication(
    setApplication,
    setIsLoading,
    setError
  );

  const updateStep = useUpdateApplicationStep(
    application,
    setApplication,
    setIsLoading,
    setError
  );

  const savePersonalDetails = usePersonalDetails(
    application,
    setApplication,
    setIsLoading,
    setError
  );

  const uploadDocument = useDocumentUpload(
    application,
    setApplication,
    setIsLoading,
    setError,
    userId
  );

  const submitApplication = useApplicationSubmit(
    application,
    setApplication,
    setIsLoading,
    setError
  );

  const completePayment = usePayment(
    application,
    setApplication,
    setIsLoading,
    setError
  );

  return {
    createApplication,
    getApplication,
    updateStep,
    savePersonalDetails,
    uploadDocument,
    submitApplication,
    completePayment
  };
}
