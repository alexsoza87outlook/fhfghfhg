
import { useState } from 'react';
import { Application, ApplicationStatus, ApplicationStep, PaymentStatus } from '@/types/application';

export function useApplicationState() {
  const [application, setApplication] = useState<Application | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<Error | null>(null);

  return {
    application,
    setApplication,
    isLoading,
    setIsLoading,
    error,
    setError
  };
}
