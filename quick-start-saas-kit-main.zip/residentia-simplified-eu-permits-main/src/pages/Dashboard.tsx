
import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useUserApplications } from '@/hooks/application/useUserApplications';
import MainLayout from '@/components/layout/MainLayout';

// Import all the new components
import DashboardHeader from '@/components/dashboard/DashboardHeader';
import StatusCard from '@/components/dashboard/StatusCard';
import NextStepsCard from '@/components/dashboard/NextStepsCard';
import SupportCard from '@/components/dashboard/SupportCard';
import ApplicationTimeline from '@/components/dashboard/ApplicationTimeline';

const Dashboard = () => {
  const { user, profile, isAuthenticated, isLoading: authLoading } = useAuth();
  const { applications, statusUpdates, isLoading: applicationsLoading } = useUserApplications();
  const navigate = useNavigate();

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      navigate('/login');
    }
  }, [isAuthenticated, authLoading, navigate]);

  // Get the latest application (if any)
  const latestApplication = applications && applications.length > 0 ? applications[0] : null;

  const isLoading = authLoading || applicationsLoading;

  if (isLoading) {
    return (
      <MainLayout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-resident-purple"></div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-8">
        <DashboardHeader 
          userName={profile?.full_name || user?.email?.split('@')[0] || ''}
        />
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <StatusCard latestApplication={latestApplication} />
          <NextStepsCard />
          <SupportCard />
        </div>
        
        {latestApplication && (
          <>
            {/* Horizontal Timeline */}
            <ApplicationTimeline 
              statusUpdates={statusUpdates}
              latestApplication={latestApplication}
            />
          </>
        )}
      </div>
    </MainLayout>
  );
};

export default Dashboard;
