
import MainLayout from '@/components/layout/MainLayout';
import HeroSection from '@/components/home/HeroSection';
import ProblemSection from '@/components/home/ProblemSection';
import StepsSection from '@/components/home/StepsSection';
import BenefitsSection from '@/components/home/BenefitsSection';
import ComparisonSection from '@/components/home/ComparisonSection';
import WhereWeOperateSection from '@/components/home/WhereWeOperateSection';
import WhoItsForSection from '@/components/home/WhoItsForSection';
import PricingSection from '@/components/home/PricingSection';
import TrustGuaranteeSection from '@/components/home/TrustGuaranteeSection';
import TestimonialsCarousel from '@/components/home/TestimonialsCarousel';
import CtaSection from '@/components/home/CtaSection';

const Index = () => {
  return (
    <MainLayout>
      <HeroSection />
      <ProblemSection />
      <StepsSection />
      <BenefitsSection />
      <ComparisonSection />
      <WhereWeOperateSection />
      <WhoItsForSection />
      <PricingSection />
      <TrustGuaranteeSection />
      <TestimonialsCarousel />
      <CtaSection />
    </MainLayout>
  );
};

export default Index;
