
import React, { useState } from 'react';
import MainLayout from '@/components/layout/MainLayout';
import ResidenceCard from '@/components/residence/ResidenceCard';
import EligibilityQuestionnaire from '@/components/residence/EligibilityQuestionnaire';
import InfoDialog from '@/components/residence/InfoDialog';
import { useLanguage } from '@/contexts/LanguageContext';

type LongTermCardType = 'euFamilyMember' | 'longTerm.permanentResidence';

const LongTermResidence = () => {
  const { t } = useLanguage();
  const [eligibilityOpen, setEligibilityOpen] = useState(false);
  const [infoOpen, setInfoOpen] = useState(false);
  const [selectedCard, setSelectedCard] = useState<LongTermCardType | null>(null);

  const handleCheckEligibility = (cardType: LongTermCardType) => {
    setSelectedCard(cardType);
    setEligibilityOpen(true);
  };

  const handleMoreInfo = (cardType: LongTermCardType) => {
    setSelectedCard(cardType);
    setInfoOpen(true);
  };

  return (
    <MainLayout>
      <div className="container mx-auto py-10 px-4">
        <h1 className="text-3xl font-bold text-center mb-12">{t('residence.longTerm.title')}</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <ResidenceCard 
            cardType="euFamilyMember" 
            onCheckEligibility={() => handleCheckEligibility('euFamilyMember')} 
            onMoreInfo={() => handleMoreInfo('euFamilyMember')} 
          />
          
          <ResidenceCard 
            cardType="longTerm.permanentResidence" 
            onCheckEligibility={() => handleCheckEligibility('longTerm.permanentResidence')} 
            onMoreInfo={() => handleMoreInfo('longTerm.permanentResidence')} 
          />
        </div>
      </div>
      
      {selectedCard && (
        <>
          <EligibilityQuestionnaire 
            isOpen={eligibilityOpen} 
            onClose={() => setEligibilityOpen(false)} 
            cardType={selectedCard}
          />
          
          <InfoDialog 
            isOpen={infoOpen} 
            onClose={() => setInfoOpen(false)} 
            cardType={selectedCard}
          />
        </>
      )}
    </MainLayout>
  );
};

export default LongTermResidence;
