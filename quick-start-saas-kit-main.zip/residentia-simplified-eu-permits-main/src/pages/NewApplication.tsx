
import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { useApplication } from '@/contexts/ApplicationContext';
import MainLayout from '@/components/layout/MainLayout';

const NewApplication = () => {
  const { isAuthenticated, isLoading: authLoading } = useAuth();
  const { createApplication } = useApplication();
  const navigate = useNavigate();
  const { t } = useLanguage();

  useEffect(() => {
    const initApplication = async () => {
      if (!authLoading) {
        if (!isAuthenticated) {
          navigate('/login');
          return;
        }

        try {
          const app = await createApplication();
          navigate(`/application/${app.id}`);
        } catch (error) {
          console.error("Error creating application:", error);
          navigate('/dashboard');
        }
      }
    };

    initApplication();
  }, [isAuthenticated, authLoading, navigate, createApplication]);

  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-resident-purple mx-auto mb-4"></div>
            <p className="text-lg">{t('Creating your application...')}</p>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default NewApplication;
