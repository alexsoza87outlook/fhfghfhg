
import React, { useState } from 'react';
import MainLayout from '@/components/layout/MainLayout';
import ResidenceCard from '@/components/residence/ResidenceCard';
import EligibilityQuestionnaire from '@/components/residence/EligibilityQuestionnaire';
import InfoDialog from '@/components/residence/InfoDialog';
import NonLucrativeEligibilityCheck from '@/components/residence/NonLucrativeEligibilityCheck';
import EuBlueCardEligibilityCheck from '@/components/residence/EuBlueCardEligibilityCheck';
import { useLanguage } from '@/contexts/LanguageContext';
import ChatbotWidget from '@/components/chatbot/ChatbotWidget';

type CardType = 
  | 'nonLucrative' 
  | 'certificate' 
  | 'nie' 
  | 'highlyQualified' 
  | 'temporaryWork' 
  | 'familyReunification' 
  | 'longTerm' 
  | 'euFamilyMember' 
  | 'euBlueCard'
  | 'studentStay'
  | 'temporaryWorkInitial'
  | 'remoteWork'
  | 'familyReunificationInitial';

const ResidenceAuthorization = () => {
  const { t } = useLanguage();
  const [eligibilityOpen, setEligibilityOpen] = useState(false);
  const [infoOpen, setInfoOpen] = useState(false);
  const [nonLucrativeEligibilityOpen, setNonLucrativeEligibilityOpen] = useState(false);
  const [euBlueCardEligibilityOpen, setEuBlueCardEligibilityOpen] = useState(false);
  const [selectedCard, setSelectedCard] = useState<CardType | null>(null);

  const handleCheckEligibility = (cardType: CardType) => {
    setSelectedCard(cardType);
    if (cardType === 'nonLucrative') {
      setNonLucrativeEligibilityOpen(true);
    } else if (cardType === 'euBlueCard') {
      setEuBlueCardEligibilityOpen(true);
    } else {
      setEligibilityOpen(true);
    }
  };

  const handleMoreInfo = (cardType: CardType) => {
    setSelectedCard(cardType);
    setInfoOpen(true);
  };

  // Updated card categories - moved longTerm and euFamilyMember to renewal
  const cardsByCategory = {
    initial: [
      'studentStay',
      'temporaryWorkInitial',
      'remoteWork',
      'familyReunificationInitial',
      'euBlueCard'
    ],
    renewal: [
      'nonLucrative',
      'highlyQualified',
      'temporaryWork',
      'familyReunification',
      'certificate',
      'nie',
      'longTerm',
      'euFamilyMember'
    ]
  };

  return (
    <MainLayout>
      <div className="container mx-auto py-10 px-4">
        <h1 className="text-3xl font-bold text-center mb-12">
          {t('residence.title')} - Spain
        </h1>
        
        {/* Initial Residence Applications */}
        <div className="mb-12">
          <h2 className="text-2xl font-semibold mb-6">
            {t('residence.initial.applications')}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {cardsByCategory.initial.map((cardType) => (
              <ResidenceCard 
                key={cardType}
                cardType={cardType}
                onCheckEligibility={() => handleCheckEligibility(cardType as CardType)}
                onMoreInfo={() => handleMoreInfo(cardType as CardType)}
              />
            ))}
          </div>
        </div>

        {/* Residence Renewal */}
        <div className="mb-12">
          <h2 className="text-2xl font-semibold mb-6">
            {t('residence.renewal.title')}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {cardsByCategory.renewal.map((cardType) => (
              <ResidenceCard 
                key={cardType}
                cardType={cardType}
                onCheckEligibility={() => handleCheckEligibility(cardType as CardType)}
                onMoreInfo={() => handleMoreInfo(cardType as CardType)}
              />
            ))}
          </div>
        </div>
      </div>

      {selectedCard && (
        <>
          <EligibilityQuestionnaire 
            isOpen={eligibilityOpen} 
            onClose={() => setEligibilityOpen(false)} 
            cardType={selectedCard}
          />
          
          <InfoDialog 
            isOpen={infoOpen} 
            onClose={() => setInfoOpen(false)} 
            cardType={selectedCard}
          />

          {selectedCard === 'nonLucrative' && (
            <NonLucrativeEligibilityCheck
              isOpen={nonLucrativeEligibilityOpen}
              onClose={() => setNonLucrativeEligibilityOpen(false)}
            />
          )}
          
          {selectedCard === 'euBlueCard' && (
            <EuBlueCardEligibilityCheck
              isOpen={euBlueCardEligibilityOpen}
              onClose={() => setEuBlueCardEligibilityOpen(false)}
            />
          )}
        </>
      )}

      {/* Add the chatbot widget */}
      <ChatbotWidget />
    </MainLayout>
  );
};

export default ResidenceAuthorization;
