
import React, { useState } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import AdminLayout from '@/components/admin/AdminLayout';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';
import { 
  Table, 
  TableHeader, 
  TableRow, 
  TableHead, 
  TableBody, 
  TableCell 
} from '@/components/ui/table';
import { Key, Copy, Plus, Eye, EyeOff, Trash2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

const AdminApiKeys: React.FC = () => {
  const { t } = useLanguage();
  const { toast } = useToast();
  
  const [showKey, setShowKey] = useState<Record<string, boolean>>({});
  
  // Mock API keys
  const [apiKeys, setApiKeys] = useState([
    {
      id: '1',
      name: 'Production API Key',
      key: 'sk_prod_01abc123xyz456',
      type: 'production',
      created: '2023-11-15',
      lastUsed: '2023-11-20',
    },
    {
      id: '2',
      name: 'Development API Key',
      key: 'sk_dev_02def456abc789',
      type: 'development',
      created: '2023-10-05',
      lastUsed: '2023-11-19',
    },
  ]);
  
  const [newKeyName, setNewKeyName] = useState('');
  const [newKeyType, setNewKeyType] = useState('development');

  const toggleKeyVisibility = (id: string) => {
    setShowKey({
      ...showKey,
      [id]: !showKey[id]
    });
  };
  
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: t('common.copied'),
      description: t('common.copiedToClipboard'),
    });
  };
  
  const createNewKey = () => {
    if (!newKeyName) {
      toast({
        variant: 'destructive',
        title: t('common.error'),
        description: t('common.nameRequired'),
      });
      return;
    }
    
    // In a real implementation, this would create a key via API
    const newKey = {
      id: `${apiKeys.length + 1}`,
      name: newKeyName,
      key: `sk_${newKeyType.substring(0, 4)}_${Math.random().toString(36).substring(2, 15)}`,
      type: newKeyType,
      created: new Date().toISOString().split('T')[0],
      lastUsed: '-',
    };
    
    setApiKeys([...apiKeys, newKey]);
    setNewKeyName('');
    
    toast({
      title: t('common.success'),
      description: t('common.apiKeyCreated'),
    });
  };
  
  const deleteKey = (id: string) => {
    // Confirm before deleting
    if (window.confirm(t('common.confirmDelete'))) {
      setApiKeys(apiKeys.filter(key => key.id !== id));
      
      toast({
        title: t('common.deleted'),
        description: t('common.apiKeyDeleted'),
      });
    }
  };
  
  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold">{t('admin.dashboard.apiKeys')}</h1>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Key className="h-5 w-5" />
              {t('admin.dashboard.apiKeys')}
            </CardTitle>
            <CardDescription>
              Manage your API keys for integrations
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-amber-50 border border-amber-200 text-amber-800 p-4 rounded-md flex gap-2">
              <AlertCircle className="h-5 w-5" />
              <div>
                <p className="font-medium">API Keys are sensitive</p>
                <p className="text-sm">Keep your API keys secure. Do not share them in public repositories or client-side code.</p>
              </div>
            </div>
            
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t('common.name')}</TableHead>
                  <TableHead>{t('common.apiKey')}</TableHead>
                  <TableHead>{t('common.type')}</TableHead>
                  <TableHead>{t('common.created')}</TableHead>
                  <TableHead>{t('common.lastUsed')}</TableHead>
                  <TableHead>{t('admin.users.actions')}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {apiKeys.map(key => (
                  <TableRow key={key.id}>
                    <TableCell>{key.name}</TableCell>
                    <TableCell className="font-mono">
                      <div className="flex items-center gap-2">
                        {showKey[key.id] ? key.key : '••••••••••••••••'}
                        <button 
                          onClick={() => toggleKeyVisibility(key.id)}
                          className="text-gray-500 hover:text-gray-700"
                        >
                          {showKey[key.id] ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </button>
                        <button 
                          onClick={() => copyToClipboard(key.key)}
                          className="text-gray-500 hover:text-gray-700"
                        >
                          <Copy className="h-4 w-4" />
                        </button>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={key.type === 'production' ? 'destructive' : 'default'}>
                        {key.type}
                      </Badge>
                    </TableCell>
                    <TableCell>{key.created}</TableCell>
                    <TableCell>{key.lastUsed}</TableCell>
                    <TableCell>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => deleteKey(key.id)}
                      >
                        <Trash2 className="h-4 w-4 text-red-500" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Plus className="h-5 w-5" />
              {t('common.createApiKey')}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">{t('common.name')}</label>
                <Input
                  value={newKeyName}
                  onChange={(e) => setNewKeyName(e.target.value)}
                  placeholder="e.g. Production API Key"
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">{t('common.type')}</label>
                <select 
                  className="w-full px-3 py-2 bg-white border rounded-md"
                  value={newKeyType}
                  onChange={(e) => setNewKeyType(e.target.value)}
                >
                  <option value="development">{t('common.development')}</option>
                  <option value="production">{t('common.production')}</option>
                </select>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-end">
            <Button onClick={createNewKey}>{t('common.createApiKey')}</Button>
          </CardFooter>
        </Card>
      </div>
    </AdminLayout>
  );
};

import { AlertCircle } from 'lucide-react';

export default AdminApiKeys;
