
import React, { useState } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import AdminLayout from '@/components/admin/AdminLayout';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';
import { MessageCircle, Settings } from 'lucide-react';

const AdminChatbot: React.FC = () => {
  const { t, language } = useLanguage();
  const { toast } = useToast();
  
  const [chatbotSettings, setChatbotSettings] = useState({
    welcomeMessage: {
      en: "Hello! I am ResidentIA, your virtual assistant for residence permits in Spain. How can I help you today?",
      es: "¡Hola! Soy ResidentIA, tu asistente virtual para permisos de residencia en España. ¿Cómo puedo ayudarte hoy?"
    },
    promptTemplate: "You are a helpful assistant specialized in Spanish residence permits and immigration procedures. Provide concise, accurate information about the residence application process in Spain.",
    fallbackMessage: {
      en: "I'm sorry, I couldn't process your request. Please try again with a different question.",
      es: "Lo siento, no pude procesar tu solicitud. Por favor, intenta de nuevo con una pregunta diferente."
    }
  });

  const handleSaveSettings = () => {
    // In a real implementation, this would save to Supabase
    toast({
      title: t('admin.settings.saved'),
      description: t('admin.chatbot.configuration') + ' ' + t('common.saved'),
    });
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold">{t('admin.dashboard.chatbot')}</h1>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MessageCircle className="h-5 w-5" />
              {t('admin.chatbot.configuration')}
            </CardTitle>
            <CardDescription>
              Configure how the ResidentIA chatbot interacts with users
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <h3 className="text-sm font-medium">{t('admin.chatbot.welcomeMessage')} (English)</h3>
              <Textarea 
                value={chatbotSettings.welcomeMessage.en}
                onChange={(e) => setChatbotSettings({
                  ...chatbotSettings,
                  welcomeMessage: {
                    ...chatbotSettings.welcomeMessage,
                    en: e.target.value
                  }
                })}
                rows={2}
              />
            </div>

            <div className="space-y-2">
              <h3 className="text-sm font-medium">{t('admin.chatbot.welcomeMessage')} (Español)</h3>
              <Textarea 
                value={chatbotSettings.welcomeMessage.es}
                onChange={(e) => setChatbotSettings({
                  ...chatbotSettings,
                  welcomeMessage: {
                    ...chatbotSettings.welcomeMessage,
                    es: e.target.value
                  }
                })}
                rows={2}
              />
            </div>

            <div className="space-y-2">
              <h3 className="text-sm font-medium">{t('admin.chatbot.promptTemplate')}</h3>
              <Textarea 
                value={chatbotSettings.promptTemplate}
                onChange={(e) => setChatbotSettings({
                  ...chatbotSettings,
                  promptTemplate: e.target.value
                })}
                rows={4}
              />
              <p className="text-xs text-gray-500">Define the instructions that shape how the AI chatbot behaves.</p>
            </div>

            <div className="space-y-2">
              <h3 className="text-sm font-medium">{t('admin.chatbot.fallbackMessage')} (English)</h3>
              <Textarea 
                value={chatbotSettings.fallbackMessage.en}
                onChange={(e) => setChatbotSettings({
                  ...chatbotSettings,
                  fallbackMessage: {
                    ...chatbotSettings.fallbackMessage,
                    en: e.target.value
                  }
                })}
                rows={2}
              />
            </div>

            <div className="space-y-2">
              <h3 className="text-sm font-medium">{t('admin.chatbot.fallbackMessage')} (Español)</h3>
              <Textarea 
                value={chatbotSettings.fallbackMessage.es}
                onChange={(e) => setChatbotSettings({
                  ...chatbotSettings,
                  fallbackMessage: {
                    ...chatbotSettings.fallbackMessage,
                    es: e.target.value
                  }
                })}
                rows={2}
              />
            </div>
          </CardContent>
          <CardFooter className="flex justify-end">
            <Button onClick={handleSaveSettings}>{t('admin.settings.save')}</Button>
          </CardFooter>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="h-5 w-5" />
              {t('admin.settings.openAI')}
            </CardTitle>
            <CardDescription>
              Configure OpenAI integration parameters
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <h3 className="text-sm font-medium">{t('admin.settings.openAI.apiKey')}</h3>
              <Input 
                type="password" 
                value="sk-****************************************" 
                onChange={() => {}}
              />
              <p className="text-xs text-gray-500">Enter your OpenAI API key to enable the chatbot.</p>
            </div>
            
            <div className="space-y-2">
              <h3 className="text-sm font-medium">{t('admin.settings.openAI.model')}</h3>
              <select className="w-full px-3 py-2 border rounded-md">
                <option value="gpt-4">GPT-4 Turbo</option>
                <option value="gpt-3.5-turbo">GPT-3.5 Turbo</option>
              </select>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <h3 className="text-sm font-medium">{t('admin.settings.openAI.temperature')}</h3>
                <Input type="number" value="0.7" min="0" max="1" step="0.1" />
                <p className="text-xs text-gray-500">Controls randomness (0 = more focused, 1 = more creative)</p>
              </div>
              
              <div className="space-y-2">
                <h3 className="text-sm font-medium">{t('admin.settings.openAI.maxTokens')}</h3>
                <Input type="number" value="500" min="100" max="4000" />
                <p className="text-xs text-gray-500">Maximum length of response</p>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-end">
            <Button onClick={handleSaveSettings}>{t('admin.settings.save')}</Button>
          </CardFooter>
        </Card>
      </div>
    </AdminLayout>
  );
};

export default AdminChatbot;
