
import React from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import AdminLayout from '@/components/admin/AdminLayout';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { UserPlus, FileText, FileCheck, Clock } from 'lucide-react';

const AdminDashboard: React.FC = () => {
  const { t } = useLanguage();

  // Mock data for the dashboard
  const statistics = {
    totalUsers: 256,
    totalApplications: 189,
    pendingApplications: 42,
    completedApplications: 147,
    // Add more statistics as needed
  };

  const statCards = [
    {
      title: t('admin.dashboard.totalUsers'),
      value: statistics.totalUsers,
      icon: <UserPlus className="h-8 w-8 text-blue-500" />,
      color: 'bg-blue-50',
      textColor: 'text-blue-500',
    },
    {
      title: t('admin.dashboard.totalApplications'),
      value: statistics.totalApplications,
      icon: <FileText className="h-8 w-8 text-purple-500" />,
      color: 'bg-purple-50',
      textColor: 'text-purple-500',
    },
    {
      title: t('admin.dashboard.pendingApplications'),
      value: statistics.pendingApplications,
      icon: <Clock className="h-8 w-8 text-amber-500" />,
      color: 'bg-amber-50',
      textColor: 'text-amber-500',
    },
    {
      title: t('admin.dashboard.completedApplications'),
      value: statistics.completedApplications,
      icon: <FileCheck className="h-8 w-8 text-green-500" />,
      color: 'bg-green-50',
      textColor: 'text-green-500',
    },
  ];

  return (
    <AdminLayout>
      <div className="space-y-6">
        <h1 className="text-2xl font-bold">{t('admin.dashboard.overview')}</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {statCards.map((card, index) => (
            <Card key={index} className="overflow-hidden">
              <CardHeader className={`${card.color} p-4`}>
                <div className="flex justify-between items-center">
                  <CardTitle className={`text-lg font-semibold ${card.textColor}`}>
                    {card.title}
                  </CardTitle>
                  {card.icon}
                </div>
              </CardHeader>
              <CardContent className="p-4">
                <p className="text-3xl font-bold">{card.value}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Recent Activities Section */}
        <Card>
          <CardHeader>
            <CardTitle>{t('admin.dashboard.recentActivities')}</CardTitle>
            <CardDescription>
              {t('admin.dashboard.recentActivitiesDescription')}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {/* We would normally fetch recent activities from the database */}
            <p className="text-gray-500 text-center py-4">
              {t('admin.dashboard.noRecentActivities')}
            </p>
          </CardContent>
        </Card>

        {/* System Status Section */}
        <Card>
          <CardHeader>
            <CardTitle>{t('admin.dashboard.systemStatus')}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span>{t('admin.dashboard.chatbotStatus')}</span>
                <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs font-medium">
                  {t('admin.dashboard.online')}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span>{t('admin.dashboard.apiStatus')}</span>
                <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs font-medium">
                  {t('admin.dashboard.online')}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span>{t('admin.dashboard.databaseStatus')}</span>
                <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs font-medium">
                  {t('admin.dashboard.online')}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
};

export default AdminDashboard;
