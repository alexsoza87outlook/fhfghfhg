
import React, { useState } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import AdminLayout from '@/components/admin/AdminLayout';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { useToast } from '@/components/ui/use-toast';
import { Switch } from '@/components/ui/switch';
import { Globe, Mail, AlertCircle, Bell, Shield } from 'lucide-react';

const AdminSettings: React.FC = () => {
  const { t } = useLanguage();
  const { toast } = useToast();
  
  const [settingsGeneral, setSettingsGeneral] = useState({
    siteName: 'Resident Portal',
    siteDescription: 'Spain residence permit application platform',
    adminEmail: 'admin@residentportal.com',
    supportEmail: 'support@residentportal.com',
  });
  
  const [settingsNotifications, setSettingsNotifications] = useState({
    emailNotifications: true,
    adminApplicationAlerts: true,
    weeklyReports: true,
    systemAlerts: true,
  });

  const [settingsSecurity, setSettingsSecurity] = useState({
    twoFactorAuth: false,
    passwordExpiry: 90,
    sessionTimeout: 30,
    ipRestriction: false,
  });

  const handleSaveSettings = () => {
    // In a real implementation, this would save to Supabase
    toast({
      title: t('admin.settings.saved'),
      description: t('admin.settings.saved'),
    });
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold">{t('admin.dashboard.settings')}</h1>
        </div>

        {/* General Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Globe className="h-5 w-5" />
              {t('common.general')} {t('admin.dashboard.settings')}
            </CardTitle>
            <CardDescription>
              Configure general platform settings
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">{t('common.siteName')}</label>
                <Input
                  value={settingsGeneral.siteName}
                  onChange={(e) => setSettingsGeneral({...settingsGeneral, siteName: e.target.value})}
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">{t('common.siteDescription')}</label>
                <Input
                  value={settingsGeneral.siteDescription}
                  onChange={(e) => setSettingsGeneral({...settingsGeneral, siteDescription: e.target.value})}
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">{t('common.adminEmail')}</label>
                <Input
                  type="email"
                  value={settingsGeneral.adminEmail}
                  onChange={(e) => setSettingsGeneral({...settingsGeneral, adminEmail: e.target.value})}
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">{t('common.supportEmail')}</label>
                <Input
                  type="email"
                  value={settingsGeneral.supportEmail}
                  onChange={(e) => setSettingsGeneral({...settingsGeneral, supportEmail: e.target.value})}
                />
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-end">
            <Button onClick={handleSaveSettings}>{t('admin.settings.save')}</Button>
          </CardFooter>
        </Card>
        
        {/* Notification Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bell className="h-5 w-5" />
              {t('common.notification')} {t('admin.dashboard.settings')}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">{t('common.emailNotifications')}</p>
                <p className="text-sm text-gray-500">{t('common.emailNotificationsDesc')}</p>
              </div>
              <Switch
                checked={settingsNotifications.emailNotifications}
                onCheckedChange={(checked) => setSettingsNotifications({...settingsNotifications, emailNotifications: checked})}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">{t('common.adminApplicationAlerts')}</p>
                <p className="text-sm text-gray-500">{t('common.adminApplicationAlertsDesc')}</p>
              </div>
              <Switch
                checked={settingsNotifications.adminApplicationAlerts}
                onCheckedChange={(checked) => setSettingsNotifications({...settingsNotifications, adminApplicationAlerts: checked})}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">{t('common.weeklyReports')}</p>
                <p className="text-sm text-gray-500">{t('common.weeklyReportsDesc')}</p>
              </div>
              <Switch
                checked={settingsNotifications.weeklyReports}
                onCheckedChange={(checked) => setSettingsNotifications({...settingsNotifications, weeklyReports: checked})}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">{t('common.systemAlerts')}</p>
                <p className="text-sm text-gray-500">{t('common.systemAlertsDesc')}</p>
              </div>
              <Switch
                checked={settingsNotifications.systemAlerts}
                onCheckedChange={(checked) => setSettingsNotifications({...settingsNotifications, systemAlerts: checked})}
              />
            </div>
          </CardContent>
          <CardFooter className="flex justify-end">
            <Button onClick={handleSaveSettings}>{t('admin.settings.save')}</Button>
          </CardFooter>
        </Card>
        
        {/* Security Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5" />
              {t('common.security')} {t('admin.dashboard.settings')}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">{t('common.twoFactorAuth')}</p>
                <p className="text-sm text-gray-500">{t('common.twoFactorAuthDesc')}</p>
              </div>
              <Switch
                checked={settingsSecurity.twoFactorAuth}
                onCheckedChange={(checked) => setSettingsSecurity({...settingsSecurity, twoFactorAuth: checked})}
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">{t('common.passwordExpiry')} (days)</label>
                <Input
                  type="number"
                  value={settingsSecurity.passwordExpiry}
                  onChange={(e) => setSettingsSecurity({...settingsSecurity, passwordExpiry: parseInt(e.target.value)})}
                  min="0"
                />
                <p className="text-xs text-gray-500">{t('common.passwordExpiryDesc')}</p>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">{t('common.sessionTimeout')} (minutes)</label>
                <Input
                  type="number"
                  value={settingsSecurity.sessionTimeout}
                  onChange={(e) => setSettingsSecurity({...settingsSecurity, sessionTimeout: parseInt(e.target.value)})}
                  min="5"
                />
                <p className="text-xs text-gray-500">{t('common.sessionTimeoutDesc')}</p>
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">{t('common.ipRestriction')}</p>
                <p className="text-sm text-gray-500">{t('common.ipRestrictionDesc')}</p>
              </div>
              <Switch
                checked={settingsSecurity.ipRestriction}
                onCheckedChange={(checked) => setSettingsSecurity({...settingsSecurity, ipRestriction: checked})}
              />
            </div>
          </CardContent>
          <CardFooter className="flex justify-end">
            <Button onClick={handleSaveSettings}>{t('admin.settings.save')}</Button>
          </CardFooter>
        </Card>
      </div>
    </AdminLayout>
  );
};

export default AdminSettings;
