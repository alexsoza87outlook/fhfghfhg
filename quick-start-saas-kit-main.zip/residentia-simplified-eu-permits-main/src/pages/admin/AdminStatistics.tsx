
import React from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import AdminLayout from '@/components/admin/AdminLayout';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const AdminStatistics: React.FC = () => {
  const { t } = useLanguage();

  // Mock data for applications over time
  const applicationTimeData = [
    { month: 'Jan', applications: 42, approved: 28, rejected: 8 },
    { month: 'Feb', applications: 47, approved: 32, rejected: 7 },
    { month: 'Mar', applications: 55, approved: 40, rejected: 10 },
    { month: 'Apr', applications: 58, approved: 38, rejected: 12 },
    { month: 'May', applications: 65, approved: 45, rejected: 15 },
    { month: 'Jun', applications: 72, approved: 55, rejected: 12 },
  ];

  // Mock data for application types
  const applicationTypesData = [
    { name: 'Student Stay', value: 28, color: '#4F46E5' },
    { name: 'Work Permit', value: 32, color: '#7C3AED' },
    { name: 'Family Reunification', value: 18, color: '#EC4899' },
    { name: 'Long-Term', value: 22, color: '#F59E0B' },
    { name: 'Remote Work', value: 14, color: '#10B981' },
  ];

  // Mock data for user registrations
  const userRegistrationData = [
    { day: 'Mon', registrations: 12 },
    { day: 'Tue', registrations: 18 },
    { day: 'Wed', registrations: 15 },
    { day: 'Thu', registrations: 22 },
    { day: 'Fri', registrations: 20 },
    { day: 'Sat', registrations: 14 },
    { day: 'Sun', registrations: 10 },
  ];

  // Mock data for processing times
  const processingTimeData = [
    { type: 'Student', time: 12 },
    { type: 'Work', time: 18 },
    { type: 'Family', time: 15 },
    { type: 'Long-Term', time: 24 },
    { type: 'Remote', time: 10 },
  ];

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold">{t('admin.dashboard.statistics')}</h1>
        </div>

        <Tabs defaultValue="applications">
          <TabsList className="mb-4">
            <TabsTrigger value="applications">Applications</TabsTrigger>
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="performance">Performance</TabsTrigger>
          </TabsList>
          
          <TabsContent value="applications" className="space-y-6">
            {/* Applications Over Time */}
            <Card>
              <CardHeader>
                <CardTitle>Applications Over Time</CardTitle>
                <CardDescription>Monthly application submissions, approvals, and rejections</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={applicationTimeData}
                      margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="applications" stroke="#4F46E5" strokeWidth={2} />
                      <Line type="monotone" dataKey="approved" stroke="#10B981" strokeWidth={2} />
                      <Line type="monotone" dataKey="rejected" stroke="#EF4444" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Application Types */}
            <Card>
              <CardHeader>
                <CardTitle>Application Types Distribution</CardTitle>
                <CardDescription>Distribution of different residence permit application types</CardDescription>
              </CardHeader>
              <CardContent className="flex flex-col md:flex-row items-center justify-center">
                <div className="h-64 w-full md:w-1/2">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={applicationTypesData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {applicationTypesData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="w-full md:w-1/2 grid grid-cols-2 gap-2 mt-4 md:mt-0">
                  {applicationTypesData.map((item) => (
                    <div key={item.name} className="flex items-center">
                      <div className="w-3 h-3 rounded-full mr-2" style={{ backgroundColor: item.color }}></div>
                      <span className="text-sm">{item.name}: {item.value}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            {/* Processing Times */}
            <Card>
              <CardHeader>
                <CardTitle>Average Processing Times</CardTitle>
                <CardDescription>Average processing time in days by application type</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={processingTimeData}
                      margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="type" />
                      <YAxis label={{ value: 'Days', angle: -90, position: 'insideLeft' }} />
                      <Tooltip />
                      <Bar dataKey="time" fill="#7C3AED" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="users" className="space-y-6">
            {/* User Registrations */}
            <Card>
              <CardHeader>
                <CardTitle>User Registrations</CardTitle>
                <CardDescription>New user registrations over the last 7 days</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={userRegistrationData}
                      margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="day" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="registrations" fill="#4F46E5" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            {/* More user statistics charts would go here */}
          </TabsContent>
          
          <TabsContent value="performance" className="space-y-6">
            {/* Performance metrics would go here */}
            <Card>
              <CardHeader>
                <CardTitle>System Performance</CardTitle>
                <CardDescription>Performance metrics for the application platform</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-center py-10 text-gray-500">Performance metrics will be implemented in a future update</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AdminLayout>
  );
};

export default AdminStatistics;
