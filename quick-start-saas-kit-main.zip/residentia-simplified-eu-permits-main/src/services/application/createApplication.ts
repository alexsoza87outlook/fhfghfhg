
import { supabase } from '@/integrations/supabase/client';
import { Application } from '@/types/application';

export async function createApplication(userId: string) {
  const { data, error } = await supabase
    .from('applications')
    .insert([
      { user_id: userId }
    ])
    .select()
    .single();
  
  if (error) throw error;
  return data as Application;
}
