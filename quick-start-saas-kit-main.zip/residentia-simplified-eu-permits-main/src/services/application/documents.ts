
import { supabase } from '@/integrations/supabase/client';
import { ApplicationDocument } from '@/types/application';

export async function uploadDocument(applicationId: string, userId: string, file: File, documentType: string) {
  // Create a unique file path
  const filePath = `${userId}/${applicationId}/${documentType}/${Date.now()}_${file.name}`;
  
  // Upload file to storage
  const { data: fileData, error: fileError } = await supabase.storage
    .from('application_documents')
    .upload(filePath, file);
  
  if (fileError) throw fileError;
  
  // Save document record in database
  const { data, error } = await supabase
    .from('application_documents')
    .insert([
      {
        application_id: applicationId,
        document_type: documentType,
        file_path: filePath,
        original_filename: file.name
      }
    ])
    .select()
    .single();
  
  if (error) throw error;
  return data as ApplicationDocument;
}

export async function getDocumentUrl(filePath: string) {
  const { data } = await supabase.storage
    .from('application_documents')
    .getPublicUrl(filePath);
  
  return data.publicUrl;
}
