
import { supabase } from '@/integrations/supabase/client';
import { Application } from '@/types/application';

export async function getApplicationById(applicationId: string) {
  // Get application base data
  const { data: application, error: applicationError } = await supabase
    .from('applications')
    .select('*')
    .eq('id', applicationId)
    .single();
  
  if (applicationError) throw applicationError;
  
  // Get personal details
  const { data: personalDetails, error: personalDetailsError } = await supabase
    .from('application_personal_details')
    .select('*')
    .eq('application_id', applicationId)
    .maybeSingle();
  
  // Get documents
  const { data: documents, error: documentsError } = await supabase
    .from('application_documents')
    .select('*')
    .eq('application_id', applicationId);
  
  return {
    ...application,
    personal_details: personalDetails || undefined,
    documents: documents || []
  } as Application;
}

export async function getApplicationsByUserId(userId: string) {
  const { data, error } = await supabase
    .from('applications')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  
  if (error) throw error;
  return data as Application[];
}

export async function getAllApplications() {
  // Fix the query to avoid using the foreign key relationship
  const { data: applications, error: applicationsError } = await supabase
    .from('applications')
    .select('*')
    .order('created_at', { ascending: false });
  
  if (applicationsError) throw applicationsError;
  
  // Get user profile information for each application
  if (applications && applications.length > 0) {
    // Get all user IDs from applications
    const userIds = applications.map(app => app.user_id);
    
    // Fetch all relevant user profiles in a single query
    const { data: profiles, error: profilesError } = await supabase
      .from('profiles')
      .select('id, full_name, email')
      .in('id', userIds);
    
    if (profilesError) throw profilesError;
    
    // Map profiles to applications
    const enrichedApplications = applications.map(app => {
      const userProfile = profiles?.find(profile => profile.id === app.user_id);
      return {
        ...app,
        user_profile: userProfile || { full_name: 'Unknown', email: 'Unknown' }
      };
    });
    
    return enrichedApplications as Application[];
  }
  
  return applications as Application[];
}
