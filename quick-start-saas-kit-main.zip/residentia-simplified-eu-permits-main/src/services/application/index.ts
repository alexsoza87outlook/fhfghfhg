
// Re-export all application service functions
export { createApplication } from './createApplication';
export { getApplicationById, getApplicationsByUserId, getAllApplications } from './getApplications';
export { updateApplicationStep, updateApplicationStatus, submitApplication, completePayment } from './updateApplication';
export { savePersonalDetails } from './personalDetails';
export { uploadDocument, getDocumentUrl } from './documents';
export { addStatusUpdate, getStatusUpdates } from './statusUpdates';
