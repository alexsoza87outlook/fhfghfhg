
import { supabase } from '@/integrations/supabase/client';
import { PersonalDetails } from '@/types/application';

export async function savePersonalDetails(applicationId: string, details: PersonalDetails) {
  // Check if personal details already exist
  const { data: existingData } = await supabase
    .from('application_personal_details')
    .select('id')
    .eq('application_id', applicationId)
    .maybeSingle();
  
  if (existingData) {
    // Update existing record
    const { data, error } = await supabase
      .from('application_personal_details')
      .update(details)
      .eq('application_id', applicationId)
      .select()
      .single();
    
    if (error) throw error;
    return data as PersonalDetails;
  } else {
    // Insert new record
    const { data, error } = await supabase
      .from('application_personal_details')
      .insert([
        { application_id: applicationId, ...details }
      ])
      .select()
      .single();
    
    if (error) throw error;
    return data as PersonalDetails;
  }
}
