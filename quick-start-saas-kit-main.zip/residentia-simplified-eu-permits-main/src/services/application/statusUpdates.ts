
import { supabase } from '@/integrations/supabase/client';
import { ApplicationStatus, StatusUpdate } from '@/types/application';

export async function addStatusUpdate(applicationId: string, userId: string, status: ApplicationStatus, comment?: string) {
  const { data, error } = await supabase
    .from('application_status_updates')
    .insert([
      {
        application_id: applicationId,
        status: status,
        comment: comment,
        created_by: userId
      }
    ])
    .select()
    .single();
  
  if (error) throw error;
  return data as StatusUpdate;
}

export async function getStatusUpdates(applicationId: string) {
  const { data, error } = await supabase
    .from('application_status_updates')
    .select('*')
    .eq('application_id', applicationId)
    .order('created_at', { ascending: false });
  
  if (error) throw error;
  return data as StatusUpdate[];
}
