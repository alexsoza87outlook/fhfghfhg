
import { supabase } from '@/integrations/supabase/client';
import { Application, ApplicationStatus, ApplicationStep, PaymentStatus } from '@/types/application';

export async function updateApplicationStep(applicationId: string, step: string) {
  const { data, error } = await supabase
    .from('applications')
    .update({ current_step: step })
    .eq('id', applicationId)
    .select()
    .single();
  
  if (error) throw error;
  return data as Application;
}

export async function updateApplicationStatus(applicationId: string, status: ApplicationStatus) {
  const { data, error } = await supabase
    .from('applications')
    .update({ status: status })
    .eq('id', applicationId)
    .select()
    .single();
  
  if (error) throw error;
  return data as Application;
}

export async function submitApplication(applicationId: string) {
  const now = new Date().toISOString();
  const { data, error } = await supabase
    .from('applications')
    .update({
      status: 'submitted' as ApplicationStatus,
      submitted_at: now
    })
    .eq('id', applicationId)
    .select()
    .single();
  
  if (error) throw error;
  return data as Application;
}

export async function completePayment(applicationId: string) {
  const { data, error } = await supabase
    .from('applications')
    .update({
      payment_status: 'completed' as PaymentStatus
    })
    .eq('id', applicationId)
    .select()
    .single();
  
  if (error) throw error;
  return data as Application;
}
