
import { TranslationSection } from './types';

export const adminTranslations: TranslationSection = {
  'admin.title': {
    en: 'Admin Dashboard',
    es: 'Panel de Administración'
  },
  'admin.login.title': {
    en: 'Admin Login',
    es: 'Acceso de Administrador'
  },
  'admin.login.subTitle': {
    en: 'Access the administrative panel',
    es: 'Accede al panel de administración'
  },
  'admin.register.title': {
    en: 'Admin Registration',
    es: 'Registro de Administrador'
  },
  'admin.register.subTitle': {
    en: 'Create an admin account to manage the platform',
    es: 'Crea una cuenta de administrador para gestionar la plataforma'
  },
  'admin.dashboard.overview': {
    en: 'Overview',
    es: 'Resumen'
  },
  'admin.dashboard.users': {
    en: 'Users',
    es: 'Usuarios'
  },
  'admin.dashboard.applications': {
    en: 'Applications',
    es: 'Solicitudes'
  },
  'admin.dashboard.settings': {
    en: 'Settings',
    es: 'Configuración'
  },
  'admin.dashboard.chatbot': {
    en: 'Chatbot',
    es: 'Chatbot'
  },
  'admin.dashboard.apiKeys': {
    en: 'API Keys',
    es: 'Claves API'
  },
  'admin.dashboard.statistics': {
    en: 'Statistics',
    es: 'Estadísticas'
  },
  'admin.dashboard.totalUsers': {
    en: 'Total Users',
    es: 'Total de Usuarios'
  },
  'admin.dashboard.totalApplications': {
    en: 'Total Applications',
    es: 'Total de Solicitudes'
  },
  'admin.dashboard.pendingApplications': {
    en: 'Pending Applications',
    es: 'Solicitudes Pendientes'
  },
  'admin.dashboard.completedApplications': {
    en: 'Completed Applications',
    es: 'Solicitudes Completadas'
  },
  'admin.dashboard.recentActivities': {
    en: 'Recent Activities',
    es: 'Actividades Recientes'
  },
  'admin.dashboard.recentActivitiesDescription': {
    en: 'The most recent activities on the platform',
    es: 'Las actividades más recientes en la plataforma'
  },
  'admin.dashboard.noRecentActivities': {
    en: 'No recent activities found',
    es: 'No se encontraron actividades recientes'
  },
  'admin.dashboard.systemStatus': {
    en: 'System Status',
    es: 'Estado del Sistema'
  },
  'admin.dashboard.chatbotStatus': {
    en: 'Chatbot Status',
    es: 'Estado del Chatbot'
  },
  'admin.dashboard.online': {
    en: 'Online',
    es: 'En línea'
  },
  'admin.dashboard.offline': {
    en: 'Offline',
    es: 'Desconectado'
  },
  'admin.dashboard.apiStatus': {
    en: 'API Status',
    es: 'Estado de la API'
  },
  'admin.dashboard.databaseStatus': {
    en: 'Database Status',
    es: 'Estado de la Base de datos'
  },
  'admin.users.name': {
    en: 'Name',
    es: 'Nombre'
  },
  'admin.users.email': {
    en: 'Email',
    es: 'Correo Electrónico'
  },
  'admin.users.role': {
    en: 'Role',
    es: 'Rol'
  },
  'admin.users.status': {
    en: 'Status',
    es: 'Estado'
  },
  'admin.users.actions': {
    en: 'Actions',
    es: 'Acciones'
  },
  'admin.users.lastLogin': {
    en: 'Last Login',
    es: 'Último Acceso'
  },
  'admin.applications.id': {
    en: 'ID',
    es: 'ID'
  },
  'admin.applications.type': {
    en: 'Type',
    es: 'Tipo'
  },
  'admin.applications.applicant': {
    en: 'Applicant',
    es: 'Solicitante'
  },
  'admin.applications.status': {
    en: 'Status',
    es: 'Estado'
  },
  'admin.applications.submissionDate': {
    en: 'Submission Date',
    es: 'Fecha de Envío'
  },
  'admin.applications.actions': {
    en: 'Actions',
    es: 'Acciones'
  },
  'admin.settings.apiConfiguration': {
    en: 'API Configuration',
    es: 'Configuración de API'
  },
  'admin.settings.openAI': {
    en: 'OpenAI Settings',
    es: 'Configuración de OpenAI'
  },
  'admin.settings.openAI.apiKey': {
    en: 'API Key',
    es: 'Clave API'
  },
  'admin.settings.openAI.model': {
    en: 'Model',
    es: 'Modelo'
  },
  'admin.settings.openAI.temperature': {
    en: 'Temperature',
    es: 'Temperatura'
  },
  'admin.settings.openAI.maxTokens': {
    en: 'Max Tokens',
    es: 'Máximo de Tokens'
  },
  'admin.settings.save': {
    en: 'Save Settings',
    es: 'Guardar Configuración'
  },
  'admin.settings.saved': {
    en: 'Settings saved successfully',
    es: 'Configuración guardada exitosamente'
  },
  'admin.chatbot.configuration': {
    en: 'Chatbot Configuration',
    es: 'Configuración del Chatbot'
  },
  'admin.chatbot.welcomeMessage': {
    en: 'Welcome Message',
    es: 'Mensaje de Bienvenida'
  },
  'admin.chatbot.promptTemplate': {
    en: 'Prompt Template',
    es: 'Plantilla de Prompt'
  },
  'admin.chatbot.fallbackMessage': {
    en: 'Fallback Message',
    es: 'Mensaje de Respaldo'
  },
  'admin.footer.adminSection': {
    en: 'Administration',
    es: 'Administración'
  },
  'admin.footer.adminLogin': {
    en: 'Admin Login',
    es: 'Acceso Admin'
  },
  'admin.footer.adminRegister': {
    en: 'Admin Register',
    es: 'Registro Admin'
  },
};
