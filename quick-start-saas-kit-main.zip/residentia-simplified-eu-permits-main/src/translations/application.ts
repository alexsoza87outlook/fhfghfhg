
import { TranslationSection } from './types';

export const applicationTranslations: TranslationSection = {
  'application.title': {
    en: 'Residence Permit Application',
    es: 'Solicitud de Permiso de Residencia'
  },
  'application.start': {
    en: 'Start Application',
    es: 'Iniciar Solicitud'
  },
  'application.continue': {
    en: 'Continue Application',
    es: 'Continuar Solicitud'
  },
  'application.submit': {
    en: 'Submit Application',
    es: 'Enviar Solicitud'
  },
  'application.save': {
    en: 'Save Progress',
    es: 'Guardar Progreso'
  },
  'application.next': {
    en: 'Next Step',
    es: 'Siguiente Paso'
  },
  'application.previous': {
    en: 'Previous Step',
    es: 'Paso Anterior'
  },
  'application.cancel': {
    en: 'Cancel',
    es: 'Cancelar'
  },
  'application.personalDetails': {
    en: 'Personal Details',
    es: 'Datos Personales'
  },
  'application.personalDetails.name': {
    en: 'Name',
    es: 'Nombre'
  },
  'application.personalDetails.firstName': {
    en: 'First Name',
    es: 'Nombre'
  },
  'application.personalDetails.firstLastName': {
    en: 'First Last Name',
    es: 'Primer Apellido'
  },
  'application.personalDetails.secondLastName': {
    en: 'Second Last Name',
    es: 'Segundo Apellido'
  },
  'application.personalDetails.contact': {
    en: 'Contact Information',
    es: 'Información de Contacto'
  },
  'application.personalDetails.email': {
    en: 'Email',
    es: 'Correo Electrónico'
  },
  'application.personalDetails.phone': {
    en: 'Phone Number',
    es: 'Número de Teléfono'
  },
  'application.personalDetails.address': {
    en: 'Address',
    es: 'Dirección'
  },
  'application.personalDetails.addressLine1': {
    en: 'Address Line 1',
    es: 'Dirección Línea 1'
  },
  'application.personalDetails.addressLine2': {
    en: 'Address Line 2',
    es: 'Dirección Línea 2'
  },
  'application.personalDetails.city': {
    en: 'City',
    es: 'Ciudad'
  },
  'application.personalDetails.state': {
    en: 'State/Province',
    es: 'Estado/Provincia'
  },
  'application.personalDetails.postalCode': {
    en: 'Postal Code',
    es: 'Código Postal'
  },
  'application.personalDetails.country': {
    en: 'Country',
    es: 'País'
  },
  'application.personalDetails.identification': {
    en: 'Identification',
    es: 'Identificación'
  },
  'application.personalDetails.passportNumber': {
    en: 'Passport Number',
    es: 'Número de Pasaporte'
  },
  'application.personalDetails.nie': {
    en: 'NIE (Foreigner ID Number)',
    es: 'NIE (Número de Identidad de Extranjero)'
  },
  'application.personalDetails.birthDetails': {
    en: 'Birth Details',
    es: 'Datos de Nacimiento'
  },
  'application.personalDetails.dateOfBirth': {
    en: 'Date of Birth',
    es: 'Fecha de Nacimiento'
  },
  'application.personalDetails.placeOfBirth': {
    en: 'Place of Birth',
    es: 'Lugar de Nacimiento'
  },
  'application.personalDetails.nationality': {
    en: 'Nationality',
    es: 'Nacionalidad'
  },
  'application.personalDetails.sex': {
    en: 'Sex',
    es: 'Sexo'
  },
  'application.personalDetails.male': {
    en: 'Male',
    es: 'Hombre'
  },
  'application.personalDetails.female': {
    en: 'Female',
    es: 'Mujer'
  },
  'application.personalDetails.other': {
    en: 'Other',
    es: 'Otro'
  },
  'application.documents': {
    en: 'Documents',
    es: 'Documentos'
  },
  'application.documents.upload': {
    en: 'Upload Documents',
    es: 'Subir Documentos'
  },
  'application.documents.passport': {
    en: 'Passport',
    es: 'Pasaporte'
  },
  'application.documents.photo': {
    en: 'Photo',
    es: 'Foto'
  },
  'application.documents.birthCertificate': {
    en: 'Birth Certificate',
    es: 'Certificado de Nacimiento'
  },
  'application.documents.marriageCertificate': {
    en: 'Marriage Certificate',
    es: 'Certificado de Matrimonio'
  },
  'application.documents.policeClearance': {
    en: 'Police Clearance',
    es: 'Certificado de Antecedentes Penales'
  },
  'application.documents.medicalCertificate': {
    en: 'Medical Certificate',
    es: 'Certificado Médico'
  },
  'application.documents.proofOfAccommodation': {
    en: 'Proof of Accommodation',
    es: 'Prueba de Alojamiento'
  },
  'application.documents.proofOfIncome': {
    en: 'Proof of Income',
    es: 'Prueba de Ingresos'
  },
  'application.documents.healthInsurance': {
    en: 'Health Insurance',
    es: 'Seguro de Salud'
  },
  'application.additionalDocuments': {
    en: 'Additional Documents',
    es: 'Documentos Adicionales'
  },
  'application.review': {
    en: 'Review Application',
    es: 'Revisar Solicitud'
  },
  'application.payment': {
    en: 'Payment',
    es: 'Pago'
  },
  'application.payment.amount': {
    en: 'Amount',
    es: 'Monto'
  },
  'application.payment.cardNumber': {
    en: 'Card Number',
    es: 'Número de Tarjeta'
  },
  'application.payment.expiryDate': {
    en: 'Expiry Date',
    es: 'Fecha de Vencimiento'
  },
  'application.payment.cvv': {
    en: 'CVV',
    es: 'CVV'
  },
  'application.payment.nameOnCard': {
    en: 'Name on Card',
    es: 'Nombre en la Tarjeta'
  },
  'application.payment.process': {
    en: 'Process Payment',
    es: 'Procesar Pago'
  },
  'application.success': {
    en: 'Application Submitted',
    es: 'Solicitud Enviada'
  },
  'application.success.message': {
    en: 'Your application has been submitted successfully!',
    es: '¡Su solicitud ha sido enviada con éxito!'
  },
  'application.trackingNumber': {
    en: 'Tracking Number',
    es: 'Número de Seguimiento'
  },
};
