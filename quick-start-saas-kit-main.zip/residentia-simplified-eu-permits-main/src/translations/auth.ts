
import { TranslationSection } from './types';

export const authTranslations: TranslationSection = {
  // Auth
  'auth.email': {
    en: 'Email',
    es: 'Correo Electrónico'
  },
  'auth.password': {
    en: 'Password',
    es: 'Contraseña'
  },
  'auth.confirmPassword': {
    en: 'Confirm Password',
    es: 'Confirmar Contraseña'
  },
  'auth.name': {
    en: 'Full Name',
    es: 'Nombre Completo'
  },
  'auth.fullNamePlaceholder': {
    en: 'Enter your full name',
    es: 'Ingrese su nombre completo'
  },
  'auth.login': {
    en: 'Login',
    es: 'Acceder'
  },
  'auth.signup': {
    en: 'Sign Up',
    es: 'Registrarse'
  },
  'auth.forgotPassword': {
    en: 'Forgot Password?',
    es: '¿Olvidó su Contraseña?'
  },
  'auth.processing': {
    en: 'Processing...',
    es: 'Procesando...'
  },
  'auth.noAccount': {
    en: "Don't have an account?",
    es: "¿No tiene una cuenta?"
  },
  'auth.alreadyAccount': {
    en: "Already have an account?",
    es: "¿Ya tiene una cuenta?"
  },
  'auth.loginDescription': {
    en: 'Enter your credentials to access your account',
    es: 'Ingrese sus credenciales para acceder a su cuenta'
  },
  'auth.signupDescription': {
    en: 'Create an account to start your application',
    es: 'Cree una cuenta para iniciar su solicitud'
  },
  'auth.solicitorLogin': {
    en: 'Solicitor Login',
    es: 'Acceso para Abogados'
  },
  'auth.solicitorSignup': {
    en: 'Solicitor Sign Up',
    es: 'Registro para Abogados'
  },
  'auth.solicitorLoginDescription': {
    en: 'Login for approved immigration solicitors',
    es: 'Acceso para abogados de inmigración aprobados'
  },
  'auth.solicitorSignupDescription': {
    en: 'Create an account as an approved immigration solicitor',
    es: 'Cree una cuenta como abogado de inmigración aprobado'
  },
  'auth.areSolicitor': {
    en: 'Are you a solicitor?',
    es: '¿Es usted un abogado?'
  },
  'auth.notSolicitor': {
    en: 'Not a solicitor?',
    es: '¿No es un abogado?'
  },
  'auth.solicitorLoginLink': {
    en: 'Login here',
    es: 'Acceda aquí'
  },
  'auth.regularLoginLink': {
    en: 'Regular user login',
    es: 'Acceso para usuarios regulares'
  },
  'auth.solicitorSignupLink': {
    en: 'Register here',
    es: 'Regístrese aquí'
  },
  'auth.regularSignupLink': {
    en: 'Regular user signup',
    es: 'Registro para usuarios regulares'
  },
  'auth.passwordsNotMatch': {
    en: 'Passwords do not match',
    es: 'Las contraseñas no coinciden'
  },
  'auth.errorSignup': {
    en: 'An error occurred during signup',
    es: 'Ocurrió un error durante el registro'
  }
};
