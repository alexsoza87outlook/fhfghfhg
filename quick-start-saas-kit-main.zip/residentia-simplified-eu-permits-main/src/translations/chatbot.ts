
import { TranslationSection } from './types';

export const chatbotTranslations: TranslationSection = {
  'chatbot.title': {
    en: 'ResidentIA',
    es: 'ResidentIA'
  },
  'chatbot.welcomeMessage': {
    en: 'Hello! I am ResidentIA, your virtual assistant for residence permits in Spain. How can I help you today?',
    es: '¡Hola! Soy ResidentIA, tu asistente virtual para permisos de residencia en España. ¿Cómo puedo ayudarte hoy?'
  },
  'chatbot.typingPlaceholder': {
    en: 'Type your message...',
    es: 'Escribe tu mensaje...'
  },
  'chatbot.send': {
    en: 'Send',
    es: 'Enviar'
  },
  'chatbot.error': {
    en: 'Error',
    es: 'Error'
  },
  'chatbot.errorMessage': {
    en: 'Sorry, I could not process your request. Please try again later.',
    es: 'Lo siento, no pude procesar tu solicitud. Por favor, inténtalo de nuevo más tarde.'
  },
};
