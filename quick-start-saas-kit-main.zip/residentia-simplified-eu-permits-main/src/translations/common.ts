
import { TranslationSection } from './types';

export const commonTranslations: TranslationSection = {
  // Navigation
  'nav.home': {
    en: 'Home',
    es: 'Inicio'
  },
  'nav.services': {
    en: 'Services',
    es: 'Servicios'
  },
  'nav.pricing': {
    en: 'Pricing',
    es: 'Precios'
  },
  'nav.about': {
    en: 'About Us',
    es: 'Sobre Nosotros'
  },
  'nav.contact': {
    en: 'Contact',
    es: 'Contacto'
  },
  'nav.login': {
    en: 'Login',
    es: 'Acceso'
  },
  'nav.signup': {
    en: 'Sign Up',
    es: 'Registrarse'
  },
  
  // Footer
  'footer.pages': {
    en: 'Pages',
    es: 'Páginas'
  },
  'footer.services': {
    en: 'Services',
    es: 'Servicios'
  },
  'footer.contact': {
    en: 'Contact',
    es: 'Contacto'
  },
  'footer.rightsReserved': {
    en: 'All rights reserved.',
    es: 'Todos los derechos reservados.'
  },
  'footer.privacyPolicy': {
    en: 'Privacy Policy',
    es: 'Política de Privacidad'
  },
  'footer.termsOfService': {
    en: 'Terms of Service',
    es: 'Términos de Servicio'
  },
  'footer.cookies': {
    en: 'Cookies',
    es: 'Cookies'
  },
  'footer.solicitorSection': {
    en: 'For Solicitors',
    es: 'Para Abogados'
  },
  
  // Services
  'services.workPermits': {
    en: 'Work Permits',
    es: 'Permisos de Trabajo'
  },
  'services.familyReunification': {
    en: 'Family Reunification',
    es: 'Reunificación Familiar'
  },
  'services.studentVisas': {
    en: 'Student Visas',
    es: 'Visados de Estudiante'
  },
  'services.blueCard': {
    en: 'EU Blue Card',
    es: 'Tarjeta Azul UE'
  },
  'services.citizenship': {
    en: 'Citizenship Applications',
    es: 'Solicitudes de Ciudadanía'
  }
};
