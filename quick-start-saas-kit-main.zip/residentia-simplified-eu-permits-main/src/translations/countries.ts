
import { TranslationSection } from './types';

export const countriesTranslations: TranslationSection = {
  // EU Countries
  'countries.spain': {
    en: 'Spain',
    es: 'España'
  },
  'countries.italy': {
    en: 'Italy',
    es: 'Italia'
  },
  'countries.france': {
    en: 'France',
    es: 'Francia'
  },
  'countries.portugal': {
    en: 'Portugal',
    es: 'Portugal'
  },
  'countries.czech': {
    en: 'Czech Republic',
    es: 'República Checa'
  },
  'countries.slovenia': {
    en: 'Slovenia',
    es: 'Eslovenia'
  },
  'countries.austria': {
    en: 'Austria',
    es: 'Austria'
  },
  'countries.greece': {
    en: 'Greece',
    es: 'Grecia'
  },
  'countries.poland': {
    en: 'Poland',
    es: 'Polonia'
  },
  'countries.hungary': {
    en: 'Hungary',
    es: 'Hungría'
  },
  'countries.croatia': {
    en: 'Croatia',
    es: 'Croacia'
  },
  'countries.slovakia': {
    en: 'Slovakia',
    es: 'Eslovaquia'
  },
  'countries.romania': {
    en: 'Romania',
    es: 'Rumanía'
  },
  'countries.bulgaria': {
    en: 'Bulgaria',
    es: 'Bulgaria'
  },
  'countries.germany': {
    en: 'Germany',
    es: 'Alemania'
  },
  'countries.netherlands': {
    en: 'Netherlands',
    es: 'Países Bajos'
  },
  'countries.belgium': {
    en: 'Belgium',
    es: 'Bélgica'
  },
  'countries.luxembourg': {
    en: 'Luxembourg',
    es: 'Luxemburgo'
  },
  'countries.denmark': {
    en: 'Denmark',
    es: 'Dinamarca'
  },
  'countries.sweden': {
    en: 'Sweden',
    es: 'Suecia'
  },
  'countries.finland': {
    en: 'Finland',
    es: 'Finlandia'
  },
  'countries.ireland': {
    en: 'Ireland',
    es: 'Irlanda'
  },
  'countries.estonia': {
    en: 'Estonia',
    es: 'Estonia'
  },
  'countries.latvia': {
    en: 'Latvia',
    es: 'Letonia'
  },
  'countries.lithuania': {
    en: 'Lithuania',
    es: 'Lituania'
  },
  'countries.malta': {
    en: 'Malta',
    es: 'Malta'
  },
  'countries.cyprus': {
    en: 'Cyprus',
    es: 'Chipre'
  },
  
  // Nationalities (countries of origin)
  'nationalities.afghanistan': {
    en: 'Afghanistan',
    es: 'Afganistán'
  },
  'nationalities.albania': {
    en: 'Albania',
    es: 'Albania'
  },
  'nationalities.algeria': {
    en: 'Algeria',
    es: 'Argelia'
  },
  'nationalities.argentina': {
    en: 'Argentina',
    es: 'Argentina'
  },
  'nationalities.australia': {
    en: 'Australia',
    es: 'Australia'
  },
  'nationalities.brazil': {
    en: 'Brazil',
    es: 'Brasil'
  },
  'nationalities.canada': {
    en: 'Canada',
    es: 'Canadá'
  },
  'nationalities.china': {
    en: 'China',
    es: 'China'
  },
  'nationalities.colombia': {
    en: 'Colombia',
    es: 'Colombia'
  },
  'nationalities.egypt': {
    en: 'Egypt',
    es: 'Egipto'
  },
  'nationalities.india': {
    en: 'India',
    es: 'India'
  },
  'nationalities.indonesia': {
    en: 'Indonesia',
    es: 'Indonesia'
  },
  'nationalities.japan': {
    en: 'Japan',
    es: 'Japón'
  },
  'nationalities.mexico': {
    en: 'Mexico',
    es: 'México'
  },
  'nationalities.morocco': {
    en: 'Morocco',
    es: 'Marruecos'
  },
  'nationalities.nigeria': {
    en: 'Nigeria',
    es: 'Nigeria'
  },
  'nationalities.pakistan': {
    en: 'Pakistan',
    es: 'Pakistán'
  },
  'nationalities.philippines': {
    en: 'Philippines',
    es: 'Filipinas'
  },
  'nationalities.russia': {
    en: 'Russia',
    es: 'Rusia'
  },
  'nationalities.saudiArabia': {
    en: 'Saudi Arabia',
    es: 'Arabia Saudita'
  },
  'nationalities.southAfrica': {
    en: 'South Africa',
    es: 'Sudáfrica'
  },
  'nationalities.southKorea': {
    en: 'South Korea',
    es: 'Corea del Sur'
  },
  'nationalities.thailand': {
    en: 'Thailand',
    es: 'Tailandia'
  },
  'nationalities.turkey': {
    en: 'Turkey',
    es: 'Turquía'
  },
  'nationalities.uae': {
    en: 'United Arab Emirates',
    es: 'Emiratos Árabes Unidos'
  },
  'nationalities.uk': {
    en: 'United Kingdom',
    es: 'Reino Unido'
  },
  'nationalities.usa': {
    en: 'United States of America',
    es: 'Estados Unidos de América'
  },
  'nationalities.venezuela': {
    en: 'Venezuela',
    es: 'Venezuela'
  },
  'nationalities.vietnam': {
    en: 'Vietnam',
    es: 'Vietnam'
  }
  // Add more countries as needed
};
