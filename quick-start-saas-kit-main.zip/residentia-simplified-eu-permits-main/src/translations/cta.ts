
import { TranslationSection } from './types';

export const ctaTranslations: TranslationSection = {
  // CTA section
  'cta.title': {
    en: 'Let ResidentIA Handle the Paperwork—So You Can Focus on Living',
    es: 'Deje que ResidentIA se Encargue del Papeleo—Para Que Usted Pueda Centrarse en Vivir'
  },
  'cta.description': {
    en: "Applying for a residence permit shouldn't feel like a second job. With ResidentIA, you get real legal support, a fully digital experience, and peace of mind. Whether you're moving for work, love, study, or retirement—ResidentIA is the easiest way to get your residence permit without confusion, calls, or legal risk.",
    es: 'Solicitar un permiso de residencia no debería sentirse como un segundo trabajo. Con ResidentIA, obtiene apoyo legal real, una experiencia totalmente digital y tranquilidad. Ya sea que se mude por trabajo, amor, estudio o jubilación—ResidentIA es la forma más fácil de obtener su permiso de residencia sin confusión, llamadas o riesgo legal.'
  },
  'cta.button': {
    en: 'Get Started Now',
    es: 'Comience Ahora'
  }
};
