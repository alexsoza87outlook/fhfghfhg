
import { userDashboardTranslations } from './dashboard/index';
import { solicitorDashboardTranslations } from './solicitor/index';

// Re-export both translation sections
export const dashboardTranslations = {
  ...userDashboardTranslations,
  ...solicitorDashboardTranslations
};
