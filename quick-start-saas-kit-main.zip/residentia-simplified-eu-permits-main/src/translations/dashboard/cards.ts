
import { TranslationSection } from '../types';

export const dashboardCardsTranslations: TranslationSection = {
  'dashboard.cards.status.title': {
    'en': 'Application Status',
    'es': 'Estado de la Solicitud'
  },
  'dashboard.cards.status.description': {
    'en': 'Track your current application',
    'es': 'Sigue tu solicitud actual'
  },
  'dashboard.cards.status.review': {
    'en': 'Documents Under Review',
    'es': 'Documentos en Revisión'
  },
  'dashboard.cards.status.message': {
    'en': 'Our legal team is reviewing your uploaded documents.',
    'es': 'Nuestro equipo legal está revisando los documentos subidos.'
  },
  'dashboard.cards.status.noApplications': {
    'en': 'You have not started any applications yet.',
    'es': 'Aún no has comenzado ninguna solicitud.'
  },
  'dashboard.cards.status.draft': {
    'en': 'Draft',
    'es': 'Borrador'
  },
  'dashboard.cards.status.submitted': {
    'en': 'Submitted',
    'es': 'Enviada'
  },
  'dashboard.cards.status.approved': {
    'en': 'Approved',
    'es': 'Aprobada'
  },
  'dashboard.cards.status.rejected': {
    'en': 'Rejected',
    'es': 'Rechazada'
  },
  'dashboard.cards.status.docs': {
    'en': 'Additional Documents Required',
    'es': 'Documentos Adicionales Requeridos'
  },
  'dashboard.cards.status.none': {
    'en': 'No Applications',
    'es': 'Sin Solicitudes'
  },
  'dashboard.cards.nextsteps.title': {
    'en': 'Next Steps',
    'es': 'Próximos Pasos'
  },
  'dashboard.cards.nextsteps.description': {
    'en': 'What you need to do',
    'es': 'Lo que necesitas hacer'
  },
  'dashboard.cards.nextsteps.biometric': {
    'en': 'Schedule Biometric Appointment',
    'es': 'Programar Cita Biométrica'
  },
  'dashboard.cards.nextsteps.message': {
    'en': 'Please schedule your biometric data collection appointment.',
    'es': 'Por favor, programa tu cita para la recolección de datos biométricos.'
  },
  'dashboard.cards.support.title': {
    'en': 'Support',
    'es': 'Soporte'
  },
  'dashboard.cards.support.description': {
    'en': 'Get help with your application',
    'es': 'Obtén ayuda con tu solicitud'
  },
  'dashboard.cards.support.questions': {
    'en': 'Have questions?',
    'es': '¿Tienes preguntas?'
  },
  'dashboard.cards.support.message': {
    'en': 'Contact your dedicated immigration expert for assistance.',
    'es': 'Contacta a tu experto en inmigración dedicado para asistencia.'
  }
};
