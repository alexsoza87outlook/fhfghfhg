
import { TranslationSection } from '../types';

export const dashboardCommonTranslations: TranslationSection = {
  'common.cancel': {
    'en': 'Cancel',
    'es': 'Cancelar'
  }
};
