
import { TranslationSection } from '../types';
import { dashboardCommonTranslations } from './common';
import { dashboardStatusTranslations } from './status';
import { dashboardTimelineTranslations } from './timeline';
import { dashboardWelcomeTranslations } from './welcome';
import { dashboardCardsTranslations } from './cards';

// Merge all dashboard translation sections
export const userDashboardTranslations: TranslationSection = {
  ...dashboardCommonTranslations,
  ...dashboardStatusTranslations,
  ...dashboardTimelineTranslations,
  ...dashboardWelcomeTranslations,
  ...dashboardCardsTranslations
};
