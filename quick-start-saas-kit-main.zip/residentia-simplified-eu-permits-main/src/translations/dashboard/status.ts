
import { TranslationSection } from '../types';

export const dashboardStatusTranslations: TranslationSection = {
  'dashboard.applicationStatus.current': {
    'en': 'Current Status',
    'es': 'Estado Actual'
  },
  'dashboard.applicationStatus.draft': {
    'en': 'Draft',
    'es': 'Borrador'
  },
  'dashboard.applicationStatus.submitted': {
    'en': 'Submitted',
    'es': 'Enviada'
  },
  'dashboard.applicationStatus.underReview': {
    'en': 'Under Review',
    'es': 'En Revisión'
  },
  'dashboard.applicationStatus.docsRequired': {
    'en': 'Additional Documents Required',
    'es': 'Documentos Adicionales Requeridos'
  },
  'dashboard.applicationStatus.approved': {
    'en': 'Approved',
    'es': 'Aprobada'
  },
  'dashboard.applicationStatus.rejected': {
    'en': 'Rejected',
    'es': 'Rechazada'
  },
  'dashboard.applicationStatus.completed': {
    'en': 'Completed',
    'es': 'Completada'
  }
};
