
import { TranslationSection } from '../types';

export const dashboardTimelineTranslations: TranslationSection = {
  'dashboard.timeline.title': {
    'en': 'Application Timeline',
    'es': 'Cronología de la Solicitud'
  },
  'dashboard.timeline.step1.title': {
    'en': 'Eligibility Check Completed',
    'es': 'Verificación de Elegibilidad Completada'
  },
  'dashboard.timeline.step1.date': {
    'en': 'May 10, 2025',
    'es': '10 de Mayo, 2025'
  },
  'dashboard.timeline.step2.title': {
    'en': 'Documents Uploaded',
    'es': 'Documentos Subidos'
  },
  'dashboard.timeline.step2.date': {
    'en': 'May 15, 2025',
    'es': '15 de Mayo, 2025'
  },
  'dashboard.timeline.step3.title': {
    'en': 'Legal Review In Progress',
    'es': 'Revisión Legal En Curso'
  },
  'dashboard.timeline.step3.status': {
    'en': 'Current Step',
    'es': 'Paso Actual'
  },
  'dashboard.timeline.step4.title': {
    'en': 'Biometric Appointment',
    'es': 'Cita Biométrica'
  },
  'dashboard.timeline.step4.date': {
    'en': 'Scheduled for May 25, 2025',
    'es': 'Programado para el 25 de Mayo, 2025'
  },
  'dashboard.timeline.step5.title': {
    'en': 'Permit Approval',
    'es': 'Aprobación del Permiso'
  },
  'dashboard.timeline.step5.date': {
    'en': 'Expected by June 15, 2025',
    'es': 'Esperado para el 15 de Junio, 2025'
  },
  'dashboard.applicationTimeline.applicationStarted': {
    'en': 'Application Started',
    'es': 'Solicitud Iniciada'
  },
  'dashboard.applicationTimeline.applicationSubmitted': {
    'en': 'Application Submitted',
    'es': 'Solicitud Enviada'
  },
  'dashboard.applicationTimeline.legalReview': {
    'en': 'Legal Review In Progress',
    'es': 'Revisión Legal En Curso'
  },
  'dashboard.applicationTimeline.applicationApproved': {
    'en': 'Application Approved',
    'es': 'Solicitud Aprobada'
  },
  'dashboard.applicationTimeline.applicationRejected': {
    'en': 'Application Rejected',
    'es': 'Solicitud Rechazada'
  },
  'dashboard.applicationTimeline.docsRequested': {
    'en': 'Additional Documents Requested',
    'es': 'Documentos Adicionales Solicitados'
  }
};
