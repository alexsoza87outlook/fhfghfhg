
import { TranslationSection } from '../types';

export const dashboardWelcomeTranslations: TranslationSection = {
  'dashboard.welcome': {
    'en': 'Welcome, {name}',
    'es': 'Bienvenido/a, {name}'
  },
  'dashboard.loading': {
    'en': 'Loading your dashboard...',
    'es': 'Cargando tu panel de control...'
  },
  'dashboard.startApplication': {
    'en': 'Start Application',
    'es': 'Iniciar Solicitud'
  }
};
