
import { TranslationSection } from './types';

export const eligibilityTranslations: TranslationSection = {
  // Country Selector
  'eligibility.selectCountry': {
    en: 'Select Country',
    es: 'Seleccionar País'
  },
  'eligibility.available': {
    en: 'Available',
    es: 'Disponible'
  },
  'eligibility.comingSoon': {
    en: 'Coming Soon',
    es: 'Próximamente'
  },

  // Authorization Type
  'eligibility.selectAuthorizationType': {
    en: 'Select Authorization Type',
    es: 'Seleccionar Tipo de Autorización'
  },
  'eligibility.initialResidence': {
    en: 'Initial Residence Applications',
    es: 'Solicitudes Iniciales de Residencia'
  },
  'eligibility.initialResidenceDescription': {
    en: 'For first-time residence authorization in {country}',
    es: 'Para autorización de residencia por primera vez en {country}'
  },
  'eligibility.residenceRenewal': {
    en: 'Residence Renewal',
    es: 'Renovación de Residencia'
  },
  'eligibility.residenceRenewalDescription': {
    en: 'To Renew your current residence authorization',
    es: 'Para renovar su autorización de residencia actual'
  },

  // Nationality Selector
  'eligibility.selectNationality': {
    en: 'Select Your Country of Nationality',
    es: 'Seleccione Su País de Nacionalidad'
  },
  'eligibility.findRightAuthorization': {
    en: 'Find the right residence authorization for you. Answer a few questions to help us identify the most relevant authorization options for your situation.',
    es: 'Encuentre la autorización de residencia adecuada para usted. Responda algunas preguntas para ayudarnos a identificar las opciones de autorización más relevantes para su situación.'
  },
  'eligibility.searchCountry': {
    en: 'Search country',
    es: 'Buscar país'
  },

  // Renewal Type Selector
  'eligibility.selectAuthorizationPhase': {
    en: 'Select Authorization Phase',
    es: 'Seleccionar Fase de Autorización'
  },
  'eligibility.renewalOrExtension': {
    en: 'Renewal or Extension',
    es: 'Renovación o Prórroga'
  },
  'eligibility.standardRenewalDescription': {
    en: 'Standard renewal of your current authorization',
    es: 'Renovación estándar de su autorización actual'
  },
  'eligibility.longTermResidence': {
    en: 'Long-term Residence 5 Years',
    es: 'Residencia de Larga Duración 5 Años'
  },
  'eligibility.longTermResidenceDescription': {
    en: 'For residents who have legally lived in {country} for 5 years',
    es: 'Para residentes que han vivido legalmente en {country} durante 5 años'
  },
  'eligibility.others': {
    en: 'Others',
    es: 'Otros'
  },
  'eligibility.othersDescription': {
    en: 'Other types of renewals or notifications',
    es: 'Otros tipos de renovaciones o notificaciones'
  },

  // Toasts and Notifications
  'eligibility.nationalitySelected': {
    en: 'Nationality Selected',
    es: 'Nacionalidad Seleccionada'
  },
  'eligibility.renewalTypeSelected': {
    en: 'Renewal Type Selected',
    es: 'Tipo de Renovación Seleccionado'
  },
  'eligibility.redirectingToForm': {
    en: 'Redirecting to the application form...',
    es: 'Redirigiendo al formulario de solicitud...'
  }
};
