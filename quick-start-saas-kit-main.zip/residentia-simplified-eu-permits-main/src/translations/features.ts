
import { TranslationSection } from './types';

export const featuresTranslations: TranslationSection = {
  // Benefits section
  'benefits.title': {
    en: 'Your Residence Permit, Handled by Real Immigration Experts—Made Digital',
    es: 'Su Permiso de Residencia, Gestionado por Expertos en Inmigración—Hecho Digital'
  },
  'benefits.online': {
    en: '100% Online – Apply anytime, from anywhere',
    es: '100% Online – Solicite en cualquier momento, desde cualquier lugar'
  },
  'benefits.qualified': {
    en: 'Qualified Immigration Solicitors – We handle the legal part, so you don\'t have to',
    es: 'Abogados de Inmigración Cualificados – Nos encargamos de la parte legal, para que usted no tenga que hacerlo'
  },
  'benefits.pricing': {
    en: 'Flat, Transparent Pricing – No hourly rates. No surprises. Government fees included',
    es: 'Precios Planos y Transparentes – Sin tarifas por hora. Sin sorpresas. Tasas gubernamentales incluidas'
  },
  'benefits.multilingual': {
    en: 'Multilingual Platform – English + local document templates per country',
    es: 'Plataforma Multilingüe – Inglés + plantillas de documentos locales por país'
  },
  'benefits.tracker': {
    en: 'Real-Time Application Tracker – Know exactly what\'s done, and what\'s next',
    es: 'Seguimiento de Solicitudes en Tiempo Real – Sepa exactamente qué está hecho y qué sigue'
  },
  'benefits.nocalls': {
    en: 'No Video Calls or Interviews Needed',
    es: 'Sin Necesidad de Videollamadas o Entrevistas'
  },
  'benefits.guarantee': {
    en: 'Money-Back Guarantee – If your application is denied due to our mistake',
    es: 'Garantía de Devolución – Si su solicitud es denegada debido a nuestro error'
  },
  'benefits.klarna': {
    en: 'Pay with Klarna – Split your payment into 3 or pay later, interest-free',
    es: 'Pague con Klarna – Divida su pago en 3 o pague más tarde, sin intereses'
  },
  
  // Comparison section
  'comparison.title': {
    en: 'ResidentIA vs Traditional Solicitors',
    es: 'ResidentIA vs Abogados Tradicionales'
  },
  'comparison.feature1': {
    en: 'Apply From Anywhere, Anytime',
    es: 'Solicite Desde Cualquier Lugar, En Cualquier Momento'
  },
  'comparison.feature2': {
    en: 'Government Fees Included',
    es: 'Tasas Gubernamentales Incluidas'
  },
  'comparison.feature3': {
    en: 'Pay in Installments (Klarna)',
    es: 'Pague en Cuotas (Klarna)'
  },
  'comparison.feature4': {
    en: 'No Zoom or Video Calls Required',
    es: 'Sin Necesidad de Zoom o Videollamadas'
  },
  'comparison.feature5': {
    en: 'Personalized Checklist Generator',
    es: 'Generador de Lista de Verificación Personalizada'
  },
  'comparison.feature6': {
    en: 'Legal Review by Solicitor',
    es: 'Revisión Legal por Abogado'
  },
  'comparison.feature7': {
    en: 'Real-Time Status Tracking',
    es: 'Seguimiento de Estado en Tiempo Real'
  },
  'comparison.feature8': {
    en: 'Transparent Flat Pricing',
    es: 'Precios Planos Transparentes'
  },
  'comparison.feature9': {
    en: 'Money-Back Guarantee',
    es: 'Garantía de Devolución'
  },
  'comparison.yes': {
    en: 'Yes',
    es: 'Sí'
  },
  'comparison.no': {
    en: 'No',
    es: 'No'
  },
  'comparison.no.extra': {
    en: 'Usually Extra',
    es: 'Normalmente Extra'
  },
  'comparison.no.required': {
    en: 'Usually Required',
    es: 'Normalmente Requerido'
  },
  'comparison.no.manual': {
    en: 'Manual Only',
    es: 'Solo Manual'
  },
  'comparison.no.common': {
    en: 'Not Common',
    es: 'No es Común'
  },
  'comparison.no.hourly': {
    en: 'Hourly/Variable Fees',
    es: 'Tarifas por Hora/Variables'
  },
  'comparison.no.refunds': {
    en: 'No Refunds',
    es: 'Sin Reembolsos'
  }
};
