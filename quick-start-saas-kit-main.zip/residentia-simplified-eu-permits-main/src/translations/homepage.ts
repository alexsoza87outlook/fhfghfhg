
import { TranslationSection } from './types';

export const homepageTranslations: TranslationSection = {
  // Hero section
  'hero.title': {
    en: 'Your Residence Permit, Managed by AI — 100% Online',
    es: 'Tu Permiso de Residencia, Gestionado por IA — 100% Online'
  },
  'hero.subtitle': {
    en: 'No video calls. No in-person visits. No paperwork confusion. No legal guesswork. No high lawyer fees.',
    es: 'Sin videollamadas. Sin visitas presenciales. Sin confusión de papeleo. Sin conjeturas legales. Sin altas tarifas de abogados.'
  },
  'hero.cta.check': {
    en: 'Check Your Eligibility',
    es: 'Compruebe Su Elegibilidad'
  },
  'hero.cta.start': {
    en: 'Start My Application',
    es: 'Iniciar Mi Solicitud'
  },
  'hero.cta.or': {
    en: 'Or',
    es: 'O'
  },
  'hero.trust.novideo': {
    en: 'No Video Calls, No In-person visits',
    es: 'Sin Videollamadas, Sin Visitas Presenciales'
  },
  'hero.trust.klarna': {
    en: 'Klarna: Pay Later or in Installments',
    es: 'Klarna: Pague Después o en Cuotas'
  },
  'hero.trust.guarantee': {
    en: 'Money-Back Guarantee',
    es: 'Garantía de Devolución'
  },
  'hero.trust.fees': {
    en: 'Government Fees Included',
    es: 'Tasas Gubernamentales Incluidas'
  },
  'hero.trust.verified': {
    en: 'Solicitor-Verified',
    es: 'Verificado por Abogados'
  },
  'hero.badge': {
    en: 'AI-Powered Residence Permit',
    es: 'Permiso de Residencia con IA'
  },
  
  // Problem section
  'problem.title': {
    en: 'Tired of EU Immigration Bureaucracy? So Were We.',
    es: '¿Cansado de la Burocracia de Inmigración de la UE? Nosotros También.'
  },
  'problem.intro': {
    en: "If you've already entered an EU country visa-free and want to stay longer, you've probably faced this:",
    es: "Si ya ha entrado en un país de la UE sin visado y quiere quedarse más tiempo, probablemente se ha enfrentado a esto:"
  },
  'problem.issue1': {
    en: 'No clear information on which permit to apply for',
    es: 'Sin información clara sobre qué permiso solicitar'
  },
  'problem.issue2': {
    en: 'Confusing checklists with missing or outdated requirements',
    es: 'Listas de verificación confusas con requisitos faltantes o desactualizados'
  },
  'problem.issue3': {
    en: 'Unsure if you need translations, legalizations, or certified copies',
    es: 'Dudas sobre si necesita traducciones, legalizaciones o copias certificadas'
  },
  'problem.issue4': {
    en: "Don't know how many copies, where to pay, or what form to use",
    es: 'No sabe cuántas copias, dónde pagar o qué formulario usar'
  },
  'problem.issue5': {
    en: 'Appointment booking systems are full for months',
    es: 'Los sistemas de reserva de citas están completos durante meses'
  },
  'problem.issue6': {
    en: 'Government websites are incomplete or only in local language',
    es: 'Los sitios web gubernamentales están incompletos o solo en idioma local'
  },
  'problem.issue7': {
    en: "You're wasting time, unsure who to trust—or spending €€€ on traditional lawyers",
    es: 'Está perdiendo tiempo, sin saber en quién confiar, o gastando €€€ en abogados tradicionales'
  },
  'problem.solution': {
    en: 'ResidentIA fixes all of that.',
    es: 'ResidentIA soluciona todo eso.'
  },
  
  // Steps section
  'steps.title': {
    en: 'Apply in 3 Steps—With a Legal Team on Your Side',
    es: 'Solicite en 3 Pasos—Con un Equipo Legal a Su Lado'
  },
  'steps.check.title': {
    en: 'AI-Powered Eligibility Check',
    es: 'Verificación de Elegibilidad con IA'
  },
  'steps.check.description': {
    en: "Tell us where you are and what you're doing. We'll instantly match you to the right residence permit type.",
    es: 'Díganos dónde está y qué está haciendo. Le emparejaremos instantáneamente con el tipo de permiso de residencia adecuado.'
  },
  'steps.upload.title': {
    en: 'Upload Documents',
    es: 'Suba Documentos'
  },
  'steps.upload.description': {
    en: 'We generate a personalized checklist. Upload your docs securely. Our solicitors check everything and prepare the application for submission.',
    es: 'Generamos una lista personalizada. Suba sus documentos de forma segura. Nuestros abogados comprueban todo y preparan la solicitud para su presentación.'
  },
  'steps.biometric.title': {
    en: 'Attend Your Biometric Appointment',
    es: 'Asista a Su Cita Biométrica'
  },
  'steps.biometric.description': {
    en: 'We guide you to schedule the appointment with the local immigration office—no calls, no guesswork.',
    es: 'Le guiamos para programar la cita con la oficina de inmigración local—sin llamadas, sin conjeturas.'
  }
};
