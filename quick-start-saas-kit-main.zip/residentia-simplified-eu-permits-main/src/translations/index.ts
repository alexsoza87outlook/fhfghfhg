
import { TranslationSection } from './types';
import { commonTranslations } from './common';
import { homepageTranslations } from './homepage';
import { featuresTranslations } from './features';
import { testimonialsTranslations } from './testimonials';
import { locationsTranslations } from './locations';
import { pricingTranslations } from './pricing';
import { ctaTranslations } from './cta';
import { applicationTranslations } from './application';
import { eligibilityTranslations } from './eligibility';
import { dashboardTranslations } from './dashboard';
import { userDashboardTranslations } from './user-dashboard';
import { solicitorDashboardTranslations } from './solicitor-dashboard';
import { residenceTranslations } from './residence';
import { authTranslations } from './auth';
import { chatbotTranslations } from './chatbot';
import { adminTranslations } from './admin';
import { countriesTranslations } from './countries';

// Merge all translation sections
const allTranslations: TranslationSection = {
  ...commonTranslations,
  ...homepageTranslations,
  ...featuresTranslations,
  ...testimonialsTranslations,
  ...locationsTranslations,
  ...pricingTranslations,
  ...ctaTranslations,
  ...applicationTranslations,
  ...eligibilityTranslations,
  ...dashboardTranslations,
  ...userDashboardTranslations,
  ...solicitorDashboardTranslations,
  ...residenceTranslations,
  ...authTranslations,
  ...chatbotTranslations,
  ...adminTranslations,
  ...countriesTranslations
};

export default allTranslations;
