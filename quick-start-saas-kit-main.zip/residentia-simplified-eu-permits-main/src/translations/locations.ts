
import { TranslationSection } from './types';

export const locationsTranslations: TranslationSection = {
  // Where we operate
  'operate.title': {
    en: 'Your Virtual Solicitor in 14+ EU Countries',
    es: 'Su Abogado Virtual en más de 14 Países de la UE'
  },
  'operate.subtitle': {
    en: 'We help visa-free nationals apply for residence permits from within the EU after arrival.',
    es: 'Ayudamos a nacionales sin visado a solicitar permisos de residencia desde dentro de la UE después de su llegada.'
  },
  'operate.country.spain': {
    en: 'Spain',
    es: 'España'
  },
  'operate.country.italy': {
    en: 'Italy',
    es: 'Italia'
  },
  'operate.country.france': {
    en: 'France',
    es: 'Francia'
  },
  'operate.country.portugal': {
    en: 'Portugal',
    es: 'Portugal'
  },
  'operate.country.czech': {
    en: 'Czech Republic',
    es: 'República Checa'
  },
  'operate.country.slovenia': {
    en: 'Slovenia',
    es: 'Eslovenia'
  },
  'operate.country.austria': {
    en: 'Austria',
    es: 'Austria'
  },
  'operate.country.greece': {
    en: 'Greece',
    es: 'Grecia'
  },
  'operate.country.poland': {
    en: 'Poland',
    es: 'Polonia'
  },
  'operate.country.hungary': {
    en: 'Hungary',
    es: 'Hungría'
  },
  'operate.country.croatia': {
    en: 'Croatia',
    es: 'Croacia'
  },
  'operate.country.slovakia': {
    en: 'Slovakia',
    es: 'Eslovaquia'
  },
  'operate.country.romania': {
    en: 'Romania',
    es: 'Rumanía'
  },
  'operate.country.bulgaria': {
    en: 'Bulgaria',
    es: 'Bulgaria'
  },
  
  // Who it's for
  'who.title': {
    en: 'We Help People Like You, Every Day',
    es: 'Ayudamos a Personas Como Usted, Todos los Días'
  },
  'who.digital': {
    en: 'Digital Nomads & Remote Workers',
    es: 'Nómadas Digitales y Trabajadores Remotos'
  },
  'who.students': {
    en: 'Students Accepted into EU Universities',
    es: 'Estudiantes Aceptados en Universidades de la UE'
  },
  'who.citizens': {
    en: 'UK/US Citizens Staying Long-Term',
    es: 'Ciudadanos del Reino Unido/EE.UU. que se Quedan a Largo Plazo'
  },
  'who.family': {
    en: 'Spouses and Family Members of EU Citizens',
    es: 'Cónyuges y Miembros de la Familia de Ciudadanos de la UE'
  },
  'who.entrepreneurs': {
    en: 'Entrepreneurs, Freelancers, and Startup Founders',
    es: 'Empresarios, Autónomos y Fundadores de Startups'
  },
  'who.retirees': {
    en: 'Retirees Relocating to Europe, Anyone that meets the requirements',
    es: 'Jubilados que se Trasladan a Europa, Cualquiera que cumpla los requisitos'
  }
};
