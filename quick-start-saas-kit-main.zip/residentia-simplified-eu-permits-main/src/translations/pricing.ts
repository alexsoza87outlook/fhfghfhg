
import { TranslationSection } from './types';

export const pricingTranslations: TranslationSection = {
  // Pricing section
  'pricing.title': {
    en: 'One Flat Price. Flexible Payment Options.',
    es: 'Un Precio Único. Opciones de Pago Flexibles.'
  },
  'pricing.subtitle': {
    en: 'Starting at €149.99 based on permit type and country.',
    es: 'Desde €149.99 según el tipo de permiso y país.'
  },
  'pricing.included': {
    en: "What's Included:",
    es: 'Qué Incluye:'
  },
  'pricing.fees': {
    en: 'Government Filing Fees',
    es: 'Tasas Gubernamentales de Presentación'
  },
  'pricing.ai': {
    en: 'AI-Powered Permit Match & Document Checklist',
    es: 'Emparejamiento de Permisos con IA y Lista de Verificación de Documentos'
  },
  'pricing.legal': {
    en: 'Legal Review by Certified Immigration Solicitor',
    es: 'Revisión Legal por un Abogado de Inmigración Certificado'
  },
  'pricing.upload': {
    en: 'Secure Document Upload & Tracking',
    es: 'Carga Segura de Documentos y Seguimiento'
  },
  'pricing.scheduling': {
    en: 'Appointment Scheduling Support',
    es: 'Soporte para Programación de Citas'
  },
  'pricing.updates': {
    en: 'Real-Time Status Updates',
    es: 'Actualizaciones de Estado en Tiempo Real'
  },
  'pricing.guarantee': {
    en: 'Money-Back Guarantee',
    es: 'Garantía de Devolución de Dinero'
  },
  'pricing.klarna': {
    en: 'Klarna Payment Option (Pay Later or in 3)',
    es: 'Opción de Pago con Klarna (Pague Después o en 3)'
  },
  
  // Trust guarantee
  'trust.title': {
    en: "We Don't Leave Your Immigration to Chance",
    es: 'No Dejamos su Inmigración al Azar'
  },
  'trust.description': {
    en: "If your application is rejected due to a mistake made by our platform or legal team, we'll refund the processing portion of your fee. Government fees and third-party services (like translations) not included—but your trust is.",
    es: 'Si su solicitud es rechazada debido a un error cometido por nuestra plataforma o equipo legal, le reembolsaremos la parte de procesamiento de su tarifa. Las tasas gubernamentales y servicios de terceros (como traducciones) no están incluidos—pero su confianza sí.'
  },
  'trust.lawyer': {
    en: 'Lawyer-backed',
    es: 'Respaldo de Abogados'
  },
  'trust.secure': {
    en: 'Fully secure',
    es: 'Totalmente seguro'
  },
  'trust.transparent': {
    en: 'Transparent & reliable',
    es: 'Transparente y fiable'
  }
};
