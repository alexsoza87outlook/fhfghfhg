
import { TranslationSection } from '../types';

export const residenceCertificateTranslations: TranslationSection = {
  'residence.certificate.title': {
    en: 'Resident Certificate',
    es: 'Certificado de Residente'
  },
  'residence.certificate.description': {
    en: 'Renewal of the certificate that proves legal residence in Spain.',
    es: 'Renovación del certificado que acredita la residencia legal en España.'
  },
  'residence.certificate.requirement1': {
    en: 'Valid residence permit',
    es: 'Permiso de residencia válido'
  },
  'residence.certificate.requirement2': {
    en: 'Valid passport',
    es: 'Pasaporte válido'
  },
  'residence.certificate.requirement3': {
    en: 'Proof of registration in the city census',
    es: 'Comprobante de empadronamiento'
  },
  'residence.certificate.moreInfo': {
    en: 'The resident certificate is an official document that confirms your legal residence status in Spain. It needs to be renewed periodically to maintain its validity and ensure your continued legal residence status.',
    es: 'El certificado de residente es un documento oficial que confirma su estado de residencia legal en España. Debe renovarse periódicamente para mantener su validez y asegurar la continuidad de su estatus de residencia legal.'
  },
};
