
import { TranslationSection } from '../types';

export const residenceCommonTranslations: TranslationSection = {
  'residence.title': {
    en: 'Residence Authorization Types',
    es: 'Tipos de Autorización de Residencia'
  },
  'residence.initial.applications': {
    en: 'Initial Residence Applications',
    es: 'Solicitudes Iniciales de Residencia'
  },
  'residence.renewal.title': {
    en: 'Residence Renewal',
    es: 'Renovación de Residencia'
  },
  'residence.mainRequirements': {
    en: 'Main Requirements',
    es: 'Requisitos Principales'
  },
  'residence.checkEligibility': {
    en: 'Check Eligibility',
    es: 'Verificar Elegibilidad'
  },
  'residence.moreInformation': {
    en: 'More Information',
    es: 'Más Información'
  }
};
