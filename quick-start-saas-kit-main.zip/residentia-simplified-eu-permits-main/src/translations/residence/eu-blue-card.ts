
import { TranslationSection } from '../types';

export const residenceEuBlueCardTranslations: TranslationSection = {
  'residence.euBlueCard.title': {
    en: 'EU Blue Card',
    es: 'Tarjeta Azul UE'
  },
  'residence.euBlueCard.description': {
    en: 'For highly qualified professionals from non-EU countries with a job offer in Spain.',
    es: 'Para profesionales altamente cualificados de países no comunitarios con una oferta de trabajo en España.'
  },
  'residence.euBlueCard.requirement1': {
    en: 'Higher university degree (minimum 3 years) or 5 years professional experience',
    es: 'Título universitario superior (mínimo 3 años) o 5 años de experiencia profesional'
  },
  'residence.euBlueCard.requirement2': {
    en: 'Work contract for at least 1 year',
    es: 'Contrato de trabajo de al menos 1 año'
  },
  'residence.euBlueCard.requirement3': {
    en: 'Minimum salary of €40,000 annually',
    es: 'Salario mínimo de €40,000 anuales'
  },
  'residence.euBlueCard.moreInfo': {
    en: 'Designed for foreign professionals with a job offer in Spain for the development of an employment or professional relationship in a managerial position or activity that requires higher education qualifications or, exceptionally, a minimum of three years of professional experience that can be considered equivalent to said qualification, related to the activity for which the authorization is granted.\n\nThe EU Blue Card allows highly qualified professionals to work in any country of the European Union (except Denmark, Ireland, and the United Kingdom, which do not participate in this program), facilitating labor mobility within the region.\n\nThe EU Blue Card holder can bring their family (spouse, minor children, among other family members) to live with them, without the need to meet additional requirements for family reunification, facilitating family reunification.\n\nDocumentation:\n1. Complete and valid passport, with minimum validity for the period for which the stay is requested.\n2. Recent color photograph, with white background, passport size.\n3. Offer or employment contract for a highly qualified position.\n4. Proof that the salary meets the minimum threshold.\n5. University degree or equivalent work experience.\n6. Valid health insurance in Spain.\n   1. Coverage: The health insurance must offer comprehensive coverage, including medical care.\n   2. Validity: The insurance must be valid throughout Spanish territory and, preferably, throughout the European Union.\n7. Criminal record certificate.\n8. Certificates of no debts with Social Security (if you have previously worked in Spain).',
    es: 'Destinado a profesionales extranjeros con una oferta de trabajo en España para el desarrollo de una relación laboral o profesional en un puesto directivo o actividad para la que se requiera contar con una cualificación de enseñanza superior o, excepcionalmente, se acredite un mínimo de tres años de experiencia profesional que pueda considerarse equiparable a dicha cualificación, relacionada con la actividad para cuyo desempeño se conceda a la autorización.\n\nLa Tarjeta Azul UE permite a los profesionales altamente cualificados trabajar en cualquier país de la Unión Europea (excepto Dinamarca, Irlanda y el Reino Unido, que no participan en este programa), facilitando la movilidad laboral dentro de la región.\n\nEl titular de la Tarjeta Azul puede traer a su familia (cónyuge, hijos menores, entre otros miembros de la familia) a vivir con él, sin necesidad de cumplir requisitos adicionales para su reagrupación familiar, facilitando la reunificación familiar.\n\nDocumentación:\n1. Pasaporte completo y en vigor, con vigencia mínima del periodo para el que se solicita la estancia.\n2. Fotografía reciente en color, en fondo blanco, tamaño carnet.\n3. Oferta o contrato de trabajo en un puesto altamente cualificado.\n4. Justificación de que el salario cumple con el umbral mínimo.\n5. Título universitario o experiencia laboral equivalente.\n6. Seguro médico válido en España.\n   1. Cobertura: El seguro médico debe ofrecer una cobertura completa, que incluya atención médica.\n   2. Validez: El seguro debe ser válido en todo el territorio español y, preferiblemente, en toda la Unión Europea.\n7. Certificado de antecedentes penales.\n8. Certificados de no tener deudas con la Seguridad Social (si has trabajado previamente en España).'
  },
  'residence.euBlueCard.contactUsText': {
    en: 'If you have any questions about the documents or requirements, contact us through the form below.',
    es: 'Si tienes dudas sobre los documentos o requisitos, contacta con nosotros a través del formulario.'
  },
  'residence.euBlueCard.contactUs': {
    en: 'Contact Us',
    es: 'Contáctanos'
  },
  'residence.euBlueCard.formName': {
    en: 'Full Name',
    es: 'Nombre Completo'
  },
  'residence.euBlueCard.formEmail': {
    en: 'Email',
    es: 'Correo Electrónico'
  },
  'residence.euBlueCard.formMessage': {
    en: 'Message',
    es: 'Mensaje'
  },
  'residence.euBlueCard.formSubmit': {
    en: 'Send',
    es: 'Enviar'
  },
  'residence.euBlueCard.formSuccess': {
    en: 'Your message has been sent successfully!',
    es: '¡Tu mensaje ha sido enviado con éxito!'
  },
  'residence.close': {
    en: 'Close',
    es: 'Cerrar'
  },
  'residence.chatbotTitle': {
    en: 'Eligibility Check',
    es: 'Comprobación de Elegibilidad'
  },
  'residence.chatbotDescription': {
    en: 'Answer a few questions to check if you are eligible for this authorization.',
    es: 'Responda algunas preguntas para verificar si es elegible para esta autorización.'
  },
  'residence.euBlueCard.question1': {
    en: 'Can you confirm if you have a job offer in Spain that meets the following requirements?\n- The employment is in a highly qualified position, requiring a university degree or equivalent experience.\n- The gross annual salary of the offer is at least 1.5 times the average salary in Spain (approximately €40,000 per year).',
    es: '¿Podrías confirmarme si tienes una oferta de trabajo en España que cumpla con los siguientes requisitos?\n- El empleo es en un puesto altamente cualificado, que requiere un título universitario o experiencia equivalente.\n- El salario anual bruto de la oferta es al menos 1.5 veces el salario promedio en España (aproximadamente €40,000 al año).'
  },
  'residence.euBlueCard.question2': {
    en: 'Does the work contract have a minimum duration of one year?',
    es: '¿El contrato de trabajo tiene una duración mínima de un año?'
  },
  'residence.euBlueCard.question3': {
    en: 'Is your passport valid and does not expire before the end of the period you are applying for? (Example: if you are applying for a 12-month stay, the passport should not expire in less than 12 months.)',
    es: '¿Tu pasaporte está vigente y no caduca antes de que termine el periodo que solicitas? (Ejemplo: si solicitas una estancia de 12 meses, el pasaporte no debe caducar en menos de 12 meses.)'
  },
  'residence.euBlueCard.question4': {
    en: 'Do you have educational certificates, such as your university degree or equivalent?',
    es: '¿Tienes certificados de estudios, como tu título universitario o equivalente?'
  },
  'residence.euBlueCard.question5': {
    en: 'Can you submit your curriculum vitae detailing your education and professional experience?',
    es: '¿Puedes presentar tu currículum vitae que detalle tu formación y experiencia profesional?'
  },
  'residence.euBlueCard.question6': {
    en: 'Do you have health insurance in the country where you want to work?',
    es: '¿Cuentas con un seguro médico en el país donde deseas trabajar?'
  },
  'residence.euBlueCard.question7': {
    en: 'Can you provide a criminal record certificate from your country of origin and any other country where you have previously resided?',
    es: '¿Puedes presentar un certificado de antecedentes penales de tu país de origen y de cualquier otro país en el que hayas residido previamente?'
  },
  'residence.euBlueCard.question8': {
    en: 'Can you demonstrate that you will not represent a burden on the country\'s social system, by meeting the salary requirements and the job offer?',
    es: '¿Puedes demostrar que no representarás una carga para el sistema social del país, cumpliendo con los requisitos salariales y la oferta de empleo?'
  },
  'residence.euBlueCard.verified': {
    en: 'AI Verified',
    es: 'Verificado por IA'
  },
  'residence.euBlueCard.signUp': {
    en: 'Sign Up',
    es: 'Registrarse'
  },
  'residence.euBlueCard.answerYes': {
    en: 'Yes',
    es: 'Sí'
  },
  'residence.euBlueCard.answerNo': {
    en: 'No',
    es: 'No'
  },
  'residence.euBlueCard.nextQuestion': {
    en: 'Next Question',
    es: 'Siguiente Pregunta'
  }
};
