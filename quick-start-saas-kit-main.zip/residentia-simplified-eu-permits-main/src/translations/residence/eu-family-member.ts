
import { TranslationSection } from '../types';

export const residenceEuFamilyMemberTranslations: TranslationSection = {
  'residence.euFamilyMember.title': {
    en: 'EU Citizen Family Member Permanent Residence',
    es: 'Residencia Permanente para Familiar de Ciudadano de la UE'
  },
  'residence.euFamilyMember.description': {
    en: 'For non-EU family members of EU citizens who have legally resided in Spain for 5 years.',
    es: 'Para familiares no comunitarios de ciudadanos de la UE que han residido legalmente en España durante 5 años.'
  },
  'residence.euFamilyMember.requirement1': {
    en: '5 years of legal and continuous residence in Spain as EU citizen family member',
    es: '5 años de residencia legal y continua en España como familiar de ciudadano de la UE'
  },
  'residence.euFamilyMember.requirement2': {
    en: 'Maintain family relationship with the EU citizen',
    es: 'Mantener la relación familiar con el ciudadano de la UE'
  },
  'residence.euFamilyMember.requirement3': {
    en: 'No absences exceeding 6 months per year',
    es: 'Sin ausencias que excedan los 6 meses por año'
  },
  'residence.euFamilyMember.moreInfo': {
    en: 'The EU citizen family member permanent residence card is for non-EU nationals who are family members of EU citizens and have legally resided in Spain for 5 continuous years. This permanent residence status provides long-term stability and nearly the same rights as Spanish citizens.',
    es: 'La tarjeta de residencia permanente para familiares de ciudadanos de la UE es para nacionales no comunitarios que son familiares de ciudadanos de la UE y han residido legalmente en España durante 5 años continuos. Este estatus de residencia permanente proporciona estabilidad a largo plazo y prácticamente los mismos derechos que los ciudadanos españoles.'
  },
};
