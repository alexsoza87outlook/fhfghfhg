
import { TranslationSection } from '../types';

export const residenceFamilyReunificationInitialTranslations: TranslationSection = {
  'residence.familyReunificationInitial.title': {
    en: 'Family Reunification',
    es: 'Reagrupación Familiar'
  },
  'residence.familyReunificationInitial.description': {
    en: 'For family members of legal foreign residents in Spain who wish to reunite with them.',
    es: 'Para familiares de residentes extranjeros legales en España que desean reunirse con ellos.'
  },
  'residence.familyReunificationInitial.requirement1': {
    en: 'The sponsor must have legal residence in Spain for at least 1 year',
    es: 'El reagrupante debe tener residencia legal en España durante al menos 1 año'
  },
  'residence.familyReunificationInitial.requirement2': {
    en: 'Renewed or long-term residence permit',
    es: 'Permiso de residencia renovado o de larga duración'
  },
  'residence.familyReunificationInitial.requirement3': {
    en: 'Sufficient financial means to support the family',
    es: 'Medios económicos suficientes para mantener a la familia'
  },
  'residence.familyReunificationInitial.moreInfo': {
    en: 'PLACEHOLDER\n\nDOCUMENTATION:\n\nPLACEHOLDER',
    es: 'PLACEHOLDER\n\nDOCUMENTACION:\n\nPLACEHOLDER'
  },
  'residence.familyReunificationInitial.contactUs': {
    en: 'Contact us',
    es: 'Contáctanos'
  },
  'residence.familyReunificationInitial.contactUsText': {
    en: 'If you have questions about the documents or requirements, contact us through the form below.',
    es: 'Si tienes dudas sobre los documentos o requisitos, contacta con nosotros a través del formulario.'
  },
  'residence.familyReunificationInitial.formName': {
    en: 'Full Name',
    es: 'Nombre Completo'
  },
  'residence.familyReunificationInitial.formEmail': {
    en: 'Email',
    es: 'Correo Electrónico'
  },
  'residence.familyReunificationInitial.formMessage': {
    en: 'Message',
    es: 'Mensaje'
  },
  'residence.familyReunificationInitial.formSubmit': {
    en: 'Send',
    es: 'Enviar'
  },
  'residence.familyReunificationInitial.formSuccess': {
    en: 'Message sent successfully',
    es: 'Mensaje enviado con éxito'
  }
};
