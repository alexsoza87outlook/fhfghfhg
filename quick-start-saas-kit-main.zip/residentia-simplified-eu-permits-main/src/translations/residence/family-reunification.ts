
import { TranslationSection } from '../types';

export const residenceFamilyReunificationTranslations: TranslationSection = {
  'residence.familyReunification.title': {
    en: 'Family Reunification',
    es: 'Reagrupación Familiar'
  },
  'residence.familyReunification.description': {
    en: 'Renewal of temporary residence authorization for family reunification.',
    es: 'Renovación de autorización de residencia temporal por reagrupación familiar.'
  },
  'residence.familyReunification.requirement1': {
    en: 'Maintenance of family relationship',
    es: 'Mantenimiento de la relación familiar'
  },
  'residence.familyReunification.requirement2': {
    en: 'The sponsor maintains the requirements for reunification',
    es: 'El reagrupante mantiene los requisitos para la reagrupación'
  },
  'residence.familyReunification.requirement3': {
    en: 'Health insurance',
    es: 'Seguro de salud'
  },
  'residence.familyReunification.moreInfo': {
    en: 'The family reunification authorization allows foreigners legally residing in Spain to bring their family members to live with them. The renewal requires maintaining both the family relationship and the initial requirements that allowed the reunification.',
    es: 'La autorización de reagrupación familiar permite a los extranjeros que residen legalmente en España traer a sus familiares para vivir con ellos. La renovación requiere mantener tanto la relación familiar como los requisitos iniciales que permitieron la reagrupación.'
  },
};
