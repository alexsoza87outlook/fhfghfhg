
import { TranslationSection } from '../types';

export const residenceHighlyQualifiedTranslations: TranslationSection = {
  'residence.highlyQualified.title': {
    en: 'Highly Qualified Professionals',
    es: 'Profesionales Altamente Cualificados'
  },
  'residence.highlyQualified.description': {
    en: 'Renewal of residence and work authorization for highly qualified professionals.',
    es: 'Renovación de autorización de residencia y trabajo para profesionales altamente cualificados.'
  },
  'residence.highlyQualified.requirement1': {
    en: 'Valid work contract',
    es: 'Contrato de trabajo válido'
  },
  'residence.highlyQualified.requirement2': {
    en: 'Professional qualification',
    es: 'Cualificación profesional'
  },
  'residence.highlyQualified.requirement3': {
    en: 'Compliance with tax and Social Security obligations',
    es: 'Cumplimiento de obligaciones fiscales y de Seguridad Social'
  },
  'residence.highlyQualified.moreInfo': {
    en: 'The highly qualified professional permit is designed for individuals with specialized skills, advanced degrees, or exceptional professional experience. The renewal process requires proof of continued employment and compliance with all legal and tax obligations in Spain.',
    es: 'El permiso para profesionales altamente cualificados está diseñado para personas con habilidades especializadas, títulos avanzados o experiencia profesional excepcional. El proceso de renovación requiere prueba de empleo continuo y cumplimiento de todas las obligaciones legales y fiscales en España.'
  },
};
