
import { TranslationSection } from '../types';
import { residenceCommonTranslations } from './common';
import { residenceNonLucrativeTranslations } from './non-lucrative';
import { residenceCertificateTranslations } from './certificate';
import { residenceNieTranslations } from './nie';
import { residenceHighlyQualifiedTranslations } from './highly-qualified';
import { residenceTemporaryWorkTranslations } from './temporary-work';
import { residenceFamilyReunificationTranslations } from './family-reunification';
import { residenceEuFamilyMemberTranslations } from './eu-family-member';
import { residenceLongTermTranslations } from './long-term';
import { residenceEuBlueCardTranslations } from './eu-blue-card';
import { residenceStudentStayTranslations } from './student-stay';
import { residenceTemporaryWorkInitialTranslations } from './temporary-work-initial';
import { residenceRemoteWorkTranslations } from './remote-work';
import { residenceFamilyReunificationInitialTranslations } from './family-reunification-initial';

// Merge all residence translation sections
export const residenceTranslations: TranslationSection = {
  ...residenceCommonTranslations,
  ...residenceNonLucrativeTranslations,
  ...residenceCertificateTranslations,
  ...residenceNieTranslations,
  ...residenceHighlyQualifiedTranslations,
  ...residenceTemporaryWorkTranslations,
  ...residenceFamilyReunificationTranslations,
  ...residenceEuFamilyMemberTranslations,
  ...residenceLongTermTranslations,
  ...residenceEuBlueCardTranslations,
  ...residenceStudentStayTranslations,
  ...residenceTemporaryWorkInitialTranslations,
  ...residenceRemoteWorkTranslations,
  ...residenceFamilyReunificationInitialTranslations
};
