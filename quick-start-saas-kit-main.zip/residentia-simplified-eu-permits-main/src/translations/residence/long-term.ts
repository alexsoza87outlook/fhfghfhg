
import { TranslationSection } from '../types';

export const residenceLongTermTranslations: TranslationSection = {
  'residence.longTerm.title': {
    en: 'Long-Term Residence',
    es: 'Residencia de Larga Duración'
  },
  'residence.longTerm.description': {
    en: 'For foreigners who have resided legally and continuously in Spain for five years.',
    es: 'Para extranjeros que han residido legal y continuadamente en España durante cinco años.'
  },
  'residence.longTerm.requirement1': {
    en: 'Continuous legal residence in Spain for 5 years',
    es: 'Residencia legal continuada en España durante 5 años'
  },
  'residence.longTerm.requirement2': {
    en: 'No crimes in the last 5 years',
    es: 'Sin delitos en los últimos 5 años'
  },
  'residence.longTerm.requirement3': {
    en: 'Adequate health insurance',
    es: 'Seguro médico adecuado'
  },
  'residence.longTerm.moreInfo': {
    en: 'Long-term residence authorization allows non-EU foreigners who have resided legally and continuously in Spain for five years to live and work in Spain indefinitely, with the same rights as Spanish citizens in many aspects. This permit needs to be renewed every 5 years.',
    es: 'La autorización de residencia de larga duración permite a los extranjeros no comunitarios que han residido legalmente y de forma continuada en España durante cinco años vivir y trabajar en España por tiempo indefinido, con los mismos derechos que los ciudadanos españoles en muchos aspectos. Este permiso necesita ser renovado cada 5 años.'
  },
  'residence.longTerm.permanentResidence.title': {
    en: 'Long-Term Permanent Residence',
    es: 'Residencia Permanente de Larga Duración'
  },
  'residence.longTerm.permanentResidence.description': {
    en: 'For foreigners who have completed 5 years of legal and continuous residence in Spain.',
    es: 'Para extranjeros que han completado 5 años de residencia legal y continuada en España.'
  },
};
