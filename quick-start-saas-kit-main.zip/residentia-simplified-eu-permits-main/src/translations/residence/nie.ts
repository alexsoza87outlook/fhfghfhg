
import { TranslationSection } from '../types';

export const residenceNieTranslations: TranslationSection = {
  'residence.nie.title': {
    en: 'Foreign Identity Number',
    es: 'Número de Identidad de Extranjero'
  },
  'residence.nie.description': {
    en: 'Renewal of the Foreign Identity Number (NIE).',
    es: 'Renovación del Número de Identidad de Extranjero (NIE).'
  },
  'residence.nie.requirement1': {
    en: 'Previous NIE',
    es: 'NIE anterior'
  },
  'residence.nie.requirement2': {
    en: 'Valid passport',
    es: 'Pasaporte válido'
  },
  'residence.nie.requirement3': {
    en: 'Justification for renewal need',
    es: 'Justificación de la necesidad de renovación'
  },
  'residence.nie.moreInfo': {
    en: 'The Foreign Identity Number (NIE) is the unique identification number assigned to foreigners in Spain. While the NIE itself never expires, the physical card or document that contains it may need to be renewed, especially if it\'s linked to a specific residence or work permit.',
    es: 'El Número de Identidad de Extranjero (NIE) es el número de identificación único asignado a los extranjeros en España. Aunque el NIE en sí nunca caduca, la tarjeta física o el documento que lo contiene puede necesitar renovación, especialmente si está vinculado a un permiso específico de residencia o trabajo.'
  },
};
