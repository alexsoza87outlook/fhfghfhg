
import { TranslationSection } from '../types';

export const residenceNonLucrativeTranslations: TranslationSection = {
  'residence.nonLucrative.title': {
    en: 'Non-Lucrative Residence',
    es: 'Residencia No Lucrativa'
  },
  'residence.nonLucrative.description': {
    en: 'Renewal of non-lucrative residence authorization.',
    es: 'Renovación de autorización de residencia no lucrativa.'
  },
  'residence.nonLucrative.requirement1': {
    en: 'Sufficient financial means',
    es: 'Medios económicos suficientes'
  },
  'residence.nonLucrative.requirement2': {
    en: 'Health insurance',
    es: 'Seguro de salud'
  },
  'residence.nonLucrative.requirement3': {
    en: 'Not having been outside Spain for more than 6 months',
    es: 'No haber estado fuera de España más de 6 meses'
  },
  'residence.nonLucrative.moreInfo': {
    en: 'The non-lucrative residence permit is for non-EU citizens who want to reside in Spain without working or carrying out economic activities in the country. This permit can be renewed if you maintain the same conditions as when it was initially granted.\n\nHowever, individuals can have income from abroad (such as rents, investments, dividends, etc.). This permit is ideal for retirees, people with passive income, or investors who can demonstrate economic solvency without the need for employment in Spain.',
    es: 'Es un permiso de residencia para ciudadanos extracomunitarios que desean vivir en España sin trabajar ni realizar actividades económicas en el país. Sin embargo, sí pueden tener ingresos del extranjero (rentas, inversiones, dividendos, etc.).\n\nEste permiso es ideal para jubilados, personas con ingresos pasivos o inversores que pueden demostrar solvencia económica sin necesidad de empleo en España.'
  },
  // New eligibility check translations
  'residence.nonLucrative.eligibilityCheck.instruction': {
    en: 'Please answer the following questions to check if you are eligible for a Non-Lucrative Residence permit.',
    es: 'Por favor, responda a las siguientes preguntas para verificar si es elegible para un permiso de Residencia No Lucrativa.'
  },
  'residence.nonLucrative.eligibilityCheck.yes': {
    en: 'Yes',
    es: 'Sí'
  },
  'residence.nonLucrative.eligibilityCheck.no': {
    en: 'No',
    es: 'No'
  },
  'residence.nonLucrative.eligibilityCheck.progress': {
    en: 'Question {current} of {total}',
    es: 'Pregunta {current} de {total}'
  },
  'residence.nonLucrative.eligibilityCheck.qualifiedTitle': {
    en: 'AI Verified',
    es: 'Verificado por IA'
  },
  'residence.nonLucrative.eligibilityCheck.qualifiedMessage': {
    en: 'Based on your answers, you appear to be eligible for a Non-Lucrative Residence permit. You can now proceed to create an account and start your application.',
    es: 'Según sus respuestas, parece ser elegible para un permiso de Residencia No Lucrativa. Ahora puede crear una cuenta e iniciar su solicitud.'
  },
  'residence.nonLucrative.eligibilityCheck.notQualifiedTitle': {
    en: 'Not Eligible',
    es: 'No Elegible'
  },
  'residence.nonLucrative.eligibilityCheck.notQualifiedMessage': {
    en: 'Based on your answers, you may not be eligible for a Non-Lucrative Residence permit. Please review the requirements or consult with one of our advisors.',
    es: 'Según sus respuestas, es posible que no sea elegible para un permiso de Residencia No Lucrativa. Por favor, revise los requisitos o consulte con uno de nuestros asesores.'
  },
  'residence.nonLucrative.eligibilityCheck.tryAgain': {
    en: 'Try Again',
    es: 'Intentar de Nuevo'
  },
  'residence.nonLucrative.eligibilityCheck.signUp': {
    en: 'Sign Up & Apply',
    es: 'Registrarse y Solicitar'
  },
  'residence.nonLucrative.eligibilityCheck.qualified': {
    en: 'Eligibility Verified',
    es: 'Elegibilidad Verificada'
  },
  'residence.nonLucrative.eligibilityCheck.redirectingToSignup': {
    en: 'Redirecting to registration...',
    es: 'Redirigiendo al registro...'
  },
  // All the questions for the questionnaire
  'residence.nonLucrative.eligibilityCheck.questions.nonEuCitizen': {
    en: 'Are you a citizen of a country outside the European Union, European Economic Area or Switzerland?',
    es: '¿Eres ciudadano de un país fuera de la Unión Europea, Espacio Económico Europeo o Suiza?'
  },
  'residence.nonLucrative.eligibilityCheck.questions.over18': {
    en: 'Are you over 18 years old?',
    es: '¿Tienes más de 18 años?'
  },
  'residence.nonLucrative.eligibilityCheck.questions.outsideSpain': {
    en: 'Are you currently outside of Spain when applying?',
    es: '¿Te encuentras fuera de España al momento de la solicitud?'
  },
  'residence.nonLucrative.eligibilityCheck.questions.cleanRecord': {
    en: 'Do you have a clean criminal record in the countries where you have resided in the last 5 years?',
    es: '¿Tienes antecedentes penales limpios en los países donde hayas residido en los últimos 5 años?'
  },
  'residence.nonLucrative.eligibilityCheck.questions.sufficientFunds': {
    en: 'Do you have at least €28,800 in savings (or demonstrable income of at least €2,400 per month) for the first applicant?',
    es: '¿Tienes al menos 28.800 € en ahorros (o ingresos demostrables de al menos 2.400 € al mes) para el primer solicitante?'
  },
  'residence.nonLucrative.eligibilityCheck.questions.additionalFunds': {
    en: 'If traveling with family members, do you have an additional €7,200 for each extra person (or sufficient income to cover them)?',
    es: 'Si viajas con familiares, ¿tienes 7.200 € adicionales por cada persona extra (o ingresos suficientes para cubrirlos)?'
  },
  'residence.nonLucrative.eligibilityCheck.questions.proveIncome': {
    en: 'Can you demonstrate these funds through bank statements, investments, income or pensions?',
    es: '¿Puedes demostrar estos ingresos mediante extractos bancarios, inversiones, rentas o pensiones?'
  },
  'residence.nonLucrative.eligibilityCheck.questions.healthInsurance': {
    en: 'Do you have or can you obtain private health insurance in Spain with no co-payments and full coverage?',
    es: '¿Tienes o puedes contratar un seguro médico privado en España sin copagos y con cobertura completa?'
  },
  'residence.nonLucrative.eligibilityCheck.questions.validPassport': {
    en: 'Do you have a valid passport with at least 1 year of validity?',
    es: '¿Tienes un pasaporte válido con al menos 1 año de vigencia?'
  },
  'residence.nonLucrative.eligibilityCheck.questions.medicalCertificate': {
    en: 'Can you provide a medical certificate confirming you do not suffer from diseases that may affect public health?',
    es: '¿Puedes presentar un certificado médico que confirme que no padeces enfermedades que puedan afectar la salud pública?'
  },
  'residence.nonLucrative.eligibilityCheck.questions.spanishAddress': {
    en: 'Can you demonstrate that you have an address in Spain (rental contract, property, invitation letter, etc.)?',
    es: '¿Puedes demostrar que tienes un domicilio en España (contrato de alquiler, propiedad, carta de invitación, etc.)?'
  },
  'residence.nonLucrative.eligibilityCheck.questions.noWork': {
    en: 'Do you commit to not performing work or professional activities in Spain?',
    es: '¿Te comprometes a no realizar actividades laborales ni profesionales en España?'
  },
  'residence.nonLucrative.eligibilityCheck.questions.understandRules': {
    en: 'Do you understand that non-lucrative residence does not allow working, but does allow investments or teleworking for foreign companies?',
    es: '¿Entiendes que la residencia no lucrativa no permite trabajar, pero sí realizar inversiones o teletrabajo para empresas extranjeras?'
  },
  'residence.nonLucrative.eligibilityCheck.questions.stayInSpain': {
    en: 'Are you willing to stay in Spain for at least 183 days per year to maintain your fiscal residence?',
    es: '¿Estás dispuesto a permanecer en España al menos 183 días al año para mantener tu residencia fiscal?'
  }
};
