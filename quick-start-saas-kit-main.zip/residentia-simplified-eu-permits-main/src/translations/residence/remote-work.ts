
import { TranslationSection } from '../types';

export const residenceRemoteWorkTranslations: TranslationSection = {
  'residence.remoteWork.title': {
    en: 'Remote Work Residence Visa',
    es: 'Visado de Residencia para Teletrabajo'
  },
  'residence.remoteWork.description': {
    en: 'For professionals working remotely for non-Spanish companies or earning income from online activities.',
    es: 'Para profesionales que trabajan remotamente para empresas no españolas o que obtienen ingresos de actividades en línea.'
  },
  'residence.remoteWork.requirement1': {
    en: 'Work contract or professional relationship with non-Spanish companies',
    es: 'Contrato de trabajo o relación profesional con empresas no españolas'
  },
  'residence.remoteWork.requirement2': {
    en: 'Minimum monthly income of €2,000 and €500 additional per family member',
    es: 'Ingresos mensuales mínimos de €2,000 y €500 adicionales por miembro familiar'
  },
  'residence.remoteWork.requirement3': {
    en: 'At least 3 months of employment history',
    es: 'Al menos 3 meses de historial laboral'
  },
  'residence.remoteWork.moreInfo': {
    en: 'Visa for foreigners who want to carry out a work or professional activity remotely for companies located outside of Spain through the exclusive use of computer, telematic or telecommunication means.\n\nForeigners who carry out an activity as an employee can only work for companies located outside of Spain.\n\nForeigners who carry out an activity as self-employed (as a freelancer) can also work for companies located in Spain, provided that the percentage of said work is not higher than 20% of their total activity.\n\nTo obtain this visa, it is necessary to have a graduate or postgraduate degree issued by prestigious universities, vocational training centers or business schools, or prove a minimum of three years of professional experience.\n\nThe following family members of the remote worker can also obtain the visa:\nThe spouse or domestic partner.\nMinor children and those of legal age who are financially dependent on the remote worker and who have not formed a family unit on their own.\nAscendants who are dependent on the remote worker.\n\nIt is necessary to request a NIE (Foreign Identification Number) at the same time as the visa.\n\nDOCUMENTATION:\n\nFREELANCE MODE:\n1. Contracts with international clients, certificates or collaboration letters.\n2. Recently issued invoices.\n3. Bank statements.\n\nEMPLOYEE MODE:\n1. Work contract.\n2. Proof of employment relationship.\n3. Proof of income.\n\nIN BOTH CASES:\n1. Complete and valid passport, with minimum validity for the period for which the stay is requested.\n2. Photograph.\n3. Entry stamp in Spain.\n4. Responsible declaration.\n5. University or vocational training degree or, alternatively, proof of work experience.\n6. Justification of monthly income.\n7. Private medical insurance policy.\n8. Criminal record certificate.',
    es: 'Visado para extranjeros que quieran ejercer una actividad laboral o profesional a distancia para empresas situadas fuera de España mediante el uso exclusivo de medios informáticos, telemáticos o de telecomunicación.\n\nEl extranjero que realice una actividad por cuenta ajena sólo podrá trabajar para empresas situadas fuera de España.\n\nEl extranjero que realice una actividad por cuenta propia (como autónomo) podrá trabajar también para empresas situadas en España, siempre que el porcentaje de dicho trabajo no sea superior al 20% del total de su actividad.\n\nPara obtener este visado es necesario tener un título de graduado o postgraduado expedido por universidades de reconocido prestigio, centros de formación profesional o escuelas de negocios de reconocido prestigio, o bien probar una experiencia profesional mínima de tres años.\n\nTambién pueden obtener el visado los siguientes familiares del teletrabajador:\nEl cónyuge o pareja de hecho.\nLos hijos menores de edad y los mayores de esa edad que dependan económicamente del teletrabajador y que no hayan constituido por sí mismos una unidad familiar.\nLos ascendientes que estén a cargo del teletrabajador.\n\nEs necesario solicitar al mismo tiempo que el visado un NIE (Número de Identificación de Extranjero).\n\nDOCUMENTACION:\n\nMODALIDAD FREELANCE:\n1. Contratos con clientes internacionales, certificados o cartas de colaboración.\n2. Facturas recientes emitidas.\n3. Extractos bancarios.\n\nMODALIDAD ASALARIADO:\n1. Contrato de trabajo.\n2. Justificante de relación laboral.\n3. Prueba de ingresos.\n\nEN AMBOS CASOS:\n1. Pasaporte completo y en vigor, con vigencia mínima del periodo para el que se solicita la estancia.\n2. Fotografía.\n3. Sello de entrada en España.\n4. Declaración responsable.\n5. Título universitario o de formación profesional o alternativamente, justificante experiencia laboral.\n6. Justificación de ingresos mensuales.\n7. Póliza de seguro médico privado.\n8. Certificado de antecedentes penales.'
  },
  'residence.remoteWork.contactUs': {
    en: 'Contact us',
    es: 'Contáctanos'
  },
  'residence.remoteWork.contactUsText': {
    en: 'If you have questions about the documents or requirements, contact us through the form below.',
    es: 'Si tienes dudas sobre los documentos o requisitos, contacta con nosotros a través del formulario.'
  },
  'residence.remoteWork.formName': {
    en: 'Full Name',
    es: 'Nombre Completo'
  },
  'residence.remoteWork.formEmail': {
    en: 'Email',
    es: 'Correo Electrónico'
  },
  'residence.remoteWork.formMessage': {
    en: 'Message',
    es: 'Mensaje'
  },
  'residence.remoteWork.formSubmit': {
    en: 'Send',
    es: 'Enviar'
  },
  'residence.remoteWork.formSuccess': {
    en: 'Message sent successfully',
    es: 'Mensaje enviado con éxito'
  }
};
