
import { TranslationSection } from '../types';

export const residenceStudentStayTranslations: TranslationSection = {
  'residence.studentStay.title': {
    en: 'Student Stay Authorization',
    es: 'Autorización de Estancia por Estudios'
  },
  'residence.studentStay.description': {
    en: 'For international students who wish to study, research or train in Spain.',
    es: 'Para estudiantes internacionales que desean estudiar, investigar o formarse en España.'
  },
  'residence.studentStay.requirement1': {
    en: 'Valid passport for the entire requested stay',
    es: 'Pasaporte válido para toda la estancia solicitada'
  },
  'residence.studentStay.requirement2': {
    en: 'Acceptance letter from an official Spanish educational institution',
    es: 'Carta de aceptación de una institución educativa española oficial'
  },
  'residence.studentStay.requirement3': {
    en: 'Full health insurance without copayments or waiting periods',
    es: 'Seguro médico completo sin copagos ni periodos de carencia'
  },
  'residence.studentStay.moreInfo': {
    en: 'An authorization that allows you to stay in Spain for a period exceeding ninety days for the purpose of studying or extending studies in an authorized educational center in Spain, in a full-time program, leading to a degree or certificate of studies.',
    es: 'Es una autorización que habilita a permanecer en España por un período superior a noventa días para la realización o ampliación de estudios en un centro de enseñanza autorizado en España, en un programa a tiempo completo, que conduzca a la obtención de un título o certificado de estudios.'
  },
  'residence.studentStay.documentation': {
    en: '1. Complete and valid passport, with minimum validity for the period for which the stay is requested.\n2. Documentation proving sufficient financial means for the requested period and for return to the country of origin.\n3. Documentation proving medical insurance coverage.\n4. Documentation proving admission to an educational center.\n5. If of legal age, criminal record certificate issued by the authorities of the country of origin or the country in which they have resided during the last five years.',
    es: '1. Pasaporte completo y en vigor, con vigencia mínima del periodo para el que se solicita la estancia.\n2. Documentación acreditativa de disponer de medios económicos necesarios para el período que se solicita y para el retorno al país de procedencia.\n3. Documentación acreditativa de disponer de seguro médico.\n4. Documentación acreditativa de estar admitido en un centro de enseñanza.\n5. Si es mayor de edad, certificado de antecedentes penales expedido por las autoridades del país de origen o del país en que haya residido durante los últimos cinco años.'
  },
  'residence.studentStay.contactUs': {
    en: 'Contact us',
    es: 'Contáctanos'
  },
  'residence.studentStay.contactUsText': {
    en: 'If you have questions about the documents or requirements, contact us through the form below.',
    es: 'Si tienes dudas sobre los documentos o requisitos, contacta con nosotros a través del formulario.'
  },
  'residence.studentStay.formName': {
    en: 'Full Name',
    es: 'Nombre Completo'
  },
  'residence.studentStay.formEmail': {
    en: 'Email',
    es: 'Correo Electrónico'
  },
  'residence.studentStay.formMessage': {
    en: 'Message',
    es: 'Mensaje'
  },
  'residence.studentStay.formSubmit': {
    en: 'Send',
    es: 'Enviar'
  },
  'residence.studentStay.formSuccess': {
    en: 'Message sent successfully',
    es: 'Mensaje enviado con éxito'
  }
};
