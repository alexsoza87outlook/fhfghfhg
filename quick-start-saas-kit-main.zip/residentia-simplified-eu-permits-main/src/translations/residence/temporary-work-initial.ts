
import { TranslationSection } from '../types';

export const residenceTemporaryWorkInitialTranslations: TranslationSection = {
  'residence.temporaryWorkInitial.title': {
    en: 'Initial Temporary Residence and Work Permit',
    es: 'Autorización Inicial de Residencia y Trabajo Temporal'
  },
  'residence.temporaryWorkInitial.description': {
    en: 'For foreign workers who have received a job offer in Spain.',
    es: 'Para trabajadores extranjeros que han recibido una oferta de trabajo en España.'
  },
  'residence.temporaryWorkInitial.requirement1': {
    en: 'Signed work contract guaranteeing continuous activity',
    es: 'Contrato de trabajo firmado que garantice actividad continua'
  },
  'residence.temporaryWorkInitial.requirement2': {
    en: 'Company must be registered with Social Security',
    es: 'La empresa debe estar registrada en la Seguridad Social'
  },
  'residence.temporaryWorkInitial.requirement3': {
    en: 'Company must be up to date with tax obligations',
    es: 'La empresa debe estar al día con sus obligaciones fiscales'
  },
  'residence.temporaryWorkInitial.moreInfo': {
    en: 'Intended for foreign workers who are not residents in Spain and are not irregularly in Spanish territory at the time when the employer who wants to hire makes the authorization request.\n\nDOCUMENTATION:\n\nWORKER DOCUMENTATION:\n1. Complete and valid passport, with minimum validity for the period for which the stay is requested.\n2. If required for the job position, title, training or experience.\n3. Criminal record certificate issued by the authorities of the country of origin or the country in which they have resided.\n\nEMPLOYER DOCUMENTATION:\n1. If it is a company:\n2. If it is a self-employed person:\n3. Proof of financial solvency of the employer.\n4. Work contract documents\n5. Justification of the need to hire a foreigner.\n\nExceptions:\n- If the occupation is in the Catalog of Difficult Coverage.\n- If the worker has Spanish family members or is a spouse/child of a legal resident, in which case they must provide documentation proving the family relationship.',
    es: 'Destinado a los trabajadores extranjeros que no sean residentes en España y no se encuentren irregularmente en territorio español en el momento en que el empleador que quiere contratar realice la solicitud de autorización.\n\nDOCUMENTACION:\n\nDOCUMENTACIÓN DEL TRABAJADOR:\n1. Pasaporte completo y en vigor, con vigencia mínima del periodo para el que se solicita la estancia.\n2. Si lo requiere el puesto de trabajo, título, formación o experiencia.\n3. Certificado de antecedentes penales expedido por las autoridades del país de origen o del país en\n\nDOCUMENTACIÓN DEL EMPLEADOR:\n1. Si es una empresa:\n2. Si es un autónomo:\n3. Prueba de solvencia económica del empleador.\n4. Documentos del contrato de trabajo\n5. Justificación de la necesidad de contratar a un extranjero.\n\nExcepciones:\n- Si la ocupación está en el Catálogo de Difícil Cobertura.\n- Si el trabajador tiene familiares españoles o es cónyuge/hijo de residente legal, en cuyo caso debe aportar la documentación que acredite el vínculo familiar.'
  },
  'residence.temporaryWorkInitial.contactUs': {
    en: 'Contact us',
    es: 'Contáctanos'
  },
  'residence.temporaryWorkInitial.contactUsText': {
    en: 'If you have questions about the documents or requirements, contact us through the form below.',
    es: 'Si tienes dudas sobre los documentos o requisitos, contacta con nosotros a través del formulario.'
  },
  'residence.temporaryWorkInitial.formName': {
    en: 'Full Name',
    es: 'Nombre Completo'
  },
  'residence.temporaryWorkInitial.formEmail': {
    en: 'Email',
    es: 'Correo Electrónico'
  },
  'residence.temporaryWorkInitial.formMessage': {
    en: 'Message',
    es: 'Mensaje'
  },
  'residence.temporaryWorkInitial.formSubmit': {
    en: 'Send',
    es: 'Enviar'
  },
  'residence.temporaryWorkInitial.formSuccess': {
    en: 'Message sent successfully',
    es: 'Mensaje enviado con éxito'
  }
};
