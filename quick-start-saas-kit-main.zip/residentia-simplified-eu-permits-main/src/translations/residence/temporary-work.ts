
import { TranslationSection } from '../types';

export const residenceTemporaryWorkTranslations: TranslationSection = {
  'residence.temporaryWork.title': {
    en: 'Temporary Work Authorization',
    es: 'Autorización de Trabajo Temporal'
  },
  'residence.temporaryWork.description': {
    en: 'Renewal of temporary residence and employment work authorization.',
    es: 'Renovación de autorización de residencia temporal y trabajo por cuenta ajena.'
  },
  'residence.temporaryWork.requirement1': {
    en: 'Valid work contract',
    es: 'Contrato de trabajo válido'
  },
  'residence.temporaryWork.requirement2': {
    en: 'Social Security contributions',
    es: 'Cotizaciones a la Seguridad Social'
  },
  'residence.temporaryWork.requirement3': {
    en: 'Tax compliance',
    es: 'Cumplimiento fiscal'
  },
  'residence.temporaryWork.moreInfo': {
    en: 'The temporary work authorization allows non-EU foreign nationals to live and work legally in Spain for a specific period. Renewal requires proof of continued employment and compliance with legal obligations.',
    es: 'La autorización de trabajo temporal permite a ciudadanos extranjeros no comunitarios vivir y trabajar legalmente en España por un período específico. La renovación requiere prueba de empleo continuo y cumplimiento de obligaciones legales.'
  },
};
