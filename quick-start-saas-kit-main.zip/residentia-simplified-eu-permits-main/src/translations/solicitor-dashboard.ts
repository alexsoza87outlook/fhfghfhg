import { Language } from '../types/language';
import { TranslationSection } from './types';

export const solicitorDashboardTranslations: TranslationSection = {
  // Solicitor Dashboard Translations
  'solicitor.dashboard.title': {
    'en': 'Applications Management',
    'es': 'Gestión de Solicitudes'
  },
  'solicitor.dashboard.applicant': {
    'en': 'Applicant',
    'es': 'Solicitante'
  },
  'solicitor.dashboard.status': {
    'en': 'Status',
    'es': 'Estado'
  },
  'solicitor.dashboard.date': {
    'en': 'Submission Date',
    'es': 'Fecha de Envío'
  },
  'solicitor.dashboard.action': {
    'en': 'Actions',
    'es': 'Acciones'
  },
  'solicitor.dashboard.viewDetails': {
    'en': 'View Details',
    'es': 'Ver Detalles'
  },
  'solicitor.dashboard.updateStatus': {
    'en': 'Update Status',
    'es': 'Actualizar Estado'
  },
  'solicitor.dashboard.refresh': {
    'en': 'Refresh',
    'es': 'Actualizar'
  },
  'solicitor.dashboard.messages': {
    'en': 'Messages',
    'es': 'Mensajes'
  },
  'solicitor.dashboard.noApplications': {
    'en': 'No applications found',
    'es': 'No se encontraron solicitudes'
  },
  'solicitor.dashboard.loading': {
    'en': 'Loading applications...',
    'es': 'Cargando solicitudes...'
  },
  'solicitor.dashboard.failedToLoad': {
    'en': 'Failed to load applications data',
    'es': 'Error al cargar los datos de las solicitudes'
  },
  'solicitor.status.underReview': {
    'en': 'Under Review',
    'es': 'En Revisión'
  },
  'solicitor.status.additionalDocsRequired': {
    'en': 'Additional Documents Required',
    'es': 'Documentos Adicionales Requeridos'
  },
  'solicitor.status.approved': {
    'en': 'Approved',
    'es': 'Aprobada'
  },
  'solicitor.status.rejected': {
    'en': 'Rejected',
    'es': 'Rechazada'
  },
  'solicitor.status.completed': {
    'en': 'Completed',
    'es': 'Completada'
  },
  'solicitor.applicationDetails.title': {
    'en': 'Application Details',
    'es': 'Detalles de la Solicitud'
  },
  'solicitor.applicationDetails.details': {
    'en': 'Details',
    'es': 'Detalles'
  },
  'solicitor.applicationDetails.history': {
    'en': 'History',
    'es': 'Historial'
  },
  'solicitor.applicationDetails.messaging': {
    'en': 'Messaging',
    'es': 'Mensajes'
  },
  'solicitor.applicationDetails.personalDetails': {
    'en': 'Personal Details',
    'es': 'Detalles Personales'
  },
  'solicitor.applicationDetails.applicantInformation': {
    'en': 'Applicant information and contact details',
    'es': 'Información del solicitante y detalles de contacto'
  },
  'solicitor.applicationDetails.noPersonalDetails': {
    'en': 'No personal details have been submitted yet.',
    'es': 'Aún no se han enviado detalles personales.'
  },
  'solicitor.applicationDetails.applicationInfo': {
    'en': 'Application Information',
    'es': 'Información de la Solicitud'
  },
  'solicitor.applicationDetails.status': {
    'en': 'Current application status and details',
    'es': 'Estado actual de la solicitud y detalles'
  },
  'solicitor.applicationDetails.dates': {
    'en': 'Important Dates',
    'es': 'Fechas Importantes'
  },
  'solicitor.applicationDetails.created': {
    'en': 'Created',
    'es': 'Creada'
  },
  'solicitor.applicationDetails.submitted': {
    'en': 'Submitted',
    'es': 'Enviada'
  },
  'solicitor.applicationDetails.updated': {
    'en': 'Last Updated',
    'es': 'Última Actualización'
  },
  'solicitor.applicationDetails.currentStatus': {
    'en': 'Current Status',
    'es': 'Estado Actual'
  },
  'solicitor.applicationDetails.step': {
    'en': 'Current Step',
    'es': 'Paso Actual'
  },
  'solicitor.applicationDetails.payment': {
    'en': 'Payment Status',
    'es': 'Estado de Pago'
  },
  'solicitor.applicationDetails.documents': {
    'en': 'Documents',
    'es': 'Documentos'
  },
  'solicitor.applicationDetails.noDocuments': {
    'en': 'No documents have been uploaded yet.',
    'es': 'Aún no se han subido documentos.'
  },
  'solicitor.applicationDetails.statusHistory': {
    'en': 'Status History',
    'es': 'Historial de Estados'
  },
  'solicitor.applicationDetails.historyDescription': {
    'en': 'Timeline of application status changes',
    'es': 'Cronología de los cambios de estado de la solicitud'
  },
  'solicitor.applicationDetails.noStatusUpdates': {
    'en': 'No status updates available.',
    'es': 'No hay actualizaciones de estado disponibles.'
  },
  'solicitor.messages.title': {
    'en': 'Messages',
    'es': 'Mensajes'
  },
  'solicitor.messages.noMessages': {
    'en': 'No messages yet',
    'es': 'Aún no hay mensajes'
  },
  'solicitor.messages.startConversation': {
    'en': 'Start a conversation with the applicant below',
    'es': 'Inicia una conversación con el solicitante abajo'
  },
  'solicitor.messages.typePlaceholder': {
    'en': 'Type a message...',
    'es': 'Escribe un mensaje...'
  },
  'solicitor.messages.send': {
    'en': 'Send',
    'es': 'Enviar'
  }
};
