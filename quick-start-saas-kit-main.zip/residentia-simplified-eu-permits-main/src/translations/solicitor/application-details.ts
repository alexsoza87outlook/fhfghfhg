
import { TranslationSection } from '../types';

export const solicitorApplicationDetailsTranslations: TranslationSection = {
  'solicitor.applicationDetails.title': {
    'en': 'Application Details',
    'es': 'Detalles de la Solicitud'
  },
  'solicitor.applicationDetails.details': {
    'en': 'Details',
    'es': 'Detalles'
  },
  'solicitor.applicationDetails.history': {
    'en': 'History',
    'es': 'Historial'
  },
  'solicitor.applicationDetails.messaging': {
    'en': 'Messaging',
    'es': 'Mensajes'
  },
  'solicitor.applicationDetails.personalDetails': {
    'en': 'Personal Details',
    'es': 'Detalles Personales'
  },
  'solicitor.applicationDetails.applicantInformation': {
    'en': 'Applicant information and contact details',
    'es': 'Información del solicitante y detalles de contacto'
  },
  'solicitor.applicationDetails.noPersonalDetails': {
    'en': 'No personal details have been submitted yet.',
    'es': 'Aún no se han enviado detalles personales.'
  },
  'solicitor.applicationDetails.applicationInfo': {
    'en': 'Application Information',
    'es': 'Información de la Solicitud'
  },
  'solicitor.applicationDetails.status': {
    'en': 'Current application status and details',
    'es': 'Estado actual de la solicitud y detalles'
  },
  'solicitor.applicationDetails.dates': {
    'en': 'Important Dates',
    'es': 'Fechas Importantes'
  },
  'solicitor.applicationDetails.created': {
    'en': 'Created',
    'es': 'Creada'
  },
  'solicitor.applicationDetails.submitted': {
    'en': 'Submitted',
    'es': 'Enviada'
  },
  'solicitor.applicationDetails.updated': {
    'en': 'Last Updated',
    'es': 'Última Actualización'
  },
  'solicitor.applicationDetails.currentStatus': {
    'en': 'Current Status',
    'es': 'Estado Actual'
  },
  'solicitor.applicationDetails.step': {
    'en': 'Current Step',
    'es': 'Paso Actual'
  },
  'solicitor.applicationDetails.payment': {
    'en': 'Payment Status',
    'es': 'Estado de Pago'
  },
  'solicitor.applicationDetails.documents': {
    'en': 'Documents',
    'es': 'Documentos'
  },
  'solicitor.applicationDetails.noDocuments': {
    'en': 'No documents have been uploaded yet.',
    'es': 'Aún no se han subido documentos.'
  },
  'solicitor.applicationDetails.statusHistory': {
    'en': 'Status History',
    'es': 'Historial de Estados'
  },
  'solicitor.applicationDetails.historyDescription': {
    'en': 'Timeline of application status changes',
    'es': 'Cronología de los cambios de estado de la solicitud'
  },
  'solicitor.applicationDetails.noStatusUpdates': {
    'en': 'No status updates available.',
    'es': 'No hay actualizaciones de estado disponibles.'
  }
};
