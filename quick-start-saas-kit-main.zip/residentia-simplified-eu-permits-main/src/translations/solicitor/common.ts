
import { TranslationSection } from '../types';

export const solicitorDashboardCommonTranslations: TranslationSection = {
  'solicitor.dashboard.title': {
    'en': 'Applications Management',
    'es': 'Gestión de Solicitudes'
  },
  'solicitor.dashboard.applicant': {
    'en': 'Applicant',
    'es': 'Solicitante'
  },
  'solicitor.dashboard.status': {
    'en': 'Status',
    'es': 'Estado'
  },
  'solicitor.dashboard.date': {
    'en': 'Submission Date',
    'es': 'Fecha de Envío'
  },
  'solicitor.dashboard.action': {
    'en': 'Actions',
    'es': 'Acciones'
  },
  'solicitor.dashboard.viewDetails': {
    'en': 'View Details',
    'es': 'Ver Detalles'
  },
  'solicitor.dashboard.updateStatus': {
    'en': 'Update Status',
    'es': 'Actualizar Estado'
  },
  'solicitor.dashboard.refresh': {
    'en': 'Refresh',
    'es': 'Actualizar'
  },
  'solicitor.dashboard.messages': {
    'en': 'Messages',
    'es': 'Mensajes'
  },
  'solicitor.dashboard.noApplications': {
    'en': 'No applications found',
    'es': 'No se encontraron solicitudes'
  },
  'solicitor.dashboard.loading': {
    'en': 'Loading applications...',
    'es': 'Cargando solicitudes...'
  },
  'solicitor.dashboard.failedToLoad': {
    'en': 'Failed to load applications data',
    'es': 'Error al cargar los datos de las solicitudes'
  }
};
