
import { TranslationSection } from '../types';
import { solicitorDashboardCommonTranslations } from './common';
import { solicitorStatusTranslations } from './status';
import { solicitorApplicationDetailsTranslations } from './application-details';

// Merge all solicitor translation sections
export const solicitorDashboardTranslations: TranslationSection = {
  ...solicitorDashboardCommonTranslations,
  ...solicitorStatusTranslations,
  ...solicitorApplicationDetailsTranslations
};
