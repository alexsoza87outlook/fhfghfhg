
import { TranslationSection } from '../types';

export const solicitorStatusTranslations: TranslationSection = {
  'solicitor.status.underReview': {
    'en': 'Under Review',
    'es': 'En Revisión'
  },
  'solicitor.status.additionalDocsRequired': {
    'en': 'Additional Documents Required',
    'es': 'Documentos Adicionales Requeridos'
  },
  'solicitor.status.approved': {
    'en': 'Approved',
    'es': 'Aprobada'
  },
  'solicitor.status.rejected': {
    'en': 'Rejected',
    'es': 'Rechazada'
  },
  'solicitor.status.completed': {
    'en': 'Completed',
    'es': 'Completada'
  }
};
