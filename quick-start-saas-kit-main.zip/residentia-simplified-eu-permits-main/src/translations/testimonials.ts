
import { TranslationSection } from './types';

export const testimonialsTranslations: TranslationSection = {
  // Testimonials
  'testimonials.title': {
    en: 'Thousands Have Simplified Their Immigration with ResidentIA',
    es: 'Miles Han Simplificado su Inmigración con ResidentIA'
  },
  'testimonials.1.quote': {
    en: 'The government site didn\'t even list my permit option. ResidentIA found it in 2 minutes and handled everything.',
    es: 'El sitio del gobierno ni siquiera listaba mi opción de permiso. ResidentIA lo encontró en 2 minutos y se encargó de todo.'
  },
  'testimonials.1.person': {
    en: 'Marcus R., Remote Worker in Malaga',
    es: 'Marcus R., Trabajador Remoto en Málaga'
  },
  'testimonials.2.quote': {
    en: 'Klarna helped me afford this as a student. And it worked perfectly. Zero hassle.',
    es: 'Klarna me ayudó a poder pagarlo como estudiante. Y funcionó perfectamente. Cero complicaciones.'
  },
  'testimonials.2.person': {
    en: 'Rana S., Student in Barcelona',
    es: 'Rana S., Estudiante en Barcelona'
  },
  'testimonials.3.quote': {
    en: 'No need to print anything. No immigration calls. Just smooth, legal, fast service.',
    es: 'Sin necesidad de imprimir nada. Sin llamadas de inmigración. Solo un servicio suave, legal y rápido.'
  },
  'testimonials.3.person': {
    en: 'David L., US Citizen in Spain',
    es: 'David L., Ciudadano de EE.UU. en España'
  },
  'testimonials.4.quote': {
    en: 'I tried for 6 weeks to get a cita previa in Madrid. ResidentIA found an appointment, prepared everything, and my application was accepted on the first try.',
    es: 'Intenté durante 6 semanas conseguir una cita previa en Madrid. ResidentIA encontró una cita, preparó todo, y mi solicitud fue aceptada al primer intento.'
  },
  'testimonials.4.person': {
    en: 'Mohammed A., UK citizen applying for a non-lucrative residence permit in Madrid',
    es: 'Mohammed A., ciudadano del Reino Unido solicitando un permiso de residencia no lucrativa en Madrid'
  },
  'testimonials.5.quote': {
    en: 'The process for the digital nomad visa in Spain was overwhelming. ResidentIA broke it into simple steps, told me exactly what documents I needed, and even helped with the translation requirements. Approved in under 30 days!',
    es: 'El proceso para la visa de nómada digital en España era abrumador. ResidentIA lo dividió en pasos simples, me dijo exactamente qué documentos necesitaba, e incluso me ayudó con los requisitos de traducción. ¡Aprobado en menos de 30 días!'
  },
  'testimonials.5.person': {
    en: 'Chloe R., US remote worker in Barcelona',
    es: 'Chloe R., trabajadora remota de EE.UU. en Barcelona'
  },
  'testimonials.6.quote': {
    en: 'As a student from Argentina, I was completely lost. Every site gave different instructions. ResidentIA told me what to do, how many copies I needed, and helped me prepare the police clearance. I didn\'t even need a lawyer meeting.',
    es: 'Como estudiante de Argentina, estaba completamente perdido. Cada sitio daba instrucciones diferentes. ResidentIA me dijo qué hacer, cuántas copias necesitaba, y me ayudó a preparar el certificado de antecedentes penales. Ni siquiera necesité una reunión con un abogado.'
  },
  'testimonials.6.person': {
    en: 'Valentina G., Student visa applicant in Valencia',
    es: 'Valentina G., Solicitante de visa de estudiante en Valencia'
  }
};
