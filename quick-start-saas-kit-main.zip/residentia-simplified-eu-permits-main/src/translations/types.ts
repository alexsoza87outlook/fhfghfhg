
import { Language } from '../types/language';

export type TranslationSection = {
  [key: string]: {
    [key in Language]: string;
  };
};
