import { Language } from '../types/language';
import { TranslationSection } from './types';

export const userDashboardTranslations: TranslationSection = {
  'dashboard.welcome': {
    'en': 'Welcome, {name}',
    'es': 'Bienvenido/a, {name}'
  },
  'dashboard.cards.status.title': {
    'en': 'Application Status',
    'es': 'Estado de la Solicitud'
  },
  'dashboard.cards.status.description': {
    'en': 'Track your current application',
    'es': 'Sigue tu solicitud actual'
  },
  'dashboard.cards.status.review': {
    'en': 'Documents Under Review',
    'es': 'Documentos en Revisión'
  },
  'dashboard.cards.status.message': {
    'en': 'Our legal team is reviewing your uploaded documents.',
    'es': 'Nuestro equipo legal está revisando los documentos subidos.'
  },
  'dashboard.cards.status.noApplications': {
    'en': 'You have not started any applications yet.',
    'es': 'Aún no has comenzado ninguna solicitud.'
  },
  'dashboard.cards.status.draft': {
    'en': 'Draft',
    'es': 'Borrador'
  },
  'dashboard.cards.status.submitted': {
    'en': 'Submitted',
    'es': 'Enviada'
  },
  'dashboard.cards.status.approved': {
    'en': 'Approved',
    'es': 'Aprobada'
  },
  'dashboard.cards.status.rejected': {
    'en': 'Rejected',
    'es': 'Rechazada'
  },
  'dashboard.cards.status.docs': {
    'en': 'Additional Documents Required',
    'es': 'Documentos Adicionales Requeridos'
  },
  'dashboard.cards.status.none': {
    'en': 'No Applications',
    'es': 'Sin Solicitudes'
  },
  'dashboard.cards.nextsteps.title': {
    'en': 'Next Steps',
    'es': 'Próximos Pasos'
  },
  'dashboard.cards.nextsteps.description': {
    'en': 'What you need to do',
    'es': 'Lo que necesitas hacer'
  },
  'dashboard.cards.nextsteps.biometric': {
    'en': 'Schedule Biometric Appointment',
    'es': 'Programar Cita Biométrica'
  },
  'dashboard.cards.nextsteps.message': {
    'en': 'Please schedule your biometric data collection appointment.',
    'es': 'Por favor, programa tu cita para la recolección de datos biométricos.'
  },
  'dashboard.cards.support.title': {
    'en': 'Support',
    'es': 'Soporte'
  },
  'dashboard.cards.support.description': {
    'en': 'Get help with your application',
    'es': 'Obtén ayuda con tu solicitud'
  },
  'dashboard.cards.support.questions': {
    'en': 'Have questions?',
    'es': '¿Tienes preguntas?'
  },
  'dashboard.cards.support.message': {
    'en': 'Contact your dedicated immigration expert for assistance.',
    'es': 'Contacta a tu experto en inmigración dedicado para asistencia.'
  },
  'dashboard.timeline.title': {
    'en': 'Application Timeline',
    'es': 'Cronología de la Solicitud'
  },
  'dashboard.timeline.step1.title': {
    'en': 'Eligibility Check Completed',
    'es': 'Verificación de Elegibilidad Completada'
  },
  'dashboard.timeline.step1.date': {
    'en': 'May 10, 2025',
    'es': '10 de Mayo, 2025'
  },
  'dashboard.timeline.step2.title': {
    'en': 'Documents Uploaded',
    'es': 'Documentos Subidos'
  },
  'dashboard.timeline.step2.date': {
    'en': 'May 15, 2025',
    'es': '15 de Mayo, 2025'
  },
  'dashboard.timeline.step3.title': {
    'en': 'Legal Review In Progress',
    'es': 'Revisión Legal En Curso'
  },
  'dashboard.timeline.step3.status': {
    'en': 'Current Step',
    'es': 'Paso Actual'
  },
  'dashboard.timeline.step4.title': {
    'en': 'Biometric Appointment',
    'es': 'Cita Biométrica'
  },
  'dashboard.timeline.step4.date': {
    'en': 'Scheduled for May 25, 2025',
    'es': 'Programado para el 25 de Mayo, 2025'
  },
  'dashboard.timeline.step5.title': {
    'en': 'Permit Approval',
    'es': 'Aprobación del Permiso'
  },
  'dashboard.timeline.step5.date': {
    'en': 'Expected by June 15, 2025',
    'es': 'Esperado para el 15 de Junio, 2025'
  },
  'dashboard.startApplication': {
    'en': 'Start Application',
    'es': 'Iniciar Solicitud'
  },
  'dashboard.loading': {
    'en': 'Loading your dashboard...',
    'es': 'Cargando tu panel de control...'
  },
  'dashboard.applicationStatus.current': {
    'en': 'Current Status',
    'es': 'Estado Actual'
  },
  'dashboard.applicationTimeline.applicationStarted': {
    'en': 'Application Started',
    'es': 'Solicitud Iniciada'
  },
  'dashboard.applicationTimeline.applicationSubmitted': {
    'en': 'Application Submitted',
    'es': 'Solicitud Enviada'
  },
  'dashboard.applicationTimeline.legalReview': {
    'en': 'Legal Review In Progress',
    'es': 'Revisión Legal En Curso'
  },
  'dashboard.applicationTimeline.applicationApproved': {
    'en': 'Application Approved',
    'es': 'Solicitud Aprobada'
  },
  'dashboard.applicationTimeline.applicationRejected': {
    'en': 'Application Rejected',
    'es': 'Solicitud Rechazada'
  },
  'dashboard.applicationTimeline.docsRequested': {
    'en': 'Additional Documents Requested',
    'es': 'Documentos Adicionales Solicitados'
  },
  'dashboard.applicationStatus.draft': {
    'en': 'Draft',
    'es': 'Borrador'
  },
  'dashboard.applicationStatus.submitted': {
    'en': 'Submitted',
    'es': 'Enviada'
  },
  'dashboard.applicationStatus.underReview': {
    'en': 'Under Review',
    'es': 'En Revisión'
  },
  'dashboard.applicationStatus.docsRequired': {
    'en': 'Additional Documents Required',
    'es': 'Documentos Adicionales Requeridos'
  },
  'dashboard.applicationStatus.approved': {
    'en': 'Approved',
    'es': 'Aprobada'
  },
  'dashboard.applicationStatus.rejected': {
    'en': 'Rejected',
    'es': 'Rechazada'
  },
  'dashboard.applicationStatus.completed': {
    'en': 'Completed',
    'es': 'Completada'
  },
  'dashboard.messages.title': {
    'en': 'Messages',
    'es': 'Mensajes'
  },
  'dashboard.messages.noMessages': {
    'en': 'No messages yet',
    'es': 'Aún no hay mensajes'
  },
  'dashboard.messages.placeholder': {
    'en': 'Type your message here...',
    'es': 'Escribe tu mensaje aquí...'
  },
  'dashboard.messages.send': {
    'en': 'Send',
    'es': 'Enviar'
  },
  'dashboard.messages.loading': {
    'en': 'Loading messages...',
    'es': 'Cargando mensajes...'
  },
  'dashboard.messages.error': {
    'en': 'Failed to load messages',
    'es': 'Error al cargar mensajes'
  },
  'dashboard.messages.from': {
    'en': 'From',
    'es': 'De'
  },
  'dashboard.messages.message': {
    'en': 'Message',
    'es': 'Mensaje'
  },
  'dashboard.messages.date': {
    'en': 'Date',
    'es': 'Fecha'
  },
  'dashboard.messages.actions': {
    'en': 'Actions',
    'es': 'Acciones'
  },
  'dashboard.messages.view': {
    'en': 'View',
    'es': 'Ver'
  },
  'dashboard.messages.compose': {
    'en': 'Compose Message',
    'es': 'Redactar Mensaje'
  },
  'dashboard.messages.viewing': {
    'en': 'Viewing message from',
    'es': 'Viendo mensaje de'
  },
  'common.cancel': {
    'en': 'Cancel',
    'es': 'Cancelar'
  }
};
