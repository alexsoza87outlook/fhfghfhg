
export type PersonalDetails = {
  first_name?: string;
  first_last_name?: string;
  second_last_name?: string;
  email?: string;
  phone?: string;
  address_line1?: string;
  address_line2?: string;
  city?: string;
  state?: string;
  postal_code?: string;
  country?: string;
  sex?: string;
  passport_number?: string;
  nie?: string;
  place_of_birth?: string;
  country_of_birth?: string;
  nationality?: string;
  date_of_birth?: string;
};

export type ApplicationDocument = {
  id: string;
  document_type: string;
  file_path: string;
  original_filename: string;
  uploaded_at: string;
};

export type ApplicationStatus = 'draft' | 'submitted' | 'under_review' | 'approved' | 'rejected' | 'completed' | 'additional_docs_required';
export type PaymentStatus = 'pending' | 'completed' | 'failed';
export type ApplicationStep = 'personal_details' | 'documents' | 'additional_documents' | 'review' | 'payment' | 'complete';

export type UserProfile = {
  id?: string;
  full_name?: string; 
  email?: string;
};

export type Application = {
  id: string;
  user_id: string;
  status: ApplicationStatus;
  current_step: ApplicationStep;
  payment_status: PaymentStatus;
  created_at: string;
  updated_at: string;
  submitted_at?: string;
  assigned_solicitor_id?: string;
  personal_details?: PersonalDetails;
  documents?: ApplicationDocument[];
  user_profile?: UserProfile;
};

export type StatusUpdate = {
  id: string;
  application_id: string;
  status: string;
  comment?: string;
  created_by: string;
  created_at: string;
};
