
import { CountryOption } from '@/data/countriesData';

/**
 * Sort countries alphabetically by name
 */
export const getSortedCountries = (countries: CountryOption[]): CountryOption[] => {
  return [...countries].sort((a, b) => a.name.localeCompare(b.name));
};

/**
 * Filter countries by search term
 */
export const filterCountriesBySearchTerm = (
  countries: CountryOption[],
  searchTerm: string
): CountryOption[] => {
  if (searchTerm.trim() === '') {
    return countries;
  }
  
  return countries.filter((country) =>
    country.name.toLowerCase().includes(searchTerm.toLowerCase())
  );
};
