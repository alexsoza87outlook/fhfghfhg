
import { Language } from '../types/language';
import allTranslations from '../translations';

export const translateKey = (key: string, language: Language, params?: Record<string, string>): string => {
  if (!allTranslations[key]) {
    console.warn(`Translation key not found: ${key}`);
    return key;
  }
  
  let text = allTranslations[key][language];
  
  // Replace any parameters in the text
  if (params) {
    Object.entries(params).forEach(([paramKey, value]) => {
      text = text.replace(`{${paramKey}}`, value);
    });
  }
  
  return text;
};
